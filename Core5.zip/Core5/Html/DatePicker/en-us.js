﻿sjs.define(function(){
    return {
        DAYS:[
            "Sun",
            "Mon",
            "Tue",
            "Wed",
            "Thu",
            "Fri",
            "Sat"
        ]
    }
});