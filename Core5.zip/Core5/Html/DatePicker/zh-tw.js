﻿sjs.define(function(){
    return {
        DAYS:[
            "日"
            ,"一"
            ,"二"
            ,"三"
            ,"四"
            ,"五"
            ,"六"
        ]
    }
});