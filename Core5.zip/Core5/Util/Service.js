﻿//如果bsom,qip日記等之前的程式如果改動后有問題，可能是jQuery升級到1.8.3的原因，可以先改回來，compile后再改回去即可
//sjs.loadJs("./ref/jQuery-1.4.2.min.js")
//sjs.loadJs("./ref/jquery-1.8.3.min.js")
sjs.loadJs("./Ref/JSON.js")
.using("jQuery")
.using("$SERVICE_CONFIG")
.using("Core5.Util.EventManager")
.define(function(jq,serviceConfig,eventManager){
    var serviceCaller = {};
   function prefixCall(ret) {
        var getRet=[];
        var errMsg="";
        if(!ret.AjaxError) {
            for(var i=0;i<ret.Result.length;i++) {
                if(!ret.Result[i].AjaxError)
                    getRet.push(ret.Result[i].Result);
                else
                    errMsg+=(errMsg.length>0?"\n":"")+ret.Result[i].Message;
            }
        }
        else
            errMsg=ret.Message;

        if(errMsg.length>0)
            return errMsg;
        else
            return getRet;
    }
    
    //var sjsHost = sjs.getRIAService();
    //var _host = sjsHost?"http://" + sjsHost:"";////172.19.6.86";//"http://172.19.40.190";//
     
    //call _ui類型的service，必須當前的MENU_JS必須match
    function getContextMenuJs(context){
        var callObj = context;
        while(callObj){
            if(callObj.MENU_JS){
                return callObj.MENU_JS;
            }

            callObj = callObj.parent;
        }
        return null;
    }
    
    function checkContextMenuJs(service,args,context){
        var uiService; 
        var clientToolService = service.split("$");
        if(service.indexOf("._ui.")>0){
            uiService = service;
        }
        else if(
            (clientToolService[0]=="ClientTool.QueryPage"
                || clientToolService[0]=="ClientTool.Query"
                || clientToolService[0]=="ClientTool.QueryDataSet"
                || clientToolService[0]=="ClientTool.QueryRows"
                || clientToolService[0]=="ClientTool.QueryRow"
                || clientToolService[0]=="ClientTool.QueryObject"
                || clientToolService[0]=="ClientTool.ExecuteObject"
                || clientToolService[0]=="ClientTool.ExecuteDataSet"
                || clientToolService[0]=="ClientTool.Execute"
                || clientToolService[0]=="ClientTool.ExecuteOutput")
            && args[0].indexOf("._ui.")>0){
            uiService = args[0] + (clientToolService.length==2?"$" + clientToolService[1]:"");
        }
        
        if(uiService){
            //cusCallService,context請放在最后一個params里
            if(context=="contextIsParamsLast"){
                context = args.pop();
            }

            if(!context || typeof(context)!="object"){
                alert('call _ui style service(' + uiService + ')\ncontext can not be empty!\n(cusCallService context please set as the last params)');
                return false;
            }

            var contextMenuJs = getContextMenuJs(context);
            if(!contextMenuJs){
                alert('call _ui style service(' + uiService + ')\ncontext(or parent) no MENU_JS property!\n(cusCallService context please set as the last params)');
                return false;
            }

            var serviceMenuJsErrMsg = "\n------------------\ncontextMenuJs:" + contextMenuJs + "\nuiService:" + uiService + (service.indexOf("._ui.")>0?"":"(SqlHelper)") + "\n------------------\n";
            //console.log(serviceMenuJsErrMsg);

            var menuJsConfig = contextMenuJs.split("$");
            var uiServiceConfig = uiService.split("$");
            if(menuJsConfig.length!=uiServiceConfig.length || menuJsConfig.length==2 && menuJsConfig[1]!=uiServiceConfig[1]){
                alert('call _ui style service(' + serviceMenuJsErrMsg + ')\n$SERVICE_CONFIG is not same!\ncontextMenuJs:' + contextMenuJs + "\nuiService:" + uiService);
                return false;
            }

            //contextMenuJs:PCI.App.XXX.Index
            //service:PCI.App._ui.XXX.aaa
            //serviceAppID:PCI.App.

            //contextMenuJs:PCI.App.YYY.ZZZ
            //service:PCI.App._ui.YYY.aaa
            //serviceAppID:PCI.App.
            contextMenuJs = menuJsConfig[0];
            var serviceItems = uiServiceConfig[0].split("._ui.");
            var serviceAppID = serviceItems[0] + ".";
            if(contextMenuJs.indexOf(serviceAppID) !=0){
                alert('call _ui style service(' + serviceMenuJsErrMsg + ')\ncontextMenuJs not start with serviceAppID!\ncontextMenuJs:' + contextMenuJs + "\nserviceAppID:" + serviceAppID);
                return false;
            }
            
            //service:PCI.App._ui.XXX.ZZZ.aaa
            //serviceItems[1]:XXX.ZZZ.aaa
            //serviceID:XXX.ZZZ.
            //contextMenuJs:PCI.App.XXX.Index
            //menuJs:XXX.

            //service:PCI.App._ui.YYY.aaa
            //serviceItems[1]:YYY.aaa
            //serviceID:YYY.
            //contextMenuJs:PCI.App.YYY.ZZZ
            //menuJs:YYY.ZZZ.
            //[not match]

            var serviceIDAry = serviceItems[1].split(".");
            serviceIDAry.pop();
            var serviceID = serviceIDAry.join(".") + ".";
            var menuJsAry = contextMenuJs.split(".");
            if(menuJsAry[menuJsAry.length-1] == "Index"){
                menuJsAry.pop();
            } 
            var menuJs = menuJsAry.join(".").substr(serviceAppID.length) + ".";


            if(serviceID.indexOf(menuJs)!=0){
                alert('call _ui style service(' + serviceMenuJsErrMsg + ')\nserviceID not start with menuJs!\nserviceID:' + serviceID + "\nmenuJs:" + menuJs);
                return false;
            }

        }
        return true;
    }

    serviceCaller.cusCallService = function(service,params,view,args,serviceKind,noOpen,host){
        
        host = sjs.getRIAServiceByHost(host || sjs.getHost());
        var serviceUrl = host + "?NoMultipleLang=1&ServiceKind=" + (serviceKind || "View");
        
        var servicePackage = {service:(serviceConfig?service.split("$")[0] + "$" + serviceConfig:service),params: params};

        if(!checkContextMenuJs(servicePackage.service,servicePackage.params,"contextIsParamsLast")){
            return "about:blank";
        }

		var JsonService = encodeURIComponent(JsonHelper.encode(servicePackage));
        serviceUrl += "&JsonService=" + JsonService;
        
        serviceUrl += "&view=" + view;
        
        if(args){
            for(var p in args){
                serviceUrl += "&" + p + "=" + args[p];
            }
        }
        if(!noOpen){
            window.open(serviceUrl);
        }
        else{
            return serviceUrl;
        }
    }

    //解決跨域問題，iframe提交一次，正常ajax再提交一次
    var _jsonKey = 0;

    function getJsonKey(){
        return (new Date().valueOf()) + "_" +  (++_jsonKey);;
    }

    var _iframeCall = {};
    var _iframeKey = 0;

    function existInArray(ary,item){
        if(ary && ary.length){
            for(var i=0;i<ary.length;i++){
                if(ary[i] == item){
                    return true;
                }
            }
        }
        return false;
    }

    serviceCaller.exportExcelByHtml = function(fileName,excelHtml){
		if(!jq("#__excelOutputFrm").length){
			var strHtml = '<form name="__excelOutputFrm"  id="__excelOutputFrm" action="/RIAService/ExportExcel.aspx" method="post" target="__excelExportIfm" style="display:none">';
			strHtml += '<input type="hidden" name="__excelHtmlHdn" id="__excelHtmlHdn">';
			strHtml += '<input type="hidden" name="__excelFileNameHdn" id="__excelFileNameHdn">';
			strHtml += '</form>';
			strHtml += '<iframe name="__excelExportIfm" style="display:none"></iframe>';				
			jq("body").append(strHtml);
		}
		jq("#__excelHtmlHdn").val(excelHtml);
		jq("#__excelFileNameHdn").val(fileName);
		jq("#__excelOutputFrm")[0].submit();
    }

    serviceCaller.callServiceUpload = function(serviceCommand,commitId,params,context,okFn,errFn,addParam,host){
        var methodIndex = serviceCommand.lastIndexOf(".");
        var service = serviceCommand.substr(0,methodIndex);
        var command = serviceCommand.substr(methodIndex+1)
        var formJq = jq("#SERVICE_UPLOAD_FORM");
        var form = formJq[0];
        if(!form){      //no any upload create
            callService(service,command,params,context,okFn,errFn,addParam,host);
            return;
        }
        //服務端啟用session,阻塞同一個client發出的http請求，這樣，upload進程一定先完成，而后面的正常json call則后面完成
        var iframeKey = (new Date().valueOf()) + "_" +  (++_iframeKey);

        var servicePackage = service.push?service:typeof(service)=="string"?{service:service + "." + command ,params: params}:service;

        if(serviceConfig){
            if(servicePackage.push){
                for(var i=0;i<servicePackage.length;i++){
                    servicePackage[i].service = servicePackage[i].service.split("$")[0] + "$" + serviceConfig;
                }
            }
            else{
                servicePackage.service = servicePackage.service.split("$")[0] + "$" + serviceConfig;
            }
        }

        //檢查service是否match MENU_JS
        if(servicePackage.push){
            for(var i=0;i<servicePackage.length;i++){
                if(!checkContextMenuJs(servicePackage[i].service,servicePackage[i].params,context)){
                    return;
                }
            }
        }
        else{
            if(!checkContextMenuJs(servicePackage.service,servicePackage.params,context)){
                return;
            }
        }

        var jsonService = JsonHelper.encode(servicePackage);

        //var jsonService = JsonHelper.encode({service:"ClientTool.UploadTmp",params:[jsonKey]});
        //var iframeHost = host || _host;
        var iframeHost = sjs.getRIAServiceByHost(host || sjs.getHost());

        var formArr = jq.makeArray(form);       //IE8,jQuery-1.8.3(Line 595) can not use formJq in fn.apply(context,[here]).so makeArray first

        if(iframeHost.indexOf("http://")==0){       //不同域名
            var url = iframeHost + "?ServiceKind=Upload&UploadKey=" + iframeKey;// + "&JsonService=" + encodeURIComponent(jsonService);
            //正常提交           
            jq("input[name='JsonService']",formJq).val(jsonService);
            form.setAttribute("action", url);



            var cannotCommit = false;

            jq("input[type='file']",formJq).each(function(){
                var id = jq(this).attr("id");
                if(jq(this).attr("TYPE_NOT_ALLOWED")=="1"){
                    cannotCommit = true;
                }
                jq(this).prop("disabled",!existInArray(commitId,id));
            });//,formArr);
            if(cannotCommit){
                alert('file type not allowed,please choose again');
                return;
            }
            eventManager.publish(serviceCaller,"callService",servicePackage,iframeHost,serviceConfig,context,addParam);
            form.submit();

            jq("input[type='file']",formJq).each(function(){
                jq(this).prop("disabled",false);         //還原
            });

            //同時結果交正常ajax返回
            callService("PCIWeb.UploadService","WaitResult",[iframeKey],context,function(result){
                    //真正的結果還在里面
                eventManager.publish(serviceCaller,!result.AjaxError?"callServiceOK":"callServiceErr",result,servicePackage,iframeHost,serviceConfig,context,addParam);
                if(!result.AjaxError)
                    okFn && okFn.call(context || window,result.Result,addParam,result);
                else if(errFn)
                    errFn.call(context || window,result,addParam);
                else if(!loadingMsgExists())
                    alert((result.Message || "").replace(/\<br\>/gi,"\r\n"));

            },errFn,addParam,iframeHost);
        }
        else{       //同域名，正常就好
            _iframeCall[iframeKey] = {
                context:context
                ,okFn:okFn
                ,errFn:errFn
                ,addParam:addParam
                ,servicePackage:servicePackage
                ,host:iframeHost
                ,serviceConfig:serviceConfig
            };
            
            var url = iframeHost + "?iframeRequest=1&callback=parent.sjs.iframeCallBack&callbackArgs=" + iframeKey;// + "&JsonService=" + encodeURIComponent(jsonService);
            //iframeRequest 不當作js，而是普通返回值
            //var url = iframeHost + "?iframeRequest=1&JsonService=" + encodeURIComponent(jsonService);

            var cannotCommit = false;
            jq("input[type='file']",formJq).each(function(){
                var id = jq(this).attr("id");
                if(jq(this).attr("TYPE_NOT_ALLOWED")=="1"){
                    cannotCommit = true;
                }
                jq(this).prop("disabled",!existInArray(commitId,id));
            });
            if(cannotCommit){
                alert('file type not allowed,please choose again');
                return;
            }

            jq("input[name='JsonService']",formJq).val(jsonService);
            form.setAttribute("action", url);

            eventManager.publish(serviceCaller,"callService",servicePackage,iframeHost,serviceConfig,context,addParam);

            form.submit();

            jq("input[type='file']",formJq).each(function(){
                jq(this).prop("disabled",false);         //還原
            });

        }
        //讓submit先過去，因為iframe在跨域時，IE，不能有效能知道load事件，從而無法實現回調
        //window.setTimeout(function(){
            //debugger
        //    callService(service,command,params,context,okFn,errFn,addParam,host,jsonKey);
        //},1);
    }

    sjs.iframeCallBack = function(result){
        //alert(JsonHelper.encode(result));

        var iframeKey = result.callbackArgs;
        var iframeCall = _iframeCall[iframeKey];
        delete _iframeCall[iframeKey];
        var okFn = iframeCall.okFn;
        var errFn = iframeCall.errFn;
        var context = iframeCall.context;
        var addParam = iframeCall.addParam;
        eventManager.publish(serviceCaller,!result.AjaxError?"callServiceOK":"callServiceErr",result,iframeCall.servicePackage,iframeCall.host,iframeCall.serviceConfig,context,addParam);
        if(!result.AjaxError)
            okFn && okFn.call(context || window,result.Result,addParam,result);
        else if(errFn)
            errFn.call(context || window,result,addParam);
        else if(!loadingMsgExists())
            alert((result.Message || "").replace(/\<br\>/gi,"\r\n"));

    }

    //兼容舊的Core2等程式，因為沒有傳errFn，如果也沒有加載Core5.Widget.Loading的話，出錯會沒有提示
    //但是Core5的程式，因為在Run里面有加載了Loading，所以出錯直接用Loading中的訊息，不再額外alert了
    function loadingMsgExists(){
        return !!sjs._getLoadedJs()["Core5.Widget.Loading"];
    }



    serviceCaller.callService = function(service,command,params,context,okFn,errFn,addParam,host,addJsonKey){
        var serverService;
        if(typeof(service)=="object" && !service.push)  //不是數組
        {
            var fn = service[command];
            if(typeof(fn)=="string")                //模擬服務結束，修改成真正的service名稱
            {
                serverService = {service:fn,params:params};
            }
            else if(typeof(fn)=="function"){        //UI模擬服務
                var fnRet = fn.call(service,params,context,okFn,errFn,addParam,host);
                if(fnRet){
                    if(typeof(fnRet)=="string"){
                        serverService = {service:fn,params:params};
                    }
                    else if(typeof(fnRet)=="object"){
                        serverService = fnRet;
                    }
                    else{
                        alert("only string,object or void can be return in this function:" + command);
                    }
                }
                else{
                    return;
                }
            }
            else{
                serverService = fn;        //service和params組合好了
            }
        }
        else if(typeof(service)=="string"){
            serverService = {service:service + "." + command,params:params};
        }
        else{       //數組
            serverService = service;
        }

        //host = host || _host;
        host = sjs.getRIAServiceByHost(host || sjs.getHost());

        var servicePackage = serverService;


        if(serviceConfig){
            if(servicePackage.push){
                for(var i=0;i<servicePackage.length;i++){
                    servicePackage[i].service = servicePackage[i].service.split("$")[0] + "$" + serviceConfig;
                }
            }
            else{
                servicePackage.service = servicePackage.service.split("$")[0] + "$" + serviceConfig;
            }
        }

        //檢查service是否match MENU_JS
        if(servicePackage.push){
            for(var i=0;i<servicePackage.length;i++){
                if(!checkContextMenuJs(servicePackage[i].service,servicePackage[i].params,context)){
                    return;
                }
            }
        }
        else{
            if(!checkContextMenuJs(servicePackage.service,servicePackage.params,context)){
                return;
            }
        }


        var jsonService = JsonHelper.encode(servicePackage);


        //var jsonService = JsonHelper.encode(serverService)//service.push?service:typeof(service)=="string"?{service:serviceCommand ,params: params}:service);
        var successFn = function(result, textStatus) {
            if(service.push){
                var ret = prefixCall(result);
                if(!ret.push){
                    result.Message = ret;
                }
                eventManager.publish(serviceCaller,ret.push?"callServiceOK":"callServiceErr",result,servicePackage,host,serviceConfig,context,addParam);
                if(ret.push){
                    okFn && okFn.call(context || window,ret,addParam,result);
                }
                else if(errFn)
                    errFn.call(context || window,result,addParam);
                else if(!loadingMsgExists())
                    alert((ret || "").replace(/\<br\>/gi,"\r\n"));
            }
            else{
                eventManager.publish(serviceCaller,!result.AjaxError?"callServiceOK":"callServiceErr",result,servicePackage,host,serviceConfig,context,addParam);
                if(!result.AjaxError)
                    okFn && okFn.call(context || window,result.Result,addParam,result);
                else if(errFn)
                    errFn.call(context || window,result,addParam);
                else if(!loadingMsgExists())
                    alert((result.Message || "").replace(/\<br\>/gi,"\r\n"));
            }
        }
        
        var errorFn = function(XMLHttpRequest, textStatus, errorThrown) {
            var result = {AjaxError:-1,Result:null,Message:XMLHttpRequest.statusText,textStatus:textStatus,errorThrown:errorThrown};
            eventManager.publish(serviceCaller,"callServiceErr",result,servicePackage,host,serviceConfig,context,addParam);
            if(errFn)
                errFn.call(context || window,result,addParam);
            else if(!loadingMsgExists())
                alert((result.Message || "").replace(/\<br\>/gi,"\r\n"));
        }         
        
        eventManager.publish(serviceCaller,"callService",servicePackage,host,serviceConfig,context,addParam);
        var maxLen = 800;//1024 chrome不行?;          //每一次最多1500個字符
        if(!addJsonKey && jsonService.length<=maxLen){      //拆包
            jq.ajax({
                url: host + "?JsonService=" + encodeURIComponent(jsonService)
                ,async: true
                ,type: "get"             //支持IE6
                ,dataType: "jsonp"       //可跨域請求
                //,contentType: "application/x-www-form-urlencoded;charset=utf-8"
                ,success: successFn
                ,error: errorFn
            });
        }
        else{
            //debugger;
            var jsons = [];
            for(var i=0;i<jsonService.length;i+=maxLen){
                var remainLen = i<jsonService.length-1?maxLen:jsonService.length - i;
                var jsonStr = jsonService.substr(i,Math.max(remainLen,maxLen));
                jsons.push(jsonStr);
            }
            
            var jsonKey = addJsonKey || getJsonKey();
            var startIndex = 0;//addJsonKey ? 1 : 0;前面的一定會自己完成
            var jsonTotal = jsons.length + startIndex;
            var jsonNotFinish = jsons.length;
            for(var i=0;i<jsons.length;i++){
                jq.ajax({
                    url: host + "" +
                        "?JsonKey=" + jsonKey +
                        "&JsonTotal=" + jsonTotal +
                        "&JsonSeq=" + (i + startIndex) +
                        "&JsonService=" + encodeURIComponent(jsons[i])
                    ,async: true
                    ,type: "get"             //支持IE6
                    ,dataType: "jsonp"       //可跨域請求
                    //,contentType: "application/x-www-form-urlencoded;charset=utf-8"
                    ,success: function(result, textStatus){
                        jsonNotFinish--;
                        if(jsonNotFinish==0){
                            successFn(result, textStatus);
                        }
                    }
                    ,error: function(XMLHttpRequest, textStatus, errorThrown){
                        jsonNotFinish--;
                        if(jsonNotFinish==0){
                            errorFn(XMLHttpRequest, textStatus, errorThrown);
                        }
                    }
                });
            }
        }
    }        

    return serviceCaller;
});