﻿/*
將row的一個或多個欄位值，以attr方式加入到tr的tag中
*/
sjs.using("Core5.Widget.Table.GenRowKey")
.define(function(genRowKey){
    return genRowKey("row");
});