﻿sjs.define(function(){
    var currencyReg=/(\d{1,3})(?=(\d{3})+(?:$|\D))/g ;

    return {
        currency:"$"    
        ,formatNull:true
        ,format:function(value){
            if(value){       //db中是數字
                var tmp = ("" + value).split('.');    //小數點
                var n1=tmp[0].replace(currencyReg,"$1,");
                return this.currency + n1 + (tmp.length>1?"." + tmp[1]:'');
            }
            return this.currency + "0";
        }
    };
});