﻿sjs.loadCss("Core5.Widget.Input")
.using("Core5.Component")
.using("Core5.Util.StrFn")
.using("Core5.DomEvent.oninput")
.define(function(component,strFn) {
    function getDateFromStr(day){
        return new Date(day.substr(0,4),Number(day.substr(4,2))-1,Number(day.substr(6,2)));
    }

    function getStrFromDate(now){
        var y = now.getFullYear();
        var m = "" + (now.getMonth() + 1);
        m = m.length < 2 ? "0" + m : m;
        var d = "" + now.getDate();
        d = d.length < 2 ? "0" + d : d;
        return "" + y + m + d;
    }
    
    var dateChecker = {
        getShowText:function(text){
            //console.log("show text:" + text);
            return text?text.substr(0,4) + "/" + text.substr(4,2) + "/" +text.substr(6,2):text;
        }

        ,checkInput:function(input){
            var error = this.$base(input);
            if(!error){
                error = input.length!=8 || isNaN(input) || getStrFromDate(getDateFromStr(input))!=input
                    ? " is not a valid date(format(yyyymmdd) like:20140228)"
                    : null;
            }
            return error;
        }

        ,placeHolder:"date format:yyyymmdd,like:20140228"
    }


    return {
        $extend:component
        ,$plugin:[dateChecker]
        ,regUIObj:true
        ,"-s-text":true
        ,inputType:"text"

        //当前状态，focus中还是没有focus
        ,_editing:false
        ,_text:""       //当前input中的文字
        ,text:""

        ,inner:function(){
            return {
                tag:"input"
                ,tagNoInner:true 
                ,"-s-text-input":true
                ," s-focus":"focus"
                ," s-blur":"blur"
                ," s-change":"change"
                ," s-mouseup":"mouseup"
                // ," s-keypress":"keydown"
                // ," onmouseup":"return false"    //chrome无论是当前已经select，还是没有select，如果用return false，则再怎样也无法改变当前状态
                ," value":this._text.replace(/"/g,"&quot;")
                ," type":this.inputType
                ," readonly":this.isDisabled()?true:null
                ,attribute:this.inputAttr
            };
        }
/*
        ,onKeydown:function(src,e,val){
            if(isNaN(val)){
                console.log("keydown:" ,val);
                e.preventDefault();
                this.set("_text",this._text);
                return false;
            }
        }
*/
        ,onFocus:function(){
            this.set("_editing",true);
            this._focused = true;
        }

        ,onMouseup:function(ipt,e){
            this._focused && ipt[0].select();
            this._focused  = false;
            e.stopPropagation();        //cancel mouseup return false in DragMove.js
        }

        ,onBlur:function(){
            // debugger;
            this.set("_editing",false);
        }

        ,trimInput:true     //是否将用户的输入去空格
        ,onChange:function(ipt,e,input){
            this._text = input;     //用于在set _text时的change比较
            //this.iptEvt && this.report(this.iptEvt,input);  //真的需要将这种事件公布上去吗？
            //如果上层真的有需要这么细致的事件，即不把它当控件，而是对view的细节也感兴趣，则请自己override此方法来发出事件就好
            //像datePicker弹出monthPicker那样，虽然选择的月份是当前月份，但上层还是希望在点到当前月时，直接将这个monthPicker这个pop关闭，
            //这是为了更好的用户体验，但不是monthPicker的控件本身需要考虑的，monthPicker当然不会让用户去点当前已选中的月，就像select控件不会让用户去点已选中的行一样，就像radio控件，永远也点不到radio，除非去响应click事件
            input = this.trimInput ? strFn.trim(input):input;
            //this.emptyInput放这里虽然会逃过checkInput的检查，但是让checkInput可能面对的是非字符串的值，造成验证程式复杂
            // input = input.length==0 && typeof(this.emptyInput) != "undefined" ? this.emptyInput:input;
            // var error = this._checkInput(input);
            this._checkInput(input);        //用这种方法支援异步
            // else if(typeof(this.errorValue)!="undefined"){
            //     //error = text === this.errorValue?error:null;
            //     text = this.errorValue;
            // }
            //有error时，默认不会改变当前input中的内容？本来需要重新设定text，但是因为还有blur事件的_editing改变，所以没关系
            //因为没有改变text，导致error出错时，getShowText执行出相同的结果

            //如同select插件一样，如果selected没有变化，user连选都选不到，更不会有事件向上发了
            //上层并不对数据的任何一次操作感兴趣，而是对数据有改变才感兴趣，否则就自己override一些view方法，或者自己开发view了
            //而自己的text设定同样如此，虽然后者最终会判断底层是否一样去做东东
            //这是外部入口，本身能够控制在变化时设定是必须的
            //至于上层，当然没有考虑是否一样才设定，它只是粗暴的直接调用set方法，至于会不会让VIEW重复绘制，则是控件内部的事情了
            //就比如datePicker中的yearMonth依赖于day，但是yearMonth可在用户的操作下被改变，造成day没有控制到yearMonth
            //而上层在给下一笔数据时，如果考虑到资料一样不给，这样，datePicker在显示下一笔资料时的yearMonth仍然处于非同步状态，会让user感到困扰
            //而label的format也一样，如果text没有变化
        }
        
        ,onDisabledChange:function(){
            var disabled = this.isDisabled();
            this.setClass("s-readonly",disabled);
            this.isRender() && this.jq(".s-text-input").prop("readonly",disabled);
        }

        ,_set_text:function(text,change){
            //因为text一样，所以最后计算出来的_text肯定也一样，所以这里也不会有change
            //所以不会改变input中的显示内容（出错状态下，这样就不会清空用户输入的内容，而是让其有机会在错误的基础上重新输过）
            //同样这里有一个bug，也让值与上一次相似时，无法正确更新值
            this.isRender() && change && this.jq(".s-text-input").val(text);
            // this.isRender() && change && console.log("real set dom...",text);

        }

        ,_setRealText:function(){
            var text = this._editing?this.getInputText(this.text):this._getShowText(this.text);
            text = text===null || typeof(text)=="undefined"?'':'' + text; 
            this.set("_text",text);
            // console.log("_setRealText execute:",this.text,this._text);
        }

        ,_set_editing:function(editing){
            if(editing){
                this.removeClass("s-text-empty-prompt");
            }
            !this.error && this._setRealText();    //这个不用判断change，因为一是因为editing一定change，而且可能有显示错误的讯息在
        }
        
        //这里不判断change了，防止正在输入时，被外部设定了text，需要清空当前input的内容（好像也清空不到，因为_text还是未改变）
        //_text会被user改变，而有可能不会动到text，error时，就不会设定text，所以这里不能判断change
        ,_setText:function(text,change){
            this._setRealText();  //直接操作UI了（因为_text并不会自己变化，所以不像datePicker中的day和yearMonth那样，不能设定change才去改变yearMonth）
        }

        ,_getShowText:function(text){
            //可override在前面，然后不会取消placeHolder的设定
            var nullOrEmpty = text === null || ('' + text).length==0;
            if(this.placeHolder){
                this.setClass("s-text-empty-prompt",nullOrEmpty);
            }
            if(this.placeHolder && nullOrEmpty){// && !this.error){
                return this.placeHolder;
            }
            return this.getShowText(text);
        }

        ,getShowText:function(text){
            return text;
        }

        ,getInputText:function(text){
            return text;
        }

        //,required:false   //为默认的checkInput作准备
        ,_checkInput:function(input){
            var error;
            if(input.length==0){
                error = this.required?"required!":null;
            }
            else{
                error = this.checkInput(input);
            }
            if(typeof(error) != "undefined"){   //checkInput返回undefined(即没有return语句，则表示checkInput函数自己会回调_checkInputOK函数)
                this._checkInputOK(input,error)
            }
            // if(input.length>0 && isNaN(input)){
            //     return input + " is not a number";
            // }
            // if(input.length>0){
            //     input = Number(input);
            //     if(input < 1){
            //         return input + " is not greater than 0";
            //     }
            // }
        }

        ,_checkInputOK:function(input,error){
            if(error !== this.error){
                this.set("error",error);
                this.errEvt && this.report(this.errEvt,this.error);
            }
            if(!error){      //error不影响当前的text值？
                var text = this._getTextFromInput(input);
                if(typeof(text)!="undefined"){      //如果没有return语句，则表示getTextFromInput函数会自己回调_getTextFromInputOK函数
                    this._getTextFromInputOK(text);
                }
            }
        }

        ,checkInput:function(input){
            return null;
            //因为checkInput可以多种规则合并
            /*
            var error = this.$base(input);
            if(!error){

            }
            return error;
            */
        }

        ,emptyInput:null  //当输入值最后计算出来的是empty时，转换成什么值，默认转成null，各类型通用，但字符串等也可以转成空，数字则可转成0
        //,caseMode:""      //upper(转大写),lower(转小写),undefined:不转
        ,_getTextFromInput:function(input){
            if(input.length==0 && typeof(this.emptyInput) != "undefined"){
                return this.emptyInput;
            }
            if(this.caseMode){
                input = this.caseMode=="upper"?input.toUpperCase():input.toLowerCase();
            }
            return this.getTextFromInput(input);
        }

        ,_getTextFromInputOK:function(text){
            if(text !== this.text){
                this.set("text",text);  //只要是user行为就设定text吧
                this.evt && this.report(this.evt,this.text);
            }
        }

        ,getTextFromInput:function(input){
            return input;
        }
        
        ,_setError:function(error,change){
            if(change){
                this.setClass("s-input-error",error);
                this.attr("title",error || null);
            }
        }

        //view method
        ,focus:function(){
            if(this.isRender()){
                var ipt = this.jq(".s-text-input")[0];
                ipt.focus();
                ipt.select();
                this._focused  = false;
            }
        }

        ,init:function(){
            this.$base();
            this._initData("text");     //要区分edit还是非edit状态，然后给出在input中不同的显示数据
            this._initData("error");    //error可由外部控制，主要是清空error由外部负责（如果text在外部有重新赋值时，请记得清空error，否则可能让之前的error出现在现在这笔正常的Input框中）
        }

        //,text:0
        //,error:"must greater than 0"

        //,required:true      //有这个,emptyInput无效。不是保证text不会是null或空，而是保证user一定要输入字串，因此required不属于checkInput的范畴
        //emptyInput不受管控了，如果前面有说要大于0，小于500，而这里设定为501，则不会接受check
        //required为false，下面这两个可能才有用
        //,emptyInput:0//null       //先验证，再设定这个值，因此这个值必须有效，否则不会再进行checkInput了
        //,placeHolder:"please input your age here..."


        //不是的，required还是保证值不能为空或null的，所以后面的emptyInput不能设定为null，否则会逃跑
        //,disabled:true

    }
});