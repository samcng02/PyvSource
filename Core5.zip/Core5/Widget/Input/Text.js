﻿sjs.loadCss("Core5.Widget.Input")
.using("Core5.Component")
.using("Core5.Widget.Mixin.Input")
.using("Core5.DomEvent.oninput")
.define(function(component,input) {
    return {
        $extend:component
        ,$mixin:[input]
        ,regUIObj:true
        ,"-s-text":true
        ,inputType:"text"
        
        ,inner:function(){
            return {
                tag:"input"
                ,tagNoInner:true 
                ,"-s-text-input":true
                ," s-change":"input"
                //," emptyText":this.emptyText
                //暫時不想將這兩個事件放出去，直接在這里做算了
                //," onfocus":"sjs.getSjsDefine()['Core5.DomEvent.UIManager'].get(this.parentNode.getAttribute('s-objId')).onfocus()"//if(this.value==this.getAttribute('emptyText')){this.value=''}else{var me=this;window.setTimeout(function(){me.select()},10)}"         //chrome,opeara,safari由為onmouseup事件，會讓focus一閃而過
                //," onfocus":"sjs.getSjsDefine()['Core5.DomEvent.UIManager'].get('" + this._objId + "') && sjs.getSjsDefine()['Core5.DomEvent.UIManager'].get('" + this._objId + "').onfocus()"//if(this.value==this.getAttribute('emptyText')){this.value=''}else{var me=this;window.setTimeout(function(){me.select()},10)}"         //chrome,opeara,safari由為onmouseup事件，會讓focus一閃而過
                //兩種寫法都可以，但上面那種變量更好一些
                //," onblur":"sjs.getSjsDefine()['Core5.DomEvent.UIManager'].get('" + this._objId + "') && sjs.getSjsDefine()['Core5.DomEvent.UIManager'].get('" + this._objId + "').onblur()"//"if(this.value=='' && this.getAttribute('emptyText')){this.value=this.getAttribute('emptyText')}"         
                
                ," s-focus":"iptFocus"
                ," s-blur":"iptBlur"

                
                ," s-mouseup":"mouseup"
                // ," onmouseup":"return false"
                ," value":this._text?this._text.replace(/"/g,"&quot;"):""
                ," type":this.inputType
                ," readonly":this.isDisabled()?true:null
                ,attribute:this.inputAttr
            };
        }

        ,onIptFocus:function(){
            //console.log("onfocus");
            if(!this.isDisabled()){  
                var ipt = this.jq(".s-text-input");
                if(this.emptyText && ipt.val()== this.emptyText){
                    this.set("_text",'');
                }   
                else{
                    this._focused = true;
                }
            }
        }

        ,onMouseup:function(ipt,e){
            this._focused && ipt[0].select();
            this._focused  = false;
            e.stopPropagation();        //cancel mouseup return false in DragMove.js
        }

        ,focus:function(){
            if(this.isRender()){
                var ipt = this.jq(".s-text-input")[0];
                ipt.focus();
                ipt.select();
                this._focused  = false;
            }
        }

        ,onIptBlur:function(){
            //onblur先還是onchange先?
            //console.log("onblur");
            if(!this.isDisabled()){  
                var ipt = this.jq(".s-text-input");
                if(ipt.val()=='' && this.emptyText){
                    this.set("_text",this.emptyText);
                }   
            }
        }

        ,onDisabledChange:function(){
            var disabled = this.isDisabled();
            this.setClass("s-readonly",disabled);
            if(this.isRender()){
                this.jq(".s-text-input").prop("readonly",disabled);
            }
        }
        
        ,_set_text:function(text,change){
            this.emptyText && this.setClass("s-text-empty-prompt",text==this.emptyText);
            if(this.isRender() && change){        
                this.jq(".s-text-input").val(text);
            }
        }
        
        ,onInput:function(ipt,e,text){
            //console.log("onchange");
            if(!this.isDisabled()){        
                this.setInput(text);
            }
        }
        
        ,_setError:function(error,change){
            //if(this.fieldNo=='SEND_QTY')
            if(change){
                this.setClass("s-input-error",error);
                this.attr("title",error || null);
            }
        }
        
        /*
        //TODO:input mask
        ,onfocus:function(){
        
        }
        
        ,onblur:function(){
        
        }
        ,checkInput:function(input){
            var ret = this.$base(input);
            if(!ret){
                if(input=="error"){
                    return "test error"
                }
            }
            return ret;
        }
        
        ,_setByError:function(error){
            if(this.isRender()){
                this.attr("title",error?"Error:" + error:"");
            }
        }
        */
    }
});