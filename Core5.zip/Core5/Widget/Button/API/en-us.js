sjs.define(function(){
    return {
        TEXT:"button text"
        ,ICON:"button icon"
        ,ICON_REMARK:"all icons reference {link:Core5.Widget.Button.Help.Icon}"
        ,RIGHTICON:"icon in the right"
        ,RIGHTICON_REMARK:"icons config same to {config:icon}"
        ,EVT:"when user click button"

        ,ONCOMMAND:"just raise evt event in it,so if you not call this.$base() in your override function,evt config no useful again"
    }
});