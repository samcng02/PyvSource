﻿//這里面只處理數據,不處理view
//data -> view
sjs.using("Core5.Util.StrFn")
.define(function(strFn){
    return {
        //show按value產生,如果show和value同時可以賦值,則是另一個類型
        init:function(){
            this.$base();
            this._initData("value");
            //this._initData("error");            //error不是可配置屬性
        }
        
        ,format:function(value){
            return value;
        }
        
        //外部同時控制value和error，所以error不要以value來變化
        ,_setValue:function(value,change){
            //因為有可能用戶修改了text，但是現在上面又重新設置了value值，所以不要判斷change值
            var text = this.format(value);
            text = text === null || typeof(text)=="undefined"?this.emptyText || "":text;      //不要显示null在input框中
            this.set("_text",text + "");
        }

        ,trimInput:true         //輸入后需要去掉輸入的空格嗎，從資料庫抓出的訂單號，線別等可能不需要去空格，直接Insert到資料庫中
        
        //提供给onchange或onkeypress事件直接綁定
        //input不需要有数据存储
        ,setInput:function(input){
            var currentShow = input;     //當前顯示的值就是this._text，后面會比較change再更新，所以先在這里置值先
            if(this.trimInput){
                input = strFn.trim(input);
            }
            if(this.upperCase){
                input = input.toUpperCase();
            }
            if(input == this.emptyText){
                input = "";
            }
            var ret;
            if(input.length==0){
                ret = this.required ? {error:"required"} : {value:this.emptyInput};
            }
            else{
                ret = this.checkInput(input);
            }
            if(ret.error){
                this._innerSetError(ret.error);
                this.set("_text",input + "");       //還原顯示輸錯的，免得重新輸入 
            }
            else{
                this._text = currentShow;
                this._innerSetValue(ret.value);
            }
        }
        
        //除配置外，还可以直接在外面动态改变，以便即时修正checkInput方法是否需要验证
        //只是一个开关而已，不影响数据，不影响逻辑(error是否就影响了?不会，因为肯定要清空value,input等数据)
        ,required:false
        
        ,checkInput:function(input){
            return {value:input};
        }
        
        ,emptyInput:null        //如果想转换，可以config这个

        
        //,errEvt:""
        
        //這些事件是由這個控件原生產生的.不是通過外部出來的
        ,_innerSetError:function(error){
            this.set("error",error);
            this.set("value",null);
            this.errEvt && this.report(this.errEvt,this.error);                
        }
        
        //,evt:""
        
        //上層應該onValue清空error，否則value正確時，error錯誤無法清除
        //除了本身輸入的外,還可以通過彈出pop給的值
        ,_innerSetValue:function(value){
            this.set("error",null);        
            this.set("value",value);
            this.evt && this.report(this.evt,this.value,this._text);
        }

        
        //UI控制.by
        //eval("with({aa:1,bb:2,test:function(a){return a+2}}){test(bb)>3?'red':'green'}")
        //如果是mvvm,最好做到能綁定到這個上面
        //,".s-text-input@html":"{this.show}"                               //source有me或parent
        /*
        ,";border":"1px solid {this._error?'green':'red'}"                     //自動提取變量
        
        ,";border":{
            bind:"error"           //多個欄位用逗號分開
            ,source:"me"           
            ,value:function(cfg){
                return "1px solid " + (this._error?"green":"red");
            }
        }
        
        ,text:{
            bind:"day"
            ,source:"parent"
            ,value:function(cfg){
                var day = this.parent.day;
                return '<div title="' + (day?"current select:" + day:"please click to select") + '">' + (day || "&nbsp;") + '</div>';
            }
        }
        */
        //两个UI方法
        //可能有error,也可能沒有error
        /*
        ,_setByError:function(error){

        }
        
        ,_setByShow:function(show){

        }        
        */
        

        //数据栏位:value,error,show
        ,setValue:function(value){
            this.set("value",value);
            return this;
        }  
             
        
    }
});