﻿/*沒有border的清爽排版*/
sjs.loadCss("Core5.Layout.Form2")
.using("Core5.Layout.Form")
.define(function(formLayout) {
    return {
        $extend:formLayout 
        ,"-s-form2":true
        ,cellSpacing:4
    }
});