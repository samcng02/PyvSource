﻿/*
這個mixin可以讓某層component只成為一個layout框架
但是parent/child關係往上移
事件也直接越過此層往上報
*/
sjs.define(function(){
    return  {
        createChild:function(extend,arg1,arg2,argN,childCfg){
            var args = Array.prototype.slice.call(arguments);
            return this.parent.createChild.apply(this.parent,args);
        }
    };
});