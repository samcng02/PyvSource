﻿sjs.define(function(){
    return {
        _initInnerItem:function(itemCfg,itemIndex){
            var ret= this.$base(itemCfg,itemIndex);
            this._layoutInitInnerItem(ret,itemIndex);
            return ret;
        }

        ,_layoutInitInnerItem:function(item,itemIndex){
            if(item.css){
                itemIndex == 0?
            }
            item.css && item.css("margin",this.itemMargin);

        }
    }
});