/*
用作模板
*/
sjs.using("Core5.Container")
.define(function(container){
	return {
		$extend:container
	};
});