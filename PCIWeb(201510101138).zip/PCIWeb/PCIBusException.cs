﻿using System;
using System.Collections.Generic;

namespace PCIWeb
{

    #region 對於程式異常，不包裝
    /*

    /// <summary>
    /// Exception Solution(主要用於報錯和幫助系統)
    /// </summary>
    /// <remarks>
    /// 1.終止當前流程
    /// 2.提供訊息給相關人員(程式員或User)
    /// 3.記錄異常(可Log出去)
    /// </remarks>
    //[Serializable]        //ObjectBuilder2中的Exception類未被序列化
    public class PCIAppException : Exception
    {
                
        #region Standard constructors - do not use

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        public PCIAppException()
        {

        }

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        /// <param name="message">Error message, ignored.</param>
        public PCIAppException(string message) : base(message)
        {
        }

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        /// <param name="message">Error message, ignored.</param>
        /// <param name="innerException">Inner exception.</param>
        public PCIAppException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        #endregion

        object _context;
        object[] _args;

        public PCIAppException(
            object context
            ,string message
            ,Exception inner
            ,params object[] args):base(message,inner)
        {
            this._context = context;
            this._args = args;
            //this.HResult = 1;
            //this.HelpLink = "";
            //Level:用戶(可修改數據，再次提交)/管理員(包括維護人員，分配權限或檢查配置)/開發人員(檢查程式)
            //this.Source = raiseObj.GetType().FullName + "." + this.TargetSite.Name;
        }
    }
    
    */

    #endregion

    /// <summary>
    /// 用戶錯誤
    /// </summary>
    [Serializable]
    public class PCIBusException : Exception
    {
                

        #region Standard constructors - do not use

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        public PCIBusException()
        {

        }

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        /// <param name="message">Error message, ignored.</param>
        public PCIBusException(string message) : base(message)
        {
        }

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        /// <param name="message">Error message, ignored.</param>
        /// <param name="innerException">Inner exception.</param>
        public PCIBusException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        #endregion

        //object _context;
        //object[] _args;

        //public PCIBusException(
        //    object context
        //    ,string message
        //    ,params object[] args):base(message)
        //{
        //    _context = context;
        //    _args = args;               
        //}
    }

    [Serializable]
    public class PCINoPermissionException : Exception
    {


        #region Standard constructors - do not use

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        public PCINoPermissionException()
        {

        }

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        /// <param name="message">Error message, ignored.</param>
        public PCINoPermissionException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        /// <param name="message">Error message, ignored.</param>
        /// <param name="innerException">Inner exception.</param>
        public PCINoPermissionException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        #endregion

        //object _context;
        //object[] _args;

        //public PCIBusException(
        //    object context
        //    ,string message
        //    ,params object[] args):base(message)
        //{
        //    _context = context;
        //    _args = args;               
        //}
    }

    [Serializable]
    public class PCINeedLoginException : Exception
    {


        #region Standard constructors - do not use

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        public PCINeedLoginException()
        {

        }

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        /// <param name="message">Error message, ignored.</param>
        public PCINeedLoginException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        /// <param name="message">Error message, ignored.</param>
        /// <param name="innerException">Inner exception.</param>
        public PCINeedLoginException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        #endregion

        //object _context;
        //object[] _args;

        //public PCIBusException(
        //    object context
        //    ,string message
        //    ,params object[] args):base(message)
        //{
        //    _context = context;
        //    _args = args;               
        //}
    }

    [Serializable]
    public class PCINotAvailableException : Exception
    {


        #region Standard constructors - do not use

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        public PCINotAvailableException()
        {

        }

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        /// <param name="message">Error message, ignored.</param>
        public PCINotAvailableException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Create a new <see cref="PCIAppException"/>. Do not use this constructor, it
        /// does not take any of the data that makes this type useful.
        /// </summary>
        /// <param name="message">Error message, ignored.</param>
        /// <param name="innerException">Inner exception.</param>
        public PCINotAvailableException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        #endregion

        //object _context;
        //object[] _args;

        //public PCIBusException(
        //    object context
        //    ,string message
        //    ,params object[] args):base(message)
        //{
        //    _context = context;
        //    _args = args;               
        //}
    }


    #region  常規Exception定義

    /*
    [global::System.Serializable]
    public class MyException : Exception
    {
        public MyException() { }
        public MyException(string message) : base(message) { }
        public MyException(string message, Exception inner) : base(message, inner) { }
        protected MyException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

    [Serializable]
    public sealed class CustomException : Exception
    {
        // 添加的自定义字段
        private string stringInfo;
        private bool booleanInfo;

        // 实现三个公有的构造函数，这里只是简单地调用基类的构造函数
        public CustomException() { }

        public CustomException(string message) : base(message) { }

        public CustomException(string message, Exception inner)
            : base(message, inner) { }

        // 实现ISerialization接口所需要的反序列化构造函数。
        // 因为本类为sealed，该构造函数为private。
        private CustomException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            stringInfo = info.GetString("StringInfo");
            booleanInfo = info.GetBoolean("BooleanInfo");
        }

        // 添加构造函数以确保自定义字段能得到正确的初始化
        public CustomException(string message, string stringInfo, bool booleanInfo)
            : base(message)
        {
            this.stringInfo = stringInfo;
            this.booleanInfo = booleanInfo;
        }

        public CustomException(string message, Exception inner, string stringInfo, bool booleanInfo)
            : base(message, inner)
        {
            this.stringInfo = stringInfo;
            this.booleanInfo = booleanInfo;
        }

        // 通过属性或其它成员提供对自定义字段的访问
        public string StringInfo
        {
            get { return stringInfo; }
        }

        public bool BooleanInfo
        {
            get { return booleanInfo; }
        }

        // 重写GetObjectData方法。(序列化時會調用的方法)
        // 如果添加了自定义字段，一定要重写基类GetObjectData方法的实现。
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            // 序列化自定义数据成员
            info.AddValue("StringInfo", stringInfo);
            info.AddValue("BooleanInfo", booleanInfo);

            // 调用基类方法，序列化它的成员
            base.GetObjectData(info, context);
        }

        public override string Message
        {
            get
            {
                string message = base.Message;

                if (stringInfo != null)
                {
                    message += Environment.NewLine +
                        stringInfo + " = " + booleanInfo;
                }

                return message;
            }
        }
    }
    */
    #endregion
}