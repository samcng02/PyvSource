﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Web;
using System.Data;
using PCIWeb.Tools;
using System.Threading;

namespace PCIWeb
{

    #region Http格式調用服務

    /// <summary>
    /// 將服務調用結果用Json格式輸出到客戶端
    /// </summary>
    public class HttpService
    {
        public static readonly HttpService Instance = new HttpService();

        protected virtual void dealResult(Dictionary<string, object> ret)
        {
            HttpContext.Current.Response.CacheControl = "no-cache";
            string noJsonError = HttpContext.Current.Request.QueryString["NoJsonError"];
            if (noJsonError!=null)       //不要json方式輸出，如果錯誤，則直接輸入NoJson的值
            {
                HttpContext.Current.Response.Clear();
                if (ret["AjaxError"].ToString() == "0")
                {
                    HttpContext.Current.Response.Write(ret["Result"].ToString());
                }
                else
                {
                    if (noJsonError == "ServiceMessage")
                    {
                        //HttpContext.Current.Response.Write("AjaxError:" + ret["AjaxError"].ToString());
                        HttpContext.Current.Response.Write(ret["Message"].ToString());
                    }
                    else
                    {
                        HttpContext.Current.Response.Write(noJsonError);
                    }
                }
            }
            else
            {
                this.dealJsonResult(ret);
            }
        }

        public void DealJsonResult(HttpContext context, Dictionary<string, object> ret)
        {
            ret["EndTimeTicks"] = Math.Round(DateTime.Now.Ticks / 10000M);
            string result = "";
            try
            {
                //throw new ApplicationException("Test");
                string callbackArgs = context.Request.QueryString["callbackArgs"];      //jsonp
                ret["callbackArgs"] = callbackArgs;
                result = Tool.ToJson(ret);
            }
            catch (Exception ex2)
            {
                Tool.Warn("結果輸出json出錯", "ex2", ex2);
                //再試一次
                System.Threading.Thread.Sleep(1000);
                try
                {
                    //throw new ApplicationException("Test2");
                    result = Tool.ToJson(ret);

                }
                catch (Exception ex)
                {
                    Tool.Error("結果輸出json重試也出錯", "ex", ex);
                    result = "{\"AjaxError\":\"4\",\"Message\":\"結果轉Json出錯:" + ex.Message + "\"}";
                }
            }
            context.Response.Clear();
            //在用iframe upload時，IE會出現腳本下載
            string iframeRequest = context.Request.QueryString["iframeRequest"];      //jsonp
            if(iframeRequest!="1")
                context.Response.ContentType = "text/javascript; charset=utf-8";
            string callback = context.Request.QueryString["callback"];      //jsonp
            if (callback != null)
            {
                if(iframeRequest=="1")
                    context.Response.Write("<script type='text/javascript'>");
                if (callback.ToLower() == "sjs.run")
                {
                    context.Response.Write("sjs.run(function(){ return");
                }
                else
                {
                    context.Response.Write(callback);
                    context.Response.Write("(");
                }
            }
            context.Response.Write(result);
            if (callback != null)
            {
                if (callback == "sjs.run")
                    context.Response.Write("})");
                else
                    context.Response.Write(");");
               if(iframeRequest=="1")
                   context.Response.Write("</script>");
            }
        }

        protected virtual void dealJsonResult(Dictionary<string, object> ret)
        {
            DealJsonResult(HttpContext.Current, ret);
        }

        static object _lockObj = new object();

        //IE6的url長度有限，2083個字符，因此提供緩存功能，讓長url可以傳過來
        string getJsonCall(HttpContext context, out int remain)
        {
            remain = 0;         //還剩多少個
            string jsonCall = context.Request["JsonService"]; //context.Request.QueryString["JsonService"];
            string jsonKey = context.Request["JsonKey"];
            if (jsonKey == null || jsonKey.Trim().Length == 0)
                return jsonCall;

            //不保證完全成功
            string cacheKey = context.Request.UserHostAddress + "_" + jsonKey;          //IP
            int jsonSeq = int.Parse(context.Request["JsonSeq"]);
            int jsonTotal = int.Parse(context.Request["JsonTotal"]);
            string[] cacheJsonStr = null;
            lock (_lockObj)
            {
                cacheJsonStr = HttpRuntime.Cache[cacheKey] as string[];
                if (cacheJsonStr == null)
                {
                    cacheJsonStr = new string[jsonTotal];
                    for (int i = 0; i < cacheJsonStr.Length; i++)
                    {
                        cacheJsonStr[i] = null;
                    }
                    HttpRuntime.Cache.Insert(cacheKey, cacheJsonStr
                        , null
                        , System.Web.Caching.Cache.NoAbsoluteExpiration
                        , new TimeSpan(0, 5, 0)         //5分鐘自動刪除(也就是說5分鐘之內必須完成所有包的傳送)
                        , System.Web.Caching.CacheItemPriority.Default
                        , null
                    );
                }
            }
            cacheJsonStr[jsonSeq] = jsonCall;
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            for (int i = 0; i < cacheJsonStr.Length; i++)
            {
                if (cacheJsonStr[i] == null)
                {
                    remain++;
                }
                else if (remain == 0)
                {
                    sb.Append(cacheJsonStr[i]);
                }
            }
            if (remain == 0)
            {
                HttpRuntime.Cache.Remove(cacheKey);
                return sb.ToString();
            }
            else
            {
                return null;
            }
        }

        public virtual void Run()
        {
            HttpContext context = HttpContext.Current;
            if (context != null)
            {
                //string jsonCall = context.Request["JsonService"]; //context.Request.QueryString["JsonService"];
                int remain;
                string jsonCall = getJsonCall(context, out remain);
                if (jsonCall == null || jsonCall.Trim().Length == 0)
                    dealResult(Tool.ToDic(
                        new object[]{
                            "AjaxError",remain==0?"4":"7"
                            ,"Message",remain==0?"Must provide JsonService QueryString":"wait " +remain.ToString() + " package" }));
                else
                    dealResult(ServiceCaller.Instance.CallToDic(ServiceCaller.CallType.PermissionCall, jsonCall));
            }
            else
                throw new ApplicationException("這個方法必須通過http請求調用");
        }

    }

    /// <summary>
    /// 將服務調用結果，轉到Http.Items中，再交給View來處理輸出(可為html，也可以轉檔輸出Excel等)
    /// </summary>
    public class ViewService : HttpService
    {
        public static readonly new ViewService Instance = new ViewService();

        protected override void dealResult(Dictionary<string, object> ret)
        {
            HttpContext.Current.Response.Clear();
            string errCode = ret["AjaxError"].ToString();
            if (errCode == "0")
            {
                string view = HttpContext.Current.Request["view"];
                if (view.StartsWith("/") || view.StartsWith("http://") || view.StartsWith("https://"))
                {
                    HttpContext.Current.Response.Redirect(view);
                }
                else
                {
                    HttpContext.Current.Items["model"] = ret;
                    HttpContext.Current.Server.Execute(view, true);
                }
            }
            else
            {
                HttpContext.Current.Response.Write(ret["Message"].ToString());
            }
        }
    }



    /// <summary>
    /// 因為iframe不能跨域請求的原因，所以將用iframe的結果保存到一個cache中，等待要結果的過來
    /// </summary>
    public class UploadService : HttpService
    {
        public static readonly new UploadService Instance = new UploadService();

        public Dictionary<string, AutoResetEvent> _uploadContextes = new Dictionary<string, AutoResetEvent>();

        static object _lockCacheObj = new object();
        static object _lockThreadObj = new object();

        Dictionary<string, Dictionary<string, object>> _results = new Dictionary<string, Dictionary<string, object>>();

        protected override void dealResult(Dictionary<string, object> ret)
        {
            HttpContext context = HttpContext.Current;
            //找一下當前有沒有在等待UploadKey的東東
            string uploadKey = context.Request["UploadKey"];
            string cacheKey = context.Request.UserHostAddress + "_" + uploadKey;          //IP

            AutoResetEvent waitContext = getResetEvt(cacheKey);
            _results.Add(cacheKey, ret);
            waitContext.Set();

        }

        AutoResetEvent getResetEvt(string cacheKey)
        {
            lock (_lockThreadObj)
            {
                if (!_uploadContextes.ContainsKey(cacheKey))
                {
                    _uploadContextes.Add(cacheKey, new AutoResetEvent(false));
                }
                return _uploadContextes[cacheKey];
            }
        }

        public Dictionary<string,object> WaitResult(string uploadKey)
        {
            HttpContext context = HttpContext.Current;
            string cacheKey = context.Request.UserHostAddress + "_" + uploadKey;          //IP
            AutoResetEvent evt = getResetEvt(cacheKey);
            //evt.WaitOne(new TimeSpan(0,1,0));           //最多等待1分鐘(.net 2.0 sp2才支持)
            evt.WaitOne(new TimeSpan(0, 1, 0), false);
            _uploadContextes.Remove(cacheKey);
            if (_results.ContainsKey(cacheKey))
            {
                Dictionary<string, object> ret = _results[cacheKey];
                _results.Remove(cacheKey);
                return ret;
            }
            throw new ApplicationException("嚴重錯誤，可能有線程死鎖，要重新審視這段代碼是否OK.WaitOne后沒有等到結果???");
       }
    }

    #endregion

    public interface IService
    {
        object Call(string command, object[] args);
    }

    /// <summary>
    /// 服務提供者
    /// </summary>
    public class ServiceCaller
    {

        //TODO:以后可用0x01,0x02,0x04,再用CallType.XXCall & callType的方式來組合是否進行某種call,以方便外部調用
        public enum CallType
        {
            PermissionCall          //包括權限，事務的service 呼叫
            ,
            TransactionCall         //只進行事務的service呼叫
            ,
            BaseCall          //只進行最內部的call(反射調用)
        }

        public static readonly ServiceCaller Instance = new ServiceCaller();

        #region 無異常(有的將錯誤放在Dic中，有的直接用轉向登錄或錯誤頁面處理)

        //以Json格式call(一次可調用多個服務)
        public Dictionary<string, object> CallToDic(ServiceCaller.CallType callType, string jsonCall)
        {
            Dictionary<string, object> ret = new Dictionary<string, object>();

            object jsonObject = null;
            try
            {
                jsonObject = Tool.ToObject(jsonCall);
            }
            catch (Exception ex)
            {
                ret["AjaxError"] = "4";
                ret["Message"] = "Tool.ToObject failure,json format invalid(" + jsonCall + " message:" + ex.Message + ")";
                return ret;
            }

            bool isMultiple = false;     //是不是多個調用
            ArrayList items = null;
            if (jsonObject is ArrayList)
            {
                isMultiple = true;
                items = jsonObject as ArrayList;
            }
            else if (jsonObject is Dictionary<string, object>)
            {
                items = new ArrayList(new object[] { jsonObject });
            }

            List<Dictionary<string, object>> multipleRet = new List<Dictionary<string, object>>();
            if (items != null && items.Count > 0)
            {
                foreach (Dictionary<string, object> dic in items)
                    multipleRet.Add(CallToDic(callType, dic));
            }
            else
            {
                ret["AjaxError"] = "4";
                ret["Message"] = "service format(json) invalid(" + jsonCall + ")";
            }


            if (isMultiple)
            {
                ret["AjaxError"] = 0;
                ret["Result"] = multipleRet;
                ret["IsMultiple"] = true;
            }
            else
            {
                ret = multipleRet[0];
                ret["IsMultiple"] = false;
            }

            return ret;
            //return Tool.ToJson(ret);
        }

        //以Dic格式call(只一個)
        public Dictionary<string, object> CallToDic(ServiceCaller.CallType callType, Dictionary<string, object> dic)
        {
            Dictionary<string, object> ret = new Dictionary<string, object>();
            if (dic != null)
            {
                string service = null;
                object[] args = null;
                //合在一起是因為，對外提供服務不一定是這樣的形式，還可能是直接一個服務名稱（如PCIUserList)
                //所以留下接口在這里
                if (dic.ContainsKey("service"))
                {
                    service = dic["service"].ToString();
                    if (dic.ContainsKey("params"))
                    {
                        ArrayList tmp = dic["params"] as ArrayList;
                        if (tmp != null)
                        {
                            args = new object[tmp.Count];
                            tmp.CopyTo(args);
                        }
                    }
                    //開發測試用，可以指定延遲，以測試網路，database繁忙情況
                    if (dic.ContainsKey("callDelay"))
                        System.Threading.Thread.Sleep(int.Parse(dic["callDelay"].ToString()));

                    ret = CallToDic(callType, service, args);
                }
                else
                {
                    ret["AjaxError"] = 4;
                    ret["Message"] = "service call description invalid(must provide service!)";
                }
            }
            else
            {
                ret["AjaxError"] = 4;
                ret["Message"] = "service call description is null(not a json object)";
            }
            return ret;
        }

        //直接以service和args進行call
        public Dictionary<string, object> CallToDic(ServiceCaller.CallType callType, string service, params object[] args)
        {
            Dictionary<string, object> ret = new Dictionary<string, object>();
            try
            {
                object result = Call(callType, service, args);
                ret["AjaxError"] = 0;
                ret["Result"] = result;
                ret["Params"] = args;
            }
            catch (PCINeedLoginException lex)
            {
                //需要登錄
                ret["AjaxError"] = 1;
                ret["Message"] = "Need Login(" + lex.Message + ")";
                Tool.Warn("服務調用(需登錄)", "Info", lex.Message);
            }
            catch (PCINoPermissionException pex)
            {
                //沒有權限
                ret["AjaxError"] = 2;
                ret["Message"] = "No Pemission:" + pex.Message;
                Tool.Warn("服務調用(無權限)", "Info", pex.Message);

            }
            catch (PCIBusException bex)             //在Ajax的Injector中拋出來的,不是通過反射出來的，也可能是為了提高性能，不使用反射，直接通過Ajax對象進行的
            {
                ret["AjaxError"] = 3;
                ret["Message"] = bex.Message;
                ret["ClientInfo"] = bex.Data["ClientInfo"];
                Tool.Warn("服務調用(用戶錯誤)", "Info", bex.Message);
            }
            catch (PCINotAvailableException bex)             //在Ajax的Injector中拋出來的,不是通過反射出來的，也可能是為了提高性能，不使用反射，直接通過Ajax對象進行的
            {
                ret["AjaxError"] = 6;
                ret["Message"] = bex.Message;
                Tool.Trace("服務不可用(系统公告)", "Info", bex.Message);
            }
            //以下2這種錯誤不到client端去，只能用日志工具查詢
            //TODO:考慮debug時，可以返回所有
            catch (ApplicationException aex)
            {
                ret["AjaxError"] = 4;
                ret["Message"] = aex.Message;
                Tool.Error("服務調用出錯", "Message", aex.Message, "內部異常", aex.InnerException);
            }
            catch (Exception ex)
            {
                ret["AjaxError"] = 5;
                ret["Message"] = "【未識別的異常】";// +ex.Message;
                Tool.Error("服務調用出錯(未捕獲)", "ex", ex);
            }
            ret["Service"] = service;
            return ret;
        }

        public T AspCall<T>(ServiceCaller.CallType callType, string service, params object[] args)
        {
            try
            {
                T ret = Call<T>(callType, service, args);
                return ret;
            }
            catch (PCINeedLoginException lex)
            {
                Tool.Warn("AspCall服務調用(需登錄)", "Info", lex.Message);
                HttpContext.Current.Response.Redirect(HttpContext.Current.Request.ApplicationPath + "/View/Login.aspx?ReturnPath=" + HttpContext.Current.Server.UrlEncode(HttpContext.Current.Request.Path.ToString()));
            }
            catch (PCINoPermissionException pex)
            {
                Tool.Warn("AspCall服務調用(無權限)", "Info", pex.Message);
                HttpContext.Current.Response.Redirect(HttpContext.Current.Request.ApplicationPath + "/View/Login.aspx?PermissionInfo=" + pex.Message + "&ReturnPath=" + HttpContext.Current.Server.UrlEncode(HttpContext.Current.Request.Path.ToString()));
            }
            catch (PCIBusException bex)             //在Ajax的Injector中拋出來的,不是通過反射出來的，也可能是為了提高性能，不使用反射，直接通過Ajax對象進行的
            {
                Tool.Warn("AspCall服務調用(用戶錯誤)", "Info", bex.Message);
                HttpContext.Current.Response.Write("<div class='errorMsg'>" + bex.Message + "</div>");
                HttpContext.Current.Response.Write("<a href='javascript:history.back()'>返回上一頁</a>");
                HttpContext.Current.Response.End();
            }
            catch (PCINotAvailableException vex)             //在Ajax的Injector中拋出來的,不是通過反射出來的，也可能是為了提高性能，不使用反射，直接通過Ajax對象進行的
            {
                Tool.Error("AspCall服務不可用", "Message", vex.Message);
                HttpContext.Current.Response.Write("<div class='errorMsg'>" + vex.Message + "</div>");
                HttpContext.Current.Response.Write("<a href='javascript:history.back()'>返回上一頁</a>");
                HttpContext.Current.Response.End();
            }

            catch (ApplicationException aex)
            {
                Tool.Error("AspCall服務調用出錯", "Message", aex.Message, "內部異常", aex.InnerException);
                HttpContext.Current.Response.Write("<div class='errorMsg'>" + aex.Message + "</div>");
                HttpContext.Current.Response.Write("<a href='javascript:history.back()'>返回上一頁</a>");
                HttpContext.Current.Response.End();
            }
            catch (Exception ex)
            {
                Tool.Error("AspCall服務調用出錯(未捕獲)", "ex", ex);
                HttpContext.Current.Response.Write("<div class='errorMsg'>" + ex.Message + "</div>");
                HttpContext.Current.Response.Write("<a href='javascript:history.back()'>返回上一頁</a>");
                HttpContext.Current.Response.End();
            }
            return default(T);
        }

        #endregion

        #region 有異常Call

        public T Call<T>(ServiceCaller.CallType callType, string service, params object[] args)
        {
            object ret = Call(callType, service, args);
            if (ret == null)
                return default(T);
            return (T)ret;
        }

        public object Call(CallType type, string service, params object[] args)
        {
            return call(type, service, args);
        }

        public object Apply(CallType type, string service, object[] args)
        {
            return call(type, service, args);
        }

        #endregion

        #region call實現(內部)

        //初始化Call
        protected virtual object call(CallType type, string service, params object[] args)
        {
            try
            {
                int paramsIndex = service.IndexOf("$");
                if (paramsIndex > 0)
                {
                    AppEventHanlder.Instance.SetServiceVarContent(service.Substring(paramsIndex + 1));
                    service = service.Substring(0, paramsIndex);
                    /*
                    string serviceApp = AppEventHanlder.Instance.ServiceVar("App");
                    if (serviceApp != null)
                    {
                        string appConfig = SystemConfig.Instance.Get<string>("Apps.js", serviceApp);
                        if (appConfig != null && appConfig.Length>0)
                        {
                            //string serviceConfig = AppEventHanlder.Instance.ServiceVar("Config") ?? "";
                            //Config和App同時存在時，目前是這樣假設的
                            /*
                             * 應用場景，如一支UI程式，同時可查詢正式資料庫和歷史資料庫，用service和service?Config=His來切換
                             * 這時如果有App是GSI，則應該搜索xxx-GSI和xxx-HisGSI這樣的config
                             * 也就是組合Config和App，把Config看作是程式hardcode代碼，而App是動態建立的代碼?
                             * Config可以直接寫在客戶端程式中，而App則是動態加在Menu上的
                             * 另外,Config是否也可以動態配置在Menu上呢？為簡單化，不行，要在外面動態設定Config，則必須使用App，其實也就是在
                             * Apps.js中增加一個配置就好
                             */
                            //config優先當前直接請求的config，再來用App的config
                            //同時有App和Config過來時，怎么辦？目前是優先Config，再來App
                            //以后具體情況具體分析?
                            /*
                            if (serviceConfig.Length > 0)
                            {
                                string[] appConfigs = appConfig.Split(new char[] { ',' });
                                string[] serviceConfigs = serviceConfig.Split(new char[] { ',' });
                                string[] combineConfig = new string[appConfigs.Length * serviceConfigs.Length];
                                int configIndex = 0;
                                foreach (string c1 in serviceConfigs)
                                {
                                    foreach (string c2 in appConfigs)
                                    {
                                        combineConfig[configIndex++] = c1 + c2;
                                    }
                                }
                            }
                            * /
                            //string newServiceConfig = serviceConfig + (serviceConfig.Length > 0 ? "," : "") +  appConfig;
                            //AppEventHanlder.Instance.SetServiceVar("Config", newServiceConfig);
                            //直接替換好了，不搞這么復雜。即任何時候只能有一個Config起作用
                            //所以要在Apps.js中考慮掉所有hardcode在程式碼中的?Config調用，手動配置各種Config的新的Config
                            //一般如果在前端hardcode config后，那一般這支程式不用在移植，移植應該會重寫
                            //程式代碼中不能直接使用Config或App這種，除非那種明顯查不同service的情況?

                            //程式碼中如果直接使用App，則App優先最高，外面動態的影響不了它
                            //程式碼中如果使用Config，則使用Config * App.Config。(還是不要了，不這么復雜!)
                            AppEventHanlder.Instance.SetServiceVar("Config", appConfig);
                        }
                    }
                    */
                }
                //把PermissionCall就看成一個新的Session，所以都要清空ServiceVarContent
                //多個service批次call,第一個不影響第二個
                else if (type == CallType.PermissionCall)
                {
                    AppEventHanlder.Instance.SetServiceVarContent(null);
                }


                int dotIndex = service.LastIndexOf(".");
                if (dotIndex <= 0 || dotIndex >= service.Length - 1)
                    throw new ApplicationException("Invalid service:" + service);
                string serviceId = service.Substring(0, dotIndex);
                string command = service.Substring(dotIndex + 1);
                //TODO:應該讓permissionCall先判斷一下權限，要不一直在實例化對象
                object serviceObj = ObjectFactory.Default.Get(serviceId);
                if (serviceObj == null)
                    throw new ApplicationException("Service not found:" + serviceId);

                beforeJIHEReport(service, args);
                recordCallInfo(service, args);

                if (type == CallType.PermissionCall)//"0")
                    return permissionCall(serviceObj, serviceId, command, args);
                else if (type == CallType.TransactionCall)//"1")
                    return transactionCall(serviceObj, serviceId, command, args);
                else
                    return baseCall(serviceObj, serviceId, command, args);
            }
            finally
            {
                finishJIHEReport(service, args);
            }
        }

        //權限驗證
        protected virtual object permissionCall(object serviceObj, string serviceId, string command, params object[] args)
        {
            string objKind = "Ajax";
            /*
            string objId1 =  serviceId + ".*";
            string objId2 =  serviceId + "." + command;
            //需要權限(避免UserID的無謂取值)
            if(!(RightsProvider.Instance.NoNeedRight(objKind,objId1)
                ||RightsProvider.Instance.NoNeedRight(objKind,objId2)))
            {
                string userId = AuthenticateHelper.Instance.UserID;
                //沒有權限
                if (!(RightsProvider.Instance.HasRight(userId, objKind, objId1)
                    || RightsProvider.Instance.HasRight(userId, objKind, objId2)))
                {
                    if (userId == null)
                        throw new PCINeedLoginException(objKind + "." + objId2);
                    else
                        throw new PCINoPermissionException(userId + ":" +objKind + "." + objId2);
                }
            }
            */
            /*
            string objId2 = serviceId + "." + command;
            //需要權限(避免UserID的無謂取值)
            if (!RightsProvider.Instance.NoNeedRight(objKind, objId2))
            {
                string userId = AuthenticateHelper.Instance.UserID;
                //沒有權限
                if (!(RightsProvider.Instance.HasRight(userId, objKind, objId2)))
                {
                    if (userId == null)
                        throw new PCINeedLoginException(objKind + "." + objId2);
                    else
                        throw new PCINoPermissionException(userId + ":" + objKind + "." + objId2);
                }
            }
            */
            string objId = serviceId + "." + command;
            string userId = AuthenticateHelper.Instance.UserID;
            string userIP = AppEventHanlder.Instance.UserHost;
            Tool.Trace("Right_Ajax", "service", objId);
            if (
                !RightsProvider.Instance.HasServiceRight("Service", serviceId, userIP, userId)
                && !RightsProvider.Instance.HasServiceRight(objKind, objId, userIP, userId))
            {
                if (userId == null)
                    throw new PCINeedLoginException(objKind + "." + objId);
                else
                    throw new PCINoPermissionException(userId + ":" + objKind + "." + objId);
            }

            return transactionCall(serviceObj, serviceId, command, args);
        }

        //默認事務處理
        protected virtual object transactionCall(object serviceObj, string serviceId, string command, params object[] args)
        {
            DBHelper.Instance.SetDefaultTran();
            try
            {
                object ret = baseCall(serviceObj, serviceId, command, args);
                PCIWeb.DDD.DomainContext.Instace.Submit();
                //if (AppEventHanlder.Instance.UserHost != "172.19.6.86")
                    DBHelper.Instance.CommitTran();
                //if (AppEventHanlder.Instance.UserHost == "172.19.6.86")
                //    DBHelper.Instance.RollbackTran();
                //DealOtherDeal();
                //2011.10.19 改到CommitTran中執行
                //if (HttpContext.Current.Items["__OTHERDEALS"] != null && HttpContext.Current.Items["__OTHERDEALS"].ToString() == "1")
                //    dealAllEx(false);    //啟動執行處理序(已經在執行則不會執行)
                //如果剛好在這里中斷的話，就麻煩了？特別是有好多的DealOtherDeal時，可能丟掉好多
                //另外還有按順序進行的問題？如第一關出錯，第二關正常，有可能程式沒有想到第二關比第一關先到?
                return ret;
            }
            catch
            {
                PCIWeb.DDD.DomainContext.Instace.Reset();
                DBHelper.Instance.RollbackTran();
                throw;
            }
        }

        //為了簡單起見，暫時不做注入
        protected virtual object baseCall(object serviceObj, string serviceId, string command, params object[] args)
        {
            try
            {
                /*
                //為了不影響args參數（會序列化到client端，這里抓一下是否有上傳上來的組件）
                object[] callArgs = args;
                HttpFileCollection files = ClientTool.GetUploadTmp();
                if (files != null)
                {
                    callArgs = new object[args.Length + 1];
                    args.CopyTo(callArgs, 0);
                    callArgs[args.Length] = files;
                }
                */
                if (serviceObj is IService)
                {
                    return (serviceObj as IService).Call(command, args);
                }
                else
                {
                    return serviceObj.GetType().InvokeMember(
                        command
                        , BindingFlags.Default | BindingFlags.InvokeMethod
                        , null
                        , serviceObj
                        , args);
                }
            }
            catch (TargetInvocationException tex)
            {
                Exception innerEx = tex.InnerException;
                if (innerEx is PCINeedLoginException
                    || innerEx is PCINoPermissionException
                    || innerEx is PCINotAvailableException
                    || innerEx is PCIBusException)
                    throw innerEx;
                else if (innerEx is ApplicationException)
                {
                    throw new ApplicationException("服務方法出錯" + serviceId + "." + command + ":" + innerEx.Message, innerEx.InnerException == null ? null : innerEx.InnerException);
                }
                else
                {
                    throw new ApplicationException("服務方法出錯" + serviceId + "." + command, innerEx);
                }
                //throw innerEx;
                /*
                if (innerEx is PCIBusException)
                    Tool.Warn("反射調用出錯[內部](用戶錯誤)", "Message", innerEx.Message);      //再拋好像堆疊會丟掉，所以在這里記錄一下
                else
                    Tool.Error("反射調用出錯[內部]", "innerEx", innerEx);      //再拋好像堆疊會丟掉，所以在這里記錄一下
                throw new ApplicationException("反射調用出錯(內部)");
                */
            }
            catch (MissingMethodException ex)
            {
                string argInfo = "";
                if (args != null)
                {
                    foreach (object arg in args)
                        argInfo += (argInfo.Length > 0 ? "," : "") + (arg == null ? "null" : arg.GetType().Name);
                }
                //Tool.Error("反射調用失敗，未找到方法" ,"類.方法名",ex.Message,"參數",argInfo);
                throw new ApplicationException("反射調用失敗，未找到方法:" + ex.Message + " 參數:" + argInfo);
            }
        }

        #endregion

        #region 異種事務處理方式(對PermissionCall的增值，解決各種不同處理的事務一致)

        /*
         * 每一次Service呼叫，包括一次主流transaction和其它種類的處理(如其它資料庫交換，文件處理，郵件發送等)
         * 主流transaction成功commit后，再依次執行其它種類處理
         * 如果失敗，則記錄到全域，以便管理員手動重啟
         * 并記錄原始呼叫方式
         */

        //這里容易寫錯，忘記傳BatchID，所以直接用陣列，提醒調用方注意
        public void AddOtherDeal(string[] serviceInfo, params object[] args)
        {
            string service = serviceInfo[0];
            string batchID = serviceInfo[1];
            //string db = "Flow";
            //if (serviceInfo.Length > 2)
            //{
            //    //沒辦法，只能手動指定，因為AddOtherDeal可能先于所有數據庫執行命令先行
            //    //TODO:為防止以后在AddOtherDeal時指定資料庫
            //    //可對于AddOtherDeal所用的事務ID與其它事務ID比較
            //    //kevin.zou 2011.11.30 注
            //    db = serviceInfo[2];
            //    HttpContext.Current.Items["__OTHERDEALS_DB"] = db;
            //}
            Tool.Trace("加入異步處理", "service", service, "batchID", batchID);//, "db", db);
            //HttpContext.Current.Items["__OTHERDEALS"] = "1";
            insertEx(service, args, batchID);//, db);
        }

        string exTable = "WEB_META_EXRECORD";

        public void DealOtherDeal(string db,string tranID)
        {
            //if (HttpContext.Current.Items["__OTHERDEALS"] != null && HttpContext.Current.Items["__OTHERDEALS"].ToString() == "1")
            //{
                db = db ?? "Flow";
                //string db = HttpContext.Current.Items["__OTHERDEALS_DB"] == null ? "Flow" : HttpContext.Current.Items["__OTHERDEALS_DB"].ToString();
                //HttpContext.Current.Items["__OTHERDEALS"] = "0";
                //T O D O：這里要order by一下，要不然同一次事務中，有兩個相同的batch，可能后面的先被抓出來
                //OK.2012.5.24 用DataView的Sort屬性完成
                DataSet ds = DBHelper.Instance.Query("Select_" + exTable + "@" + db, Tool.ToDic("REQUEST_ID", AppEventHanlder.Instance.RequestID,"TRAN_ID",tranID));
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    ds.Tables[0].DefaultView.Sort = "EX_ID asc";
                    DataView dv = ds.Tables[0].DefaultView;
                    dv.Sort = "EX_ID asc";
                    DataTable dt2 = dv.ToTable();
                    Tool.Info("開始執行批次事務處理", "db", db, "tranID", tranID);   
                    foreach (DataRow dr in dt2.Rows)
                    {
                        string retryInfo = retry(dr, db,tranID);
                        if (retryInfo.Length > 0)
                            Tool.Warn("事務處理后的異種事務失敗", "Info", retryInfo);
                    }
                    Tool.Info("執行批次事務處理完成", "db", db, "tranID", tranID);   
                    //DealOtherDeal();        //循環，可能Retry后，又有東東AddOtherDeal了，所以要一直循環處理
                }
            //}
        }

        public string Retry(string exID, string db)
        {
            DBHelper.Instance.ClearDefaultTran();
            DataSet ds = DBHelper.Instance.Query("Select_" + exTable + "@" + db, Tool.ToDic(
                "EX_ID", exID
            ));
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count == 1)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                string errMsg = retry(dr, db,"");
                if (errMsg.Length > 0)
                    throw new PCIBusException(errMsg);
                else
                    return "重試成功";
            }
            else
                throw new PCIBusException("未找到(或有多筆)異常處理:" + exID);
        }

        string retry(DataRow dr, string db,string tranID)
        {
            string exID = dr["EX_ID"].ToString();
            string batchID = dr["EX_BATCH_ID"].ToString();
            if (batchID.Length > 0)
            {
                DataSet ds2 = DBHelper.Instance.Query("Select_" + exTable + "@" + db, Tool.ToDic(
                    "EX_ID__L", exID     //小于這個ID
                    , "EX_BATCH_ID", batchID
                ));
                if (ds2 != null && ds2.Tables.Count > 0 && ds2.Tables[0].Rows.Count > 0)
                {
                    //Tool.Trace("該批次還有更早的Ex未執行成功，因此不能執行", "ExID", exID, "BatchID", batchID, "Count", ds2.Tables[0].Rows.Count
                    //    , "第1筆ExID", ds2.Tables[0].Rows[0]["ExID"].ToString());
                    return "該批次還有更早的Ex未執行成功，因此不能執行(BatchID:" + batchID + ",筆數:" + ds2.Tables[0].Rows.Count + ",第1筆ID:" + ds2.Tables[0].Rows[0]["EX_ID"].ToString() + ")";
                }
            }

            string errMsg = "";
            try
            {
                retryEx(dr,db,tranID);
            }
            catch (Exception ex)
            {
                errMsg = "重試失敗:" + ex.ToString();// Message;
            }

            if (errMsg.Length == 0)
            {
                try
                {
                    Tool.Trace("開始刪除異種處理執行序列", "ExID", exID);
                    deleteEx(exID, db);
                    Tool.Trace("刪除異種處理執行序列完畢", "ExID", exID);
                    return "";
                }
                catch (Exception ex2)
                {
                    //Tool.Error("重試成功，但刪除失敗(！*請注意*：請執行忽略或手動刪除資料，否則可能會重複執行！)", "exID", exID, "ex2", ex2);
                    return "重試成功，但刪除失敗(！*請注意*：請執行忽略或手動刪除資料，否則可能會重複執行！):" + ex2.Message;
                }
            }
            else
            {
                try
                {
                    Tool.Trace("開始更新異種處理執行序列", "ExID", exID);
                    updateEx(exID, errMsg, int.Parse(dr["TRY_COUNT"].ToString()), db);
                    Tool.Trace("更新異種處理執行序列完畢", "ExID", exID);
                    return errMsg;
                }
                catch (Exception ex2)
                {
                    //Tool.Info("重試失敗，記錄失敗(沒關係，可以手動重新執行)", "exID", exID, "ex2", ex2);
                    return "重試失敗，記錄失敗(沒關係，可以手動重新執行):" + ex2.Message;
                }
            }
        }

        public string Ignore(string exID, string db)
        {
            try
            {
                deleteEx(exID, db);     //錯誤的話，直接會正常的Exception回去
                return "忽略成功，已刪除";
            }
            catch (Exception ex)
            {
                throw new PCIBusException("刪除Ex失敗:" + ex.Message);     //轉成PCIBusException,表示是用戶邏輯失敗
            }
        }

        string retryEx(DataRow dr,string db,string tranID)
        {
            string exID = dr["EX_ID"].ToString();
            string service = dr["SERVICE"].ToString();
            string jsonArgs = dr["ARGS"].ToString();
            ArrayList argsList = Tool.ToList(jsonArgs);
            object[] args = null;
            if (argsList != null)
            {
                args = new object[argsList.Count];
                argsList.CopyTo(args);
            }
            Tool.Info("開始執行異種處理", "tranID", tranID, "ExID", exID, "service", service);
            updateExStart(exID, db);
            call(CallType.TransactionCall, service, args);
            Tool.Info("異種處理執行完畢", "tranID", tranID, "ExID", exID, "service", service);

            return exID;
        }

        void insertEx(string service, object[] args, string batchID)//, string db)
        {
            //不要try.catch，因為是在統一的transactionCall里面
            string exID = IdGenerator.Instance.NextNo("EX", "DealingException");
            string argsJson = Tool.ToJson(args);

            List<Dictionary<string, object>> otherDeals = HttpContext.Current.Items["__OTHERDEALS"] as List<Dictionary<string, object>>;
            if (otherDeals == null)
            {
                HttpContext.Current.Items["__OTHERDEALS"] = otherDeals = new List<Dictionary<string, object>>();
            }
            otherDeals.Add(Tool.ToDic(
                "EX_ID", exID
                , "EX_BATCH_ID", batchID      //批次執行ID，同一ID需按時間先后順序執行
                , "SERVICE", service
                , "ARGS", argsJson
                , "TRY_COUNT", 0          //0執行了幾次
                , "EX_TIME", DateTime.Now.ToString("yyyyMMddHHmmss")
                , "EX_MSG", "待Job執行(Waiting Job Execute)"
                , "USER_ID", AuthenticateHelper.Instance.UserID
                , "REQUEST_IP", AppEventHanlder.Instance.UserHost
                , "REQUEST_ID", AppEventHanlder.Instance.RequestID
            ));

        }

        public void ClearEx()
        {
            HttpContext.Current.Items["__OTHERDEALS"] = null;
        }

        public bool HaveEx()
        {
            return HttpContext.Current.Items["__OTHERDEALS"] != null;
        }

        public bool SaveEx(string db,string tranID)
        {
            bool ret = false;
            List<Dictionary<string, object>> otherDeals = HttpContext.Current.Items["__OTHERDEALS"] as List<Dictionary<string, object>>;
            if (otherDeals != null && otherDeals.Count>0)
            {
                if (tranID == null || tranID=="")
                    throw new ApplicationException("有異種處理，但是執行了ClearDefaultTran，請檢查代碼");
                ret = true;
                db = db ?? "Flow";      //默認資料庫Flow
                foreach(Dictionary<string,object> dic in otherDeals)
                {
                    dic["TRAN_ID"] = tranID;
                    DBHelper.Instance.Execute("Insert_" + exTable + "@" + db, dic);
                }
                HttpContext.Current.Items["__OTHERDEALS"] = null;
            }
            return ret;
            //HttpContext.Current.Items["__OTHERDEALS"] = "1";
        }

        void deleteEx(string exID, string db)
        {
            Dictionary<string, object> args = Tool.ToDic(
                "EX_ID", exID
            );
            DBHelper.Instance.NoUseDefaultTran(args);
            DBHelper.Instance.Execute("Delete_" + exTable + "@" + db, args);
        }

        void updateEx(string exID, string errInfo, int tryCount, string db)
        {
            Dictionary<string, object> args = Tool.ToDic(
                "EX_ID__W", exID
                , "TRY_TIME", DateTime.Now.ToString("yyyyMMddHHmmss")
                , "TRY_COUNT", tryCount + 1
                //第一次錯誤（可能是程式原始執行的錯誤，應該和后面重試時的錯誤分開來）
                , tryCount == 0 ? "EX_MSG" : "TRY_MSG", errInfo.Length > 200 ? errInfo.Substring(0, 190) : errInfo
            );
            DBHelper.Instance.NoUseDefaultTran(args);
            DBHelper.Instance.Execute("Update_" + exTable + "@" + db, args);
        }

        void updateExStart(string exID, string db)
        {
            Dictionary<string, object> args = Tool.ToDic(
                "EX_ID__W", exID
                , "TRY_TIME", DateTime.Now.ToString("yyyyMMddHHmmss")
                //第一次錯誤（可能是程式原始執行的錯誤，應該和后面重試時的錯誤分開來）
                , "TRY_MSG", "START_EXEC_TRAN_" + AppEventHanlder.Instance.RequestID
            );
            DBHelper.Instance.NoUseDefaultTran(args);
            DBHelper.Instance.Execute("Update_" + exTable + "@" + db, args);
        }

        #endregion

        #region 為避免design過度，暫時hardcode的代碼，如果以后還有更多的，再看是否需要重構

        int _jiheReportServiceCount = 0;        //稽核報表使用的人數
        static object _lockJIHE = new object();

        /// <summary>
        /// 稽核報表的procedure，因為計算特別耗費時間（每一次要2分鐘，因此如果不控制，則連線會被用光，造成小服務無法使用連線而全部崩潰)
        /// 因此需要控制其數量，即同時使用服務的人員只能是2個，超過兩個則報錯，告知暫不可使用服務
        /// </summary>
        void beforeJIHEReport(string service, object[] args)
        {
            if (service == "ClientTool.Query" && args != null && args.Length > 0 && args[0] != null)
            {
                ArrayList jiheCmds = SystemConfig.Instance.Get<ArrayList>("JIHE_Report.sqls");
                if (jiheCmds != null)
                {
                    int jiheCount = SystemConfig.Instance.Get<int>("JIHE_Report.count");
                    if (jiheCmds.IndexOf(args[0].ToString().ToUpper().Trim()) >= 0)
                    {
                        bool isMax;
                        int curCount;
                        lock (_lockJIHE)
                        {
                            curCount = ++_jiheReportServiceCount;
                            isMax = _jiheReportServiceCount > jiheCount;
                        }
                        if (isMax)
                        {
                            Tool.Warn("稽核報表忙碌信息", "service", args[0].ToString().ToUpper().Trim(), "當前訪問數", curCount, "允許訪問數", jiheCount);
                            throw new PCIBusException("program is busy,please try again later(maybe after 2 minutes)(稽核報表程式忙碌中，請2分鐘后再試!)");
                        }
                        Tool.Trace("稽核報表請求", "service", args[0].ToString().ToUpper().Trim(), "當前稽核報表訪問數", curCount, "允許訪問數", jiheCount);
                    }
                }
            }
        }

        void finishJIHEReport(string service, object[] args)
        {
            if (service == "ClientTool.Query" && args != null && args.Length > 0 && args[0] != null)
            {
                ArrayList jiheCmds = SystemConfig.Instance.Get<ArrayList>("JIHE_Report.sqls");
                if (jiheCmds != null)
                {
                    int jiheCount = SystemConfig.Instance.Get<int>("JIHE_Report.count");
                    if (jiheCmds.IndexOf(args[0].ToString().ToUpper().Trim()) >= 0)
                    {
                        lock (_lockJIHE)
                        {
                            _jiheReportServiceCount--;
                            Tool.Trace("稽核報表請求完成", "service", args[0].ToString().ToUpper().Trim(), "完成后的稽核報表訪問數", _jiheReportServiceCount);
                        }
                    }
                }
            }
        }


        void recordCallInfo(string service, object[] args)
        {
            if (service == "ClientTool.Query" && args != null && args.Length > 0 && args[0] != null)
            {
                string dbcommand = args[0].ToString();
                string programName = SystemConfig.Instance.Get<string>("SERVICE_USE_ANALYSE.DBCommand." + dbcommand);
                if (programName != null)
                {
                    DBHelper.Instance.Execute("Insert_RequestLog@Flow", Tool.ToDic(
                        "RequestIP", AppEventHanlder.Instance.UserHost
                        , "UserID", AuthenticateHelper.Instance.UserID
                        , "Program", programName
                        , "RequestTime", DateTime.Now.ToString("yyyyMMddHHmmss")
                        , "Service", dbcommand
                        ));
                }
            }
        }

        #endregion
    }
}