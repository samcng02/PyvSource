using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using PCIWeb.Tools;

namespace PCIWeb.Message
{
    public class AddressBook:IAddressBook
    {

        public string Kind
        {
            get { return ""; }
        }

        public Dictionary<string, string> GetAddressBook(string userID)
        {
            //Dictionary<string, string> retTest = new Dictionary<string, string>();
            //retTest.Add("Mail", "Kevin.zou@pci.co.id");
            //retTest.Add("SMS", "085880336381");
            //retTest.Add("PccMessenger", "850.00");
            //retTest.Add("SiteMsg", "850.00");
            //return retTest;

            Dictionary<string, object> args = new Dictionary<string, object>();
            args.Add("UserID", userID);
            DataSet ds = DBHelper.Instance.Query("Common_User_Query", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                Dictionary<string, string> ret = new Dictionary<string, string>();
                if(dr["Email"]!=null && dr["Email"] != DBNull.Value && dr["Email"].ToString().Length>0)
                    ret.Add("Mail", dr["Email"].ToString());
                if (dr["TelNo"] != null && dr["TelNo"] != DBNull.Value && dr["TelNo"].ToString().Length > 0)
                    ret.Add("SMS", dr["TelNo"].ToString());
                ret.Add("PccMessenger", userID);
                ret.Add("SiteMsg", userID);
                return ret;
            }
            return null;
        }

    }
}