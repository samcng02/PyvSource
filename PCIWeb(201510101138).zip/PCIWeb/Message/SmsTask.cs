using System;

namespace PCIWeb.Message
{

    public class SmsTask
    {
        /// <summary>
        /// user id
        /// </summary>
        public string User;

        /// <summary>
        /// ����key(�ѼƫO�s)
        /// </summary>
        public string Key;

        /// <summary>
        /// ²�T���e
        /// </summary>
        public string Content;

    }

}