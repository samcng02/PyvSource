using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using PCIWeb.Tools;

namespace PCIWeb.Message
{

    #region old(�w�`��)

    /*
    public class Center
    {
        //IOC�̿�`�J
        public Center(List<IMsgSource> sources
            , List<IMsgDestination> destinations
            , IMsgSubscribe msgSubscribe
            , List<IAddressBook> addressBooks
            , ILog log
            )
        {
            _log = log;
            _sources = sources;
            init(destinations, msgSubscribe, addressBooks, log);
        }

        ILog _log;
        List<IMsgSource> _sources;

        void init(List<IMsgDestination> destinations
            , IMsgSubscribe msgSubscribe
            , List<IAddressBook> addressBooks
            , ILog log)
        {
            foreach (IMsgSource source in _sources)
            {
                source.Destinations = destinations;
                source.MsgSubscribe = msgSubscribe;
                source.AddressBooks = addressBooks;
                source.Log = log;
            }
        }

        public void ReceiveSend()
        {
            _log.Info("Begin Receive");
            foreach (IMsgSource source in _sources)
            {
                //�����ưȳB�z�A�]���C�@�B���O��W��
                //1.Update N �� S
                //2.Select S
                //3.Update S �� Y
                //�o�T�B���i�H����ɭԳQUpdate�^N�A�o�˦Z����B�����|����
                //�A�`�G�]���A�Ψ�mail,sms,pcc messenger�Msite msg table����ƳB�z
                //�]���٬O�n�`�N�ưȳB�z
                //�n���զb���H�����P�ɡA�p�Guser�b�B�z��ơA�O���ݡA�����٬O�������ѳ���
                PCIWeb.Tools.DBHelper.Instance.SetDefaultTran();
                try
                {
                    source.ReceiveSend();
                    PCIWeb.Tools.DBHelper.Instance.CommitTran();
                }
                catch (Exception ex)
                {
                    PCIWeb.Tools.DBHelper.Instance.RollbackTran();
                    PCIWeb.Tools.Tool.Error("Exception:{0}", ex);
                }
            }
            _log.Info("Receive Finish");
        }

    }

    public interface ILog
    {
        void Error(string msg);
        void Warn(string msg);
        void Info(string msg);
        void Debug(string msg);
    }



    public interface IMsgSource
    {
        void ReceiveSend();

        string Kind { get;}

        ILog Log { set;}

        //�Τ@�q�\���O�A��User�ҥΡA�n��UI
        IMsgSubscribe MsgSubscribe { set;}

        //�Τ_�X�i�]���L����ܡA�ȮɨS���o�˪��ݨD�^
        //�]���ثe����A�ڭ̪��t�εo�e�������A�u�o�e�������User
        //�i�H��ҡA�O�_���H���o�e��Exchange User��ERP�W?
        List<IAddressBook> AddressBooks { set;}

        //���������覡(Mail,SMS,Pcc Messenger,Site Msg)
        List<IMsgDestination> Destinations { set;}

    }

    public abstract class AbstractMsgSource : IMsgSource
    {

        #region interface��k

        ILog _log;
        public ILog Log { set { _log = value; } }

        IMsgSubscribe _msgSubscribe;
        public IMsgSubscribe MsgSubscribe { set { _msgSubscribe = value; } }

        Dictionary<string, IAddressBook> _addressBooks = new Dictionary<string, IAddressBook>();
        public List<IAddressBook> AddressBooks
        {
            set
            {
                _addressBooks.Clear();
                if (value != null && value.Count > 0)
                {
                    foreach (IAddressBook addressBook in value)
                        _addressBooks.Add(addressBook.Kind, addressBook);
                }
            }
        }

        Dictionary<string, IMsgDestination> _destinations = new Dictionary<string, IMsgDestination>();
        public List<IMsgDestination> Destinations
        {
            set
            {
                _destinations.Clear();
                if (value != null && value.Count > 0)
                {
                    foreach (IMsgDestination destination in value)
                        _destinations.Add(destination.Kind, destination);
                }
            }
        }


        public void ReceiveSend()
        {
            _log.Debug("Receive " + Kind);
            List<Msg> msgs = receiveMsgs();
            if (msgs != null && msgs.Count > 0)
            {
                _log.Info(Kind + " Receive " + msgs.Count.ToString() + " Msg(s)");
                foreach (Msg msg in msgs)
                    sendMsg(msg);
            }
            else
                _log.Debug("No Msg Received");
            recieveMsgsOK();
            _log.Debug("Receive " + Kind + " OK");

        }

        #endregion

        #region abstract ��k

        public abstract string Kind { get;}

        //���浦���bSource���t�XTable����
        //�p�Y�ɳq�����A�i�H��ɶ��P���e�ɶ��j�_5������,��S,�M���Y
        //�ʿ쪺�A��@�Ѫ��A�M��]�w�̦Z�@���ʿ쪺�ɶ��]�C�Ѷʿ�@���^
        protected abstract List<Msg> receiveMsgs();

        protected abstract void recieveMsgsOK();

        protected abstract string formatMsg(string lang, string destinationKind, object data,Dictionary<string,object> sendOptions);

        #endregion

        #region �p����k

        Dictionary<string, string> getAddresses(string user)
        {
            string[] tmp = user.Split(new char[] { '#' }, 2);
            string userID = tmp[0];
            string userKind = "";
            if (tmp.Length == 2)
                userKind = tmp[1];
            if (_addressBooks.ContainsKey(userKind))
                return _addressBooks[userKind].GetAddressBook(userID);
            return null;
        }

        Dictionary<string, List<string>> getSendAddress(Msg msg)
        {
            Dictionary<string, List<string>> kindUserAddress = new Dictionary<string, List<string>>();

            foreach (string recUser in msg.RecUsers)
            {
                //���user���q�T���T��
                Dictionary<string, string> recUserAddress = getAddresses(recUser);

                if (recUserAddress != null)
                {
                    //���user���q�\���p
                    string lang;
                    List<string> sendKinds = _msgSubscribe.GetSubscribe(Kind, recUser, out lang);
                    if (sendKinds != null && sendKinds.Count > 0)
                    {
                        foreach (string sendKind in sendKinds)
                        {

                            string sendKey = lang + "_" + sendKind;

                            //�p�GUser���o�صo�e�覡���a�}(�pIP,UserID,Email,���)
                            if (recUserAddress.ContainsKey(sendKind))
                            {
                                if (!kindUserAddress.ContainsKey(sendKey))
                                    kindUserAddress.Add(sendKey, new List<string>());
                                kindUserAddress[sendKey].Add(recUserAddress[sendKind]);
                            }
                            else
                                _log.Warn("No Send Kind(" + recUser + "," + sendKind + ")");
                        }
                    }
                    else
                        _log.Warn("No Any Subscribe Kind(" + recUser + "," + Kind + ")");
                    //�o���n���� User �S���q�\����q���覡
                }
                else
                    _log.Warn("No User Address Found(" + recUser + ")");
            }
            return kindUserAddress;
        }

        void sendMsg(Msg msg)
        {
            //���P�����������o�e�q�T��
            Dictionary<string, List<string>> kindUserAddress = getSendAddress(msg);
            if (kindUserAddress.Count == 0)
                _log.Warn("No Any Receive Address Found!");  //�]���e�����@��log.Info����Kind�A�]���o����Msg�����ݭnsource kind�F
            else
            {
                        Dictionary<string,object> sendOptions = new Dictionary<string,object>();
                foreach (string sendKey in kindUserAddress.Keys)
                {
                    string[] tmp = sendKey.Split(new char[] { '_' }, 2);
                    string lang = tmp[0];
                    string sendKind = tmp[1];
                    sendOptions.Clear();
                  string sendMsg  = formatMsg(lang, sendKind, msg.Data,sendOptions);
                  if (_destinations.ContainsKey(sendKind))
                      _destinations[sendKind].Send(kindUserAddress[sendKey], sendMsg, Kind,sendOptions);
                  else
                      _log.Warn("No Msg Destination Found(" + sendKind + ")");
                }
            }
        }

        #endregion
    }
    */

    #endregion

    public struct Msg
    {

        public string Key;

        //�Ȯɤ����䥦�����O���o�e�A�u�o�e���t�ΥΤ�
        //�p�G�H�Z�n�X�i��o�e�䥦�Τ�A�pERP�t��,Exchange�ΪF��A�x�W�A�h�aUser���A�pKevin.zou@PCI_Exchange
        public string RecUser;

        //�����ǥX�H����(�i������榡)
        public object Data;
    }

    public interface IAddressBook
    {
        string Kind { get;}

        Dictionary<string, string> GetAddressBook(string userID);
    }

    public interface IMsgSubscribe
    {
        List<string> GetSubscribe(string kind, string recUser, out string lang);
    }

    public abstract class AbstractMsgSender
    {

        #region abstract��k

        protected abstract string msgDb { get;}
        protected abstract string kind { get;}
        protected abstract string formatMsg(string lang, string destinationKind, object data, Dictionary<string, object> sendOptions);

        protected virtual string subscribeKind
        {
            get
            {
                return kind;
            }
        }
        #endregion

        #region �o�e����

        public virtual string Send(object data, string recUser)
        {
            string ret = "";

            //���P�����������o�e�q�T��
            string lang = "";
            Dictionary<string, string> sendAddress = getSendAddress(recUser,out lang);
            if (sendAddress ==null)
            {
                ret = "No Any Receive Address Found!";
                //Tool.Warn(ret);  //�]���e�����@��log.Info����Kind�A�]���o����Msg�����ݭnsource kind�F
            }
            else
            {
                Dictionary<string, object> sendOptions = new Dictionary<string, object>();
                foreach (string sendKind in sendAddress.Keys)
                {
                    sendOptions.Clear();
                    string sendMsg = formatMsg(lang, sendKind, data, sendOptions);
                    addWaitForSending(sendKind,sendAddress[sendKind],sendMsg,kind,sendOptions);
                }
            }
            return ret;
        }

        #region �p����k

        protected virtual Dictionary<string, string> getAddresses(string user)
        {
            string userID = user;
            string userKind = "";
            int index = user.LastIndexOf('@');
            if (index > 0)
            {
                userID = user.Substring(0, index);
                userKind = user.Substring(index);
            }
            if (addressBooks.ContainsKey(userKind))
                return addressBooks[userKind].GetAddressBook(userID);
            return null;
        }

        protected virtual Dictionary<string, string> getSendAddress(string recUser,out string lang)
        {
            Dictionary<string, string> ret = null;
            
            //���user���q�\���p
            List<string> sendKinds = subscribe.GetSubscribe(subscribeKind, recUser, out lang);
            if (sendKinds != null && sendKinds.Count > 0)
            {
                Dictionary<string, string> recUserAddress = getAddresses(recUser);
                if (recUserAddress != null)
                {
                    foreach (string sendKind in sendKinds)
                    {

                        //�p�GUser���o�صo�e�覡���a�}(�pIP,UserID,Email,���)
                        if (recUserAddress.ContainsKey(sendKind))
                        {
                            if (ret == null)
                                ret = new Dictionary<string, string>();
                            ret.Add(sendKind, recUserAddress[sendKind]);
                        }
                        else
                            Tool.Warn("���q�\�A���O�����ѳo�حq�\���a�}", "recUser", recUser, "sendKind", sendKind);
                    }
                }
                else
                    Tool.Warn("User�q�T�������", "recUser", recUser);
            }
            else   //user�i�H���q�\����覡
                Tool.Warn("User���q�\���󦬨��覡", "recUser", recUser, "kind", kind);
            return ret;
        }

        protected virtual void addWaitForSending(string desKind, string recUser, string msg, string sourceKind, Dictionary<string, object> sendOptions)
        {
            Dictionary<string, object> args = new Dictionary<string, object>();
            string msgID = IdGenerator.Instance.NextNo("MsgSend");
            args.Add("MsgID", msgID);
            args.Add("Content", msg);
            args.Add("AddTime", DateTime.Now.ToString("yyyyMMddHHmmss"));
            args.Add("Status", "NEW");
            args.Add("Source", sourceKind);
            args.Add("Kind", desKind);
            args.Add("RecUser", recUser);
            args.Add("ExpiredDay", expiredDays);
            args.Add("MergeKey",mergeKey);
            args.Add("ContentFormat", contentFormat);
            //DBHelper.Instance.NoLogResult(args);            //���O���A�]���ƾڤ��A�Ψ�_�����ܧ�L�{ kevin.zou 2010.11.25

            DBHelper.Instance.Execute("Insert_Base_MsgSend@" + msgDb, args);
            if (sendOptions != null)
            {
                args.Clear();
                args.Add("MsgID", msgID);
                foreach (string key in sendOptions.Keys)
                {
                    args["Key"] = key;
                    args["Value"] = sendOptions[key].ToString();
                    //DBHelper.Instance.NoLogResult(args);            //���O���A�]���ƾڤ��A�Ψ�_�����ܧ�L�{ kevin.zou 2010.11.25

                    DBHelper.Instance.Execute("Insert_Base_MsgSend_Options@" + msgDb, args);
                }
            }
        }

        #endregion

        #region �q�{�]�m���q�T���A�q�\�ݩ�

        protected virtual string mergeKey
        {
            get
            {
                return "";
            }
        }

        protected virtual string contentFormat
        {
            get
            {
                return "";
            }
        }

        protected virtual int expiredDays
        {
            get
            {
                return -1;      //-1���ܥä��L��
            }
        }

        protected virtual IMsgSubscribe getSubscribe()
        {
            return new MsgSubscribe();
        }

        IMsgSubscribe _subscribe;

        IMsgSubscribe subscribe
        {
            get
            {
                if (_subscribe == null)
                    _subscribe = getSubscribe();
                return _subscribe;
            }
        }

        protected virtual void initAddressBooks(Dictionary<string, IAddressBook> addressBooks)
        {
            addressBooks.Add("",new AddressBook());
        }

        Dictionary<string, IAddressBook> _addressBooks;

        Dictionary<string, IAddressBook> addressBooks
        {
            get
            {
                if (_addressBooks == null)
                {
                    _addressBooks = new Dictionary<string, IAddressBook>();
                    initAddressBooks(_addressBooks);
                }
                return _addressBooks;
            }
        }

        #endregion
        
        #endregion

        #region �������o(�Τ_Job)

        public void ReceiveSend()
        {
            Tool.Trace("�}�l���ͮ���","kind",kind);
            List<Msg> msgs = getMsgs();
            if (msgs != null && msgs.Count > 0)
            {
                Tool.Trace("���o��������","kind",kind ,"count", msgs.Count);
                List<string> keys = new List<string>();
                foreach (Msg msg in msgs)
                {
                    if (!keys.Contains(msg.Key))
                        keys.Add(msg.Key);
                }
                Dictionary<string, List<string>> sendedMsgs = querySendedMsgs(keys);

                int logCount = 0;
                foreach (Msg msg in msgs)
                {
                    if (!sendedMsgs.ContainsKey(msg.Key) || !sendedMsgs[msg.Key].Contains(msg.RecUser))
                    {
                        Send(msg.Data, msg.RecUser);
                        logCount++;
                        recordSendedMsg(msg.Key,msg.RecUser);
                    }
                }

                //if(logCount>0)
                    //Tool.Info("�����ͦ�","kind", kind, "logCount",logCount);

            }
            else
                Tool.Trace("No Msg Received");
            Tool.Trace("�������ͧ���", "kind", kind);
        }

        #region �������Ѯ��������k

        /// <summary>
        /// �p�G�ncall ReceiveSend��k�A��override getMsgs��k
        /// </summary>
        /// <returns></returns>
        protected virtual List<Msg> getMsgs()
        {
            throw new ApplicationException("ReceiveSend��k�եήɡA����override getMsgs()��k");
        }

        #endregion

        #region �������o�e�m����(����Ƶo�e)

        string tranListToString(List<string> keys)
        {
            if (keys != null)
            {
                string ret = "";
                foreach (string key in keys)
                    ret += (ret.Length > 0 ? "," : "") + key;
                return ret;
            }
            return null;
        }

        protected virtual Dictionary<string, List<string>> querySendedMsgs(List<string> keys)
        {
            Dictionary<string, List<string>> ret = new Dictionary<string, List<string>>();
            if (keys != null)
            {
                string strKeys = tranListToString(keys);
                Dictionary<string, object> args = new Dictionary<string, object>();
                args.Add("Kind", kind);
                args.Add("MsgKey__IN", strKeys);
                DataSet ds = DBHelper.Instance.Query("Select_Base_MsgSended@" + msgDb, args);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        string key = dr["MsgKey"].ToString();
                        string recUser = dr["RecUser"].ToString();
                        if (!ret.ContainsKey(key))
                            ret.Add(key, new List<string>());
                        ret[key].Add(recUser);
                    }
                }
            }
            return ret;
        }

        protected virtual void recordSendedMsg(string key, string recUser)
        {
            Dictionary<string, object> args = new Dictionary<string, object>();
            args.Add("Kind", kind);
            args.Add("MsgKey", key);
            args.Add("AddTime", DateTime.Now.ToString("yyyyMMddHHmmss"));
            args.Add("RecUser", recUser);
            //DBHelper.Instance.NoLogResult(args);            //���O���A�]���ƾڤ��A�Ψ�_�����ܧ�L�{ kevin.zou 2010.11.25

            DBHelper.Instance.Execute("Insert_Base_MsgSended@" + msgDb, args);
        }

        #endregion

        #endregion

    }
}