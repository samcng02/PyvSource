using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using PCIWeb.Tools;

namespace PCIWeb.Message
{

    public interface IContentFormat
    {
        string Format(string content);
        string Format(List<string> content);
    }

    /// <summary>
    /// �Τ_Job�B��
    /// </summary>
    public abstract class Sender
    {
        #region abstract��k

        protected abstract bool send(Msg msg,Dictionary<string,object> sendOptions,out string sendInfo);

        protected abstract string kind{get;}

        #endregion

        #region �ѼƳ]�m

        protected virtual string msgDb
        {
            get
            {
                return "Flow";
            }
        }

        protected virtual int maxSendTimes
        {
            get
            {
                return 3;
            }
        }

        protected virtual string msgOpTbl
        {
            get
            {
                return "Base_MsgSend_Options";
            }
        }

        #endregion

        #region �p����k

        //protected Dictionary<string,object> tranDrToDic(DataRow dr)
        //{
        //    Dictionary<string, object> ret = new Dictionary<string, object>();
        //    foreach (DataColumn dc in dr.Table.Columns)
        //        ret.Add(dc.ColumnName, dr[dc]);
        //    return ret;
        //}

        protected Dictionary<string, object> tranDtToDic(DataSet ds,string keyCol,string valueCol)
        {
            if (ds!=null && ds.Tables.Count>0 && ds.Tables[0].Rows.Count>0)
            {
                Dictionary<string, object> ret = new Dictionary<string, object>();
                foreach (DataRow dr in ds.Tables[0].Rows)
                    ret.Add(dr[keyCol].ToString(), dr[valueCol]);
                return ret;
            }
            return null;
        }

        protected Dictionary<string, object> getSendOptions(string msgID)
        {
            Dictionary<string, object> args = new Dictionary<string, object>();
            args.Add("MsgID", msgID);
            return tranDtToDic(DBHelper.Instance.Query("Select_" + msgOpTbl + "@" + msgDb, args),"OKey","Value");
        }

        protected void reportSendResult(string msgID,bool result,string sendInfo)
        {
            Dictionary<string, object> args = new Dictionary<string, object>();
            args.Add("Status", result ? "OK" : "Fail");
            args.Add("MsgID", msgID);
            args.Add("SendTime", DateTime.Now.ToString("yyyyMMddHHmmss"));
            args.Add("SendInfo", sendInfo);
            //�۩w�q��Ʈw
            DBHelper.Instance.SetDB(args,msgDb);
            //DBHelper.Instance.NoLogResult(args);            //���O���A�]���ƾڤ��A�Ψ�_�����ܧ�L�{ kevin.zou 2010.11.25

            DBHelper.Instance.Execute("Msg/Report_Send", args);
        }

        #endregion

        #region Job��k

        protected virtual string mergeContent(List<string> content)
        {
            string ret = "";
            foreach (string con in content)
                ret += (ret.Length > 0 ? "," : "") + con;
            return ret;
        }

        //protected virtual bool mergeSend(List<Msg> msgs, Dictionary<string, object> sendOptions, out string sendInfo)
        protected bool mergeSend(List<Msg> msgs,IContentFormat formatter, Dictionary<string, object> sendOptions, out string sendInfo)
        {
            Msg sendMsg = new Msg();
            sendMsg.Key = "";//msgs[0].Key;
            sendMsg.RecUser = msgs[0].RecUser;

            List<string> content = new List<string>();
            foreach (Msg msg in msgs)
                content.Add(msg.Data.ToString());
            if (formatter == null)
                sendMsg.Data = mergeContent(content);
            else
                sendMsg.Data = formatter.Format(content);
            return send(sendMsg, sendOptions, out sendInfo);
        }

        public void Send()
        {
            //����Http���q�{Transaction,�o�e���\�@���O�@��
            DBHelper.Instance.ClearDefaultTran();

            Dictionary<string, object> args = new Dictionary<string, object>();
            args.Add("MaxSendTimes",maxSendTimes);
            args.Add("Kind",kind);

            //�۩w�q��Ʈw
            DBHelper.Instance.SetDB(args,msgDb);
            DataSet ds = DBHelper.Instance.Query("Msg/Wait_For_Send", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                //�X�}�o�e���ﶵ(key:User_MergeKey List<Dictionary<string,object>> �@��Msg,�@��Option)
                //�X�}�o�e�ɡA�q�{�u�ϥΤ@�ӿﶵ
                Dictionary<string, List<Msg>> mergeMsgs = new Dictionary<string, List<Msg>>();
                Dictionary<string, Dictionary<string, object>> mergeOptions = new Dictionary<string, Dictionary<string, object>>();
                Dictionary<string, IContentFormat> mergeFormatter = new Dictionary<string, IContentFormat>();

                //�Τ_Log�O��
                int logSuccessCount = 0;
                int logFailCount = 0;


                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    Msg msg = new Msg();
                    msg.Key = dr["MsgID"].ToString();
                    msg.RecUser = dr["RecUser"].ToString();
                    msg.Data = dr["Content"].ToString();

                    IContentFormat formatter = null;
                    string contentFormatter = dr["ContentFormat"] as string;
                    if (contentFormatter != null && contentFormatter.Trim().Length > 0)
                    {
                        formatter = ObjectFactory.Default.Get<IContentFormat>(contentFormatter);
                        if (formatter == null)
                            throw new ApplicationException("�����Formatter:" + contentFormatter);
                    }

                    Dictionary<string, object> sendOptions = getSendOptions(msg.Key);

                    string mergeKey = dr["MergeKey"] as string;
                    if (mergeKey != null && mergeKey.Trim().Length > 0)
                    {
                        string sendMergeKey = msg.RecUser + "," + mergeKey;
                        if (!mergeMsgs.ContainsKey(sendMergeKey))
                        {
                            mergeMsgs.Add(sendMergeKey, new List<Msg>());
                            mergeOptions.Add(sendMergeKey, sendOptions);
                            mergeFormatter.Add(sendMergeKey, formatter);
                        }
                        else
                        {
                            if (sendOptions != null)
                            {
                                //�X�}�o�e�ɡA�X�}optinos,�p�Gkey�ȬۦP�A���̦Z�@��
                                if (mergeOptions[sendMergeKey] == null)
                                    mergeOptions[sendMergeKey] = sendOptions;
                                else
                                {
                                    foreach (string key in sendOptions.Keys)
                                        mergeOptions[sendMergeKey][key] = sendOptions[key];
                                }
                            }
                        }
                        mergeMsgs[sendMergeKey].Add(msg);
                    }
                    else
                    {
                        if (formatter != null)
                            msg.Data = formatter.Format(msg.Data.ToString());
                        string sendInfo;
                        bool result = send(msg, sendOptions, out sendInfo);
                        if (result)
                            logSuccessCount++;
                        else
                            logFailCount++;
                        reportSendResult(msg.Key, result, sendInfo);
                    }
                }

                foreach (string sendMergeKey in mergeMsgs.Keys)
                {
                    string sendInfo;
                    bool result = mergeSend(mergeMsgs[sendMergeKey], mergeFormatter[sendMergeKey], mergeOptions[sendMergeKey], out sendInfo);
                    foreach (Msg msg in mergeMsgs[sendMergeKey])
                    {
                        reportSendResult(msg.Key, result, sendInfo);
                        if (result)
                            logSuccessCount++;
                        else
                            logFailCount++;

                    }
                }

                //�u�O�����G
                if (logSuccessCount > 0 || logFailCount > 0)
                    Tool.Info("�����o�e���G", "kind", kind, "logSuccessCount", logSuccessCount, "logFailCount",logFailCount);

            }
            else
                Tool.Trace("�S�������n�o�e", "kind", kind);
        }

        #endregion

        #region �D�ʦ���

        //�D�ʦ�����Log�A�]�������ɶ����H�����b��Ʈw�����O��
        public virtual DataTable Receive(string user)
        {
            Dictionary<string, object> args = new Dictionary<string, object>();
            args.Add("MaxSendTimes", maxSendTimes);
            args.Add("Kind", kind);
            args.Add("RecUser", user);
            //�۩w�q��Ʈw
            DBHelper.Instance.SetDB(args, msgDb);
            DataSet ds = DBHelper.Instance.Query("Msg/Wait_For_Send", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataTable ret = new DataTable();
                ret.TableName = "Table";
                ret.Columns.Add("Content");

                Dictionary<string, List<string>> mergeRows = new Dictionary<string, List<string>>();
                Dictionary<string, IContentFormat> mergeFormatters = new Dictionary<string, IContentFormat>();

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string content = dr["Content"].ToString();

                    IContentFormat formatter = null;
                    string contentFormatter = dr["ContentFormat"] as string;
                    if (contentFormatter != null && contentFormatter.Trim().Length > 0)
                    {
                        formatter = ObjectFactory.Default.Get<IContentFormat>(contentFormatter);
                        if (formatter == null)
                            throw new ApplicationException("�����Formatter:" + contentFormatter);
                    }

                    string mergeKey = dr["MergeKey"] as string;
                    if (mergeKey != null && mergeKey.Trim().Length > 0)
                    {
                        if (!mergeRows.ContainsKey(mergeKey))
                        {
                            mergeRows.Add(mergeKey, new List<string>());
                            mergeFormatters.Add(mergeKey, formatter);
                        }
                        mergeRows[mergeKey].Add(content);
                    }
                    else
                    {
                        DataRow newDr = ret.NewRow();
                        if (formatter != null)
                            newDr["Content"] = formatter.Format(dr["Content"].ToString());
                        else
                            newDr["Content"] = dr["Content"];
                        ret.Rows.Add(newDr);
                    }
                    string msgID = dr["MsgID"].ToString();
                    reportSendResult(msgID, true, "");
                }

                foreach (string key in mergeRows.Keys)
                {
                    string joinContent;
                    if (mergeFormatters[key] == null)
                        joinContent = mergeContent(mergeRows[key]);
                    else
                        joinContent = mergeFormatters[key].Format(mergeRows[key]);

                    DataRow newDr = ret.NewRow();
                    newDr["Content"] = joinContent;
                    ret.Rows.Add(newDr);
                }
                return ret;
            }
            else
                Tool.Trace("�S������", "kind", kind);
            return null;
        }

        #endregion
    }
}