using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using PCIWeb.Tools;

namespace PCIWeb.Message
{
    public class MsgSubscribe:IMsgSubscribe
    {

        public static readonly string DefaultDB = "Flow";

        public MsgSubscribe()
            : this(DefaultDB)
        {

        }

        string _msgDb;

        public MsgSubscribe(string msgDb)
            : this(msgDb,"PccMessenger,SMS,Mail")
        {

        }

        string _defaultKindsStr;

        public MsgSubscribe(string msgDb, string defaultKindsStr)
        {
            _msgDb = msgDb;
            _defaultKindsStr = defaultKindsStr;
        }

        public List<string> GetSubscribe(string kind, string recUser, out string lang)
        {
            lang = "zh-tw";
            /*
            List<string> ret = new List<string>(new string[]{
                "PccMessenger","SMS","Mail"//,"SiteMsg"     //�Ȯɥu�o�o�T��
                });
            */
            List<string> ret = new List<string>(_defaultKindsStr.Split(new char[] { ',' }));

            Dictionary<string, object> args = new Dictionary<string, object>();
            args.Add("Kind",kind);
            args.Add("UserID", recUser);
            DataSet ds = DBHelper.Instance.Query("Select_Base_MsgNotice@" + _msgDb, args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                if (dr["Lang"] != null && dr["Lang"] != DBNull.Value)
                    lang = dr["Lang"].ToString();

                foreach (DataColumn dc in ds.Tables[0].Columns)
                {
                    if (ret.Contains(dc.ColumnName) && dr[dc].ToString() == "N")
                        ret.Remove(dc.ColumnName);
                }
            }
            return ret;
        }

    }
}