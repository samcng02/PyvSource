using System;
using System.Collections.Generic;
using System.Text;
using PCIWeb.Tools;

namespace PCIWeb.Message
{
    public class MailSender : Sender
    {

        public MailSender(string msgDb)
        {
            _msgDb = msgDb;
        }

        string _msgDb;

        protected override string msgDb
        {
            get
            {
                return _msgDb;
            }
        }
        protected override bool send(Msg msg, Dictionary<string, object> sendOptions, out string sendInfo)
        {
            string from = sendOptions != null && sendOptions.ContainsKey("From") ? sendOptions["From"].ToString() : "PCI Web System";
            string to = msg.RecUser;// msg["RecUser"].ToString();
            string body = msg.Data.ToString();// msg["Content"].ToString();
            string subject = sendOptions != null && sendOptions.ContainsKey("Subject") ? sendOptions["Subject"].ToString() : "PCI Web System Notice(PCI Web�t�γq��)";
            string cc = sendOptions != null && sendOptions.ContainsKey("CC") ? sendOptions["CC"].ToString() : "";
            try
            {
                Tool.SendMail(from, subject, to, cc, body, null);
                sendInfo = "";
            }
            catch (Exception ex)
            {
                Tool.Error("�o�e�l�󥢱�", "ex", ex);
                sendInfo = ex.Message;
                return false;
            }
            return true;
        }

        protected override string kind
        {
            get { return "Mail"; }
        }
    }
}
