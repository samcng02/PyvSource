using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using PCIWeb;
using PCIWeb.Tools;

namespace PCIWeb.Message
{

    //TODO:�u���ϥΡA�ӫD�~�� 2011.12.9�`
    public abstract class NewMsgSender
    {

        //�������O
        protected string _kind;
        //���P���Τ���������P���q�T���]�o���u��8.6���ƾڮw�q�T���^
        protected Dictionary<string, IAddressBook> _addressBooks;
        //���P���T���o�e�覡�]mail�Asms�A�����u�H)
        protected Dictionary<string, INewSender> _senders;
        //�Τ᪺�H���q�\�覡�]�Τ�n�έ��Ǥ覡���^
        protected IMsgSubscribe _subscribe;


        public NewMsgSender(string kind)
        {
            _kind = kind;
            initAddressBooks();
            initMsgSenders();
            initSubscribe();
        }

        //�q�{�έ��Ǥ覡
        protected virtual string defaultKindsStr
        {
            get
            {
                return "SiteMsg,SMS,Mail";
            }
        }

        protected virtual void initAddressBooks()
        {
            _addressBooks = new Dictionary<string, IAddressBook>();
            _addressBooks.Add("", new AddressBook());
        }

        protected virtual string batchDb
        {
            get
            {
                return "Flow";
            }
        }

        protected virtual void initMsgSenders()
        {
            _senders = new Dictionary<string, INewSender>();
            _senders.Add("SMS", new NewSmsSender(batchDb));
            _senders.Add("Mail", new NewMailSender(batchDb));
            _senders.Add("SiteMsg", new NewSiteMsgSender());
        }

        protected virtual void initSubscribe()
        {
            _subscribe = new MsgSubscribe(MsgSubscribe.DefaultDB, defaultKindsStr);
        }

        //�y���A���O(mail,²�T,����)�A�ƾڡA�i�H�b�o���]�w�䥦���O
        protected abstract string formatMsg(string lang, string destinationKind, object data, Dictionary<string, object> sendOptions);

        public virtual void Send(string recUser, object data)
        {
            //���P�����������o�e�q�T��
            string lang = "";
            Dictionary<string, string> sendAddress = getSendAddress(recUser, out lang);
            if (sendAddress != null)
            {
                Dictionary<string, object> sendOptions = new Dictionary<string, object>();
                Dictionary<string,object> userInfo =AuthenticateHelper.Instance.GetUserInfo(recUser);
                foreach (string sendKind in sendAddress.Keys)
                {
                    sendOptions.Clear();
                    if(userInfo!=null)
                        sendOptions["UserName"] = userInfo["Name"].ToString();
                    string sendMsg = formatMsg(lang, sendKind, data, sendOptions);
                    if (sendMsg != null)
                    {
                        if (_senders.ContainsKey(sendKind))
                        {
                            INewSender sender = _senders[sendKind];
                            sender.Send(sendAddress[sendKind], sendMsg, _kind, sendOptions);
                        }
                        else
                            Tool.Warn("�S���w�q�o�ثH���覡", "sendKind", sendKind);
                    }
                }
            }
        }

        protected virtual Dictionary<string, string> getSendAddress(string recUser, out string lang)
        {
            return getSendAddress(recUser, _kind, out lang);
        }

        protected virtual Dictionary<string, string> getSendAddress(string recUser, string kind, out string lang)
        {
            Dictionary<string, string> ret = null;

            //���user���q�\���p
            List<string> sendKinds = _subscribe.GetSubscribe(kind, recUser, out lang);
            lang = lang.ToUpper().Trim();   //�ন�j�g
            if (sendKinds != null && sendKinds.Count > 0)
            {
                Dictionary<string, string> recUserAddress = getAddresses(recUser);
                if (recUserAddress != null)
                {
                    foreach (string sendKind in sendKinds)
                    {
                        //�p�GUser���o�صo�e�覡���a�}(�pIP,UserID,Email,���)
                        if (recUserAddress.ContainsKey(sendKind))
                        {
                            if (ret == null)
                                ret = new Dictionary<string, string>();
                            ret.Add(sendKind, recUserAddress[sendKind]);
                        }
                        else
                            Tool.Trace("���q�\�A���O�����ѳo�حq�\���a�}", "recUser", recUser, "sendKind", sendKind);
                    }
                }
                else
                    Tool.Warn("User�q�T�������", "recUser", recUser);
            }
            else   //user�i�H���q�\����覡
                Tool.Trace("User���q�\���󦬨��覡", "recUser", recUser, "kind", kind);
            return ret;
        }

        protected virtual Dictionary<string, string> getAddresses(string user)
        {
            string userID = user;
            string userKind = "";
            int index = user.LastIndexOf('@');
            if (index > 0)
            {
                userID = user.Substring(0, index);
                userKind = user.Substring(index);
            }
            if (_addressBooks.ContainsKey(userKind))
                return _addressBooks[userKind].GetAddressBook(userID);
            return null;
        }

    }

    public interface INewSender
    {
        void Send(string to, string content, string kind, Dictionary<string, object> sendOptions);
    }

    public class NewSmsSender : INewSender
    {

        string _tranDb;

        //���ʧ@�P�D�ưȬۦP�A�o�ˤ~�|�b����ɡA�۰ʶi��OtherDeals�ʧ@
        public NewSmsSender(string tranDb)
        {
            _tranDb = tranDb;
        }

        PCIWeb.Tools.SmsSender smsSender = PCIWeb.Tools.SmsSender.Instance;
        public void SendSms(string phone, string content, string source)
        {
            string name = "";
            string sender = "NewSmsSender";
            smsSender.Send(phone, name, content, source, sender);
            //SendMail(phone, name, content, source, sender);
        }

        public void Send(string to, string content, string kind, Dictionary<string, object> sendOptions)
        {
            string name = "";
            string sender = "NewSmsSender";
            //�o�T���ɡA�u�o�T���A�����䥦�ưȤ����ơA�]���S���Y
            ServiceCaller.Instance.AddOtherDeal(new string[] { "PCIWeb.Tools.SmsSender.Send", "", _tranDb }, to, name, content, kind, sender);
        }
    }

    public class NewMailSender : INewSender
    {

        string _tranDb;

        //���ʧ@�P�D�ưȬۦP�A�o�ˤ~�|�b����ɡA�۰ʶi��OtherDeals�ʧ@
        public NewMailSender(string tranDb)
        {
            _tranDb = tranDb;
        }

        /*
        public void SendMail(string from, string subject, string to, string cc, string body)
        {
            Tool.SendMail(from, subject, to, cc, body, null);
        }
        */

        public void Send(string to, string content, string kind, Dictionary<string, object> sendOptions)
        {
            string from = sendOptions != null && sendOptions.ContainsKey("From") ? sendOptions["From"].ToString() : "PCI Web System";
            string subject = sendOptions != null && sendOptions.ContainsKey("Subject") ? sendOptions["Subject"].ToString() : "PCI Web System Notice(PCI Web�t�γq��)";
            string cc = sendOptions != null && sendOptions.ContainsKey("CC") ? sendOptions["CC"].ToString() : "";
            string body = content;// msg["Content"].ToString();
            ServiceCaller.Instance.AddOtherDeal(new string[] { "PCIWeb.Tools.Tool.SendMail", "", _tranDb }, from, subject, to, cc, body, null);
            /*
            sendInfo = Tool.SendMail(from, subject, to, cc, body, null);
            if (sendInfo.Length > 0)
                return false;
            else
                return true;
            */
        }
    }

    //�Τ�ӤH�H��
    //�i�ί����u�H��Pcc Messenger�w�ɦ���
    public class NewSiteMsgSender : INewSender
    {

        #region INewSender Members

        public void Send(string to, string content, string kind, Dictionary<string, object> sendOptions)
        {
            throw new NotImplementedException();
        }

        #endregion
    }

    /*
    //�H�ZPcc Messenger�p�G�i�H�������e�A�h�γo�إ\��A���L�ثe���G�S���n(kevin.zou 2011.8.12)
    public class NewPMRSender : INewSender
    {
        #region INewSender Members

        public bool Send(string to, string content, string kind, Dictionary<string, object> sendOptions, out string sendInfo)
        {
            throw new NotImplementedException();
        }

        #endregion
    }

    */

    public abstract class FormTaskMsgSender : NewMsgSender
    {

        public FormTaskMsgSender(string kind) :
            base(kind)
        {

        }

        protected override string defaultKindsStr
        {
            get
            {
                return "SMS,Mail";          //�ʿ�H���A�q�{�u�o²�T�Mmail(�]�������u�H�A�|���M�������ȧY�ɮ����i��)
            }
        }

        protected override string formatMsg(string lang, string destinationKind, object data, Dictionary<string, object> sendOptions)
        {
            Dictionary<string, Dictionary<string, DataRow>> tasks = data as Dictionary<string, Dictionary<string, DataRow>>;
            if (tasks != null)
            {
                int count = 0;
                foreach (string task in tasks.Keys)
                {
                    if (tasks[task] != null)
                        count += tasks[task].Count;
                }
                if (count > 0)
                {
                    StringBuilder sb = new StringBuilder();
                    if (destinationKind == "Mail")
                    {
                        sb.AppendFormat("Dear {0} <br>",sendOptions["UserName"]);
                    }
                    sb.Append(sysLangName[lang]);
                    bool isSms = destinationKind == "SMS";
                    sb.Append(isSms ? "\n" : "<br>");
                    sb.AppendFormat(msgContent[lang], count);
                    if (!isSms)
                    {
                        sb.Append("<br><a href='" + otherLink + "'>");
                        sb.Append("�I���o���e��(Click here)");
                        sb.Append("</a>");
                        if (supportNotIE)
                        {
                            sb.Append("<br><br><a href='" + ipadLink + "'>");
                            sb.Append("&gt;&gt;ipad,mobile or not IE,please click here");
                            sb.Append("</a>");
                        }
                    }
                    else
                    {
                        sb.Append("\n");
                        sb.Append(smsLink);
                    }
                    return sb.ToString();
                }
            }
            return null;
        }

        protected virtual Dictionary<string, string> msgContent
        {
            get
            {
                Dictionary<string, string> ret = new Dictionary<string, string>();
                ret.Add("EN", "{0} application waiting for your check.");
                ret.Add("ZH-TW", "��{0}����ڻݭn�z�B�z.");
                return ret;
            }
        }

        protected virtual Dictionary<string, string> sysLangName
        {
            get
            {
                Dictionary<string, string> ret = new Dictionary<string, string>();
                ret.Add("EN", enSysName);
                ret.Add("ZH-TW", cnSysName);
                return ret;
            }
        }

        protected abstract string enSysName { get; }

        protected abstract string cnSysName { get; }

        protected virtual string otherLink
        {
            get
            {
                return "http://" + SystemConfig.Instance.Get<string>("Server_IP") + "/PCIService/JSLib/UI.aspx?cls=" + _kind + ".Task";
            }
        }

        protected virtual string smsLink
        {
            get
            {
                return "http://" + SystemConfig.Instance.Get<string>("Server_IP");
                //return "http://" + SystemConfig.Instance.Get<string>("Server_IP") + "/m.asp";        //������A�ŹB��Apovs�i�H�γo���챵
            }
        }

        protected virtual bool supportNotIE
        {
            get
            {
                return false;
            }
        }

        protected virtual string ipadLink
        {
            get
            {
                return "http://" + SystemConfig.Instance.Get<string>("Server_IP") + "/m.asp";
            }
        }

        protected virtual int filterHours
        {
            get
            {
                return 6;
            }
        }

        protected virtual string FlowStatusMarkField
        {
            get
            {
                return "Flow_StatusMark";
            }
        }

        protected virtual bool hoursRowFilter(DataRow dr, string task, object filterArgs)
        {
            DateTime actionTime;
            if (DateTime.TryParseExact(dr[FlowStatusMarkField].ToString(), "yyyyMMddHHmmssfff"
                , null, System.Globalization.DateTimeStyles.None, out actionTime))
            {
                DateTime now = DateTime.Now;
                TimeSpan ts = now.Subtract(actionTime);
                int subHours = filterHours;// int.Parse(filterArgs.ToString());
                if (ts.TotalHours >= subHours)
                    return true;
            }
            return false;
        }

        public abstract Dictionary<string, Dictionary<string, Dictionary<string, DataRow>>> getTasks();

        public virtual void Run()
        {
            Dictionary<string, Dictionary<string, Dictionary<string, DataRow>>> tasks = getTasks();
            if (tasks != null && tasks.Count > 0)
            {
                foreach (string user in tasks.Keys)
                {
                    if (tasks[user] != null && tasks[user].Count > 0)
                    {
                        Send(user, tasks[user]);
                        //Send("850.00", tasks[user]);
                        //break;
                        Tool.Info("�o�eDealy����", "sysName", this.cnSysName, "user", user);
                    }
                }
            }

        }

    }
}