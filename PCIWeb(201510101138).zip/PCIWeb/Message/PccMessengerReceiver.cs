using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using PCIWeb.Tools;

namespace PCIWeb.Message
{
    public class PccMessengerReceiver:Sender
    {
        protected override bool send(Msg msg, Dictionary<string, object> sendOptions, out string sendInfo)
        {
            throw new ApplicationException("�D�ʦ����A����ե�Send��k�A�нե�Receive��k");
        }

        protected override string kind
        {
            get { return "PccMessenger"; }
        }

        public override DataTable Receive(string user)
        {
            if (!user.EndsWith(".00"))
                user = user + ".00";        //PccMessenger�L�Ӯɤ���.00

            return base.Receive(user);
        }
    }
}
