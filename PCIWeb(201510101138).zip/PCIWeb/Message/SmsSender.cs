using System;
using System.Collections.Generic;
using System.Text;
using PCIWeb.Tools;

namespace PCIWeb.Message
{
    public class SmsSender:Sender
    {
        public SmsSender(string msgDb)
        {
            _msgDb = msgDb;
        }

        string _msgDb;

        protected override string msgDb
        {
            get
            {
                return _msgDb;
            }
        }

        PCIWeb.Tools.SmsSender smsSender = PCIWeb.Tools.SmsSender.Instance;

        protected override bool send(Msg msg, Dictionary<string, object> sendOptions, out string sendInfo)
        {
            sendInfo = "";
            string phone = msg.RecUser;// msg["RecUser"].ToString();// "085880336381"; 
            string name = "";
            string content = msg.Data.ToString();// msg["Content"].ToString();
            string source = "SmsSender";
            string sender = _msgDb;

            try
            {
                //Dictionary<string, object> ret = AjaxService.Execute("SMSService", "Send", new object[]{phone,name,content,source,sender});
                //PCIWeb.ServiceCaller.Instance.Call(ServiceCaller.CallType.BaseCall, "SMSService.Send", new object[] { phone, name, content, source, sender });
                smsSender.Send(phone, name, content, source, sender);
            }
            catch (Exception ex)
            {
                sendInfo = ex.Message;
                Tool.Error("�o�e²�T����", "ex", ex);
                return false;
            }
            /*
            if (ret["AjaxError"].ToString() != "0")
            {
                sendInfo = ret["Message"].ToString();
                return false;
            }
            */
            return true;
        }

        protected override string kind
        {
            get { return "SMS"; }
        }
    }
}
