﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.IO;

namespace PCIWeb.Tools
{
    public class UploadTool
    {
        string getFolder(string folderOrKind)
        {
            string folder = folderOrKind;
            if (folderOrKind.IndexOf("\\") <= 0)        //就是fileKind
                folder = Tool.UploadFolder + folderOrKind.Replace(".", "\\") + "\\";
            return folder;
        }

        public void Delete(string folderOrKind, string fileName)
        {
            //如果是folder，切記以\結尾
            string path = getFolder(folderOrKind) + fileName;
            if (System.IO.File.Exists(path))
            {
                System.IO.File.Delete(path);
                Tool.Info("Delete File", "path", path);
            }
            else
                Tool.Warn("Delete File But Not Exists", "path", path);
        }

        public void Rename(string folderOrKind, string oldFileName, string newFileName)
        {
            var folder = getFolder(folderOrKind);
            var oldPath = folder + oldFileName;
            var newPath = folder + newFileName;
            if (!File.Exists(oldPath))
                Tool.Warn("src file not exsit", "oldPath", oldPath);
            else if (newFileName == oldFileName)
                Tool.Warn("same file no need rename", "folder", folder, "oldFileName", oldFileName, "newFileName", newFileName);
            else
            {
                if (File.Exists(newPath))
                {
                    Tool.Warn("delete des file", "newPath", newPath);
                    File.Delete(newPath);
                }
                File.Move(oldPath, newPath);
                Tool.Info("Rename File", "oldPath", oldPath, "newPath", newPath);
            }
        }

        public string Upload(Dictionary<string, object> args, string uploadFieldNo, string types, string fileID, string folderOrKind, string batchID)
        {
            string userFileName;
            return Upload(args, uploadFieldNo, types, fileID, folderOrKind, batchID, out userFileName);
        }

        public string Upload(Dictionary<string, object> args, string uploadFieldNo, string types, string fileID, string folderOrKind, string batchID, out string userFileName)
        {
            string soFileUploadId = args[uploadFieldNo].ToString();
            HttpPostedFile soFile = HttpContext.Current.Request.Files[soFileUploadId];
            if (soFile != null && soFile.ContentLength > 0)
            {
                userFileName = soFile.FileName;
                string extension = System.IO.Path.GetExtension(soFile.FileName).Substring(1).ToLower();
                if (Context.ValidTool.InItems(extension, types.ToLower()) != null)
                    throw new PCIBusException("FILE TYPE " + extension + " INVALID,only " + types + " file allowed");
                extension = "." + extension;
                string fileName = fileID + extension;
                string tmpFileName = "TMP_" + fileName;
                //如果是folder，需要以\結尾
                string folder = getFolder(folderOrKind);
                soFile.SaveAs(folder + tmpFileName);
                ServiceCaller.Instance.AddOtherDeal(new string[] { "PCIWeb.Tool.UploadTool.Rename", batchID }, folderOrKind, tmpFileName, fileName);
                return extension;
            }
            userFileName = "";
            return null;
        }
    }
}