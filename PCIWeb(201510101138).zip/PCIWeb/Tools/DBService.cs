﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using PCIWeb;

namespace PCIWeb.Tools
{
    public class DBService
    {

        string dbName;

        public DBService(string dbName)
        {
            this.dbName = dbName;    
        }

        public int Insert(string table, Dictionary<string, object> args)
        {
            return Context.DBTool.Execute("Insert_" + table + "@" + dbName, args);
        }

        public int Update(string table, Dictionary<string, object> args)
        {
            return Context.DBTool.Execute("Update_" + table + "@" + dbName, args);
        }

        public int Delete(string table, Dictionary<string, object> args)
        {
            return Context.DBTool.Execute("Delete_" + table + "@" + dbName, args);
        }

        string getQueryName(string tableOrSql, Dictionary<string, object> args)
        {
            if (tableOrSql.IndexOf(".") >= 0)
            {
                Context.DBTool.SetDB(args, this.dbName);
                return tableOrSql;
            }
            else
                return "Select_" + tableOrSql + "@" + this.dbName;
        }

        public DataTableCollection QueryTables(string tableOrSql, Dictionary<string, object> args)
        {
            return Context.DBTool.Query(getQueryName(tableOrSql, args), args).Tables;
        }

        public DataRowCollection Query(string tableOrSql, Dictionary<string, object> args)
        {
            return Tool.ToRows(Context.DBTool.Query(getQueryName(tableOrSql,args), args));
        }

        public DataRow QueryRow(string tableOrSql, Dictionary<string, object> args)
        {
            return Tool.ToRow(Context.DBTool.Query(getQueryName(tableOrSql,args), args));
        }

        public Object QueryObject(string tableOrSql, Dictionary<string, object> args)
        {
            return Context.DBTool.QueryObject(getQueryName(tableOrSql, args), args);
        }

        public T Query<T>(string tableOrSql, Dictionary<string, object> args)
        {
            return (T)QueryObject(tableOrSql, args);
        }

        public Dictionary<string, object> Query(string tableOrSql, Dictionary<string, object> args, string order, int pagesize, int page)
        {
            int count;
            DataRowCollection rows = Tool.ToRows(Context.DBTool.QueryPage(getQueryName(tableOrSql, args), args, order, pagesize, page, out count));
            return Tool.ToDic(
                "Count", count
                , "Rows", rows
            );
        }
    }
}