﻿using System;
using System.Text;
using System.Web;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Reflection;

namespace PCIWeb.Tools
{
    public class xTraceHelper2
    {

        public static readonly xTraceHelper2 Instance = new xTraceHelper2();

        Queue<Dictionary<string, object>> _queue;       //記錄最后100個訪問的Request

        public List<Dictionary<string, object>> Queue()
        {
            return new List<Dictionary<string, object>>(_queue);
        }

        int QUEUESIZE = 200;

        public xTraceHelper2()
        {
            _queue = new Queue<Dictionary<string, object>>();
            _errWarnQueue = new Queue<Dictionary<string, object>>();
        }

        //static object _lockObj = new object();

        public void Record()
        {
            //暫時不監控,沒有找到好一點的客戶端工具來監控
            //lock (_lockObj)
            //{
                _queue.Enqueue(curTraceBag);
                if (_queue.Count > QUEUESIZE)
                    _queue.Dequeue();
            //}
        }

        public Dictionary<string, object> CurTraceBag
        {
            get
            {
                return curTraceBag;
            }
        }

        Dictionary<string, object> curTraceBag
        {
            get
            {
                Dictionary<string, object> ret;
                if (HttpContext.Current != null)
                {
                    ret = HttpContext.Current.Items["_PCI_Trace"] as Dictionary<string, object>;
                    if (ret == null)
                    {
                        ret = new Dictionary<string, object>();
                        ret.Add("RequestID", AppEventHanlder.Instance.RequestID);
                        ret.Add("IP", AppEventHanlder.Instance.UserHost);
                        ret.Add("UserID", AuthenticateHelper.Instance.UserID);
                        //ret.Add("UserName", AuthenticateHelper.Instance.User != null ? AuthenticateHelper.Instance.User["Name"].ToString() : "");
                        ret.Add("Path", HttpContext.Current.Request.Url.ToString().Split(new char[] { '?' })[0]);
                        string qs =  HttpContext.Current.Request.Url.Query != null && HttpContext.Current.Request.Url.Query.Length > 1 ? HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request.Url.Query.Substring(1)) : "";
                        ret.Add("QueryString", qs);
                        ret.Add("Items", new List<Dictionary<string, object>>());
                        ret.Add("Time", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss fff"));
                        ret.Add("RefUrl", HttpContext.Current.Request.UrlReferrer ==null?"":HttpContext.Current.Request.UrlReferrer.ToString());
                        //ret.Add("Cookies", HttpContext.Current.Request.Cookies.ToString());
                        //ret.Add("Request.Form", HttpContext.Current.Request.Form.ToString());
                        HttpContext.Current.Request.InputStream.Seek(0, SeekOrigin.Begin);
                        string inputStream = (new StreamReader(HttpContext.Current.Request.InputStream)).ReadToEnd();
                        ret.Add("InputStream", inputStream);
                        HttpContext.Current.Request.InputStream.Seek(0, SeekOrigin.Begin);
                        /*
                        string requestBody = "";
                        //如果都沒有,則用RequestBody試試
                        if ((inputStream==null || inputStream.Trim().Length == 0) && (qs==null || qs.Trim().Length == 0))
                        {
                            string folderPath = System.AppDomain.CurrentDomain.BaseDirectory + "/App_Data/Log";
                            string filepath = folderPath + "/"
                                + AppEventHanlder.Instance.RequestID + ".txt";
                            HttpContext.Current.Request.SaveAs(filepath, true);
                            requestBody = File.ReadAllText(filepath);
                            //File.Delete(filepath);
                        }
                        ret.Add("RequestBody", requestBody);
                        */
                        // string xxx = new StreamReader(HttpContext.Current.Request.InputStream).ReadToEnd();
                        //System.Web.Services.Description.
                        //if (_ip == AppEventHanlder.Instance.UserHost)
                        //{
                        /*
                        try
                        {
                            using (StreamReader sr = new StreamReader(HttpContext.Current.Request.InputStream))
                            {
                                ret.Add("InputStream", sr.ReadToEnd());
                            }
                        }
                        catch (Exception ex)
                        {
                            ret.Add("InputStreamErr", ex.Message);
                        }
                        */
                        //可在這里加入Request.SaveAs
                        //}
                        //HttpContext.Current.Request.SaveAs("D:/" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + ".txt",true);
                        //ret.Add("_Seq",0);        //當前記錄的號
                        HttpContext.Current.Items["_PCI_Trace"] = ret;
                    }
                }
                else  //如修改web.config,導至系統結束，記錄Application_End信息時
                {
                    ret = new Dictionary<string, object>();
                    ret.Add("Items", new List<Dictionary<string, object>>());
                    ret.Add("Time", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss fff"));
                }
                return ret;
            }
        }

        void addTraceInfo(Dictionary<string, object> args)
        {
            List<Dictionary<string, object>> infoList = curTraceBag["Items"] as List<Dictionary<string, object>>;
            infoList.Add(args);
            args["Seq"] = infoList.Count;
        }

        #region 依據IP進行Trace

        string _ip = null;

        public void ClearTrace()
        {
            _ip = null;
        }

        public void TraceIP(string ip)
        {
            _ip = ip;
        }

        public void Trace(string msg, params object[] args)
        {
            /*
            if (_ip == null
                || HttpContext.Current == null
                || _ip != HttpContext.Current.Request.UserHostAddress)
                return;
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(true);
            System.Diagnostics.StackFrame sf = st.GetFrame(2);
            string callMethod = sf.GetMethod().ReflectedType.Name + "." + sf.GetMethod().Name;
            addTraceInfo(Tool.ToDic(
                "Message", TraceHelper.FormatMsg(msg, args)
                , "Type", "Trace"
                , "Time", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss fff")
                , "Method", callMethod
                , "ProcessID", System.Diagnostics.Process.GetCurrentProcess().Id
                , "ThreadID", System.Threading.Thread.CurrentThread.ManagedThreadId
            ));
            */
        }

        #endregion

        //增加記錄項
        public void AddTraceInfo(Dictionary<string, object> args)
        {
            addTraceInfo(args);
        }

        //強制設定主檔項(可疊多項)
        public void AddBagItem(string key, object value)
        {
            if (curTraceBag.ContainsKey(key))
            {
                List<object> items = curTraceBag[key] as List<object>;
                if (items == null)
                {
                    items = new List<object>();
                    items.Add(curTraceBag[key]);
                    curTraceBag[key] = items;
                }
                items.Add(value);
            }
            else
                curTraceBag.Add(key, value);
        }

        //強制設定主檔項(單項)
        public void SetBagItem(string key, object value)
        {
            if (key == "LogType")
            {
                if (!curTraceBag.ContainsKey(key))
                {
                    RecordErr();
                    curTraceBag[key] = value;
                }
                else if ((int)value > (int)curTraceBag[key])
                    curTraceBag[key] = value;
            }
            else
                curTraceBag[key] = value;
        }

        public string GetBagItem(string key)
        {
            if (!curTraceBag.ContainsKey(key) || curTraceBag[key] == null)
                return "";
            else
                return curTraceBag[key].ToString();
        }

        #region 錯誤警告單獨記錄

        public void RecordErr()
        {
            //lock (_lockErrObj)
            //{
                _errWarnQueue.Enqueue(curTraceBag);
                if (_errWarnQueue.Count > ERRWARNQUEUESIZE)
                    _errWarnQueue.Dequeue();
            //}
        }

        static object _lockErrObj = new object();

        Queue<Dictionary<string, object>> _errWarnQueue;       //記錄最后100個訪問的Request

        public List<Dictionary<string, object>> ErrWarnQueue()
        {
            return new List<Dictionary<string, object>>(_errWarnQueue);
        }

        int ERRWARNQUEUESIZE = 100;

        #endregion

        public void RecordEndReason()
        {
            HttpRuntime runtime = (HttpRuntime)typeof(System.Web.HttpRuntime).InvokeMember("_theRuntime",
                BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.GetField,

                null,

                null,

                null);



            if (runtime == null)

                return;



            string shutDownMessage = (string)runtime.GetType().InvokeMember("_shutDownMessage",

                BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.GetField,

                null,

                runtime,

                null);



            string shutDownStack = (string)runtime.GetType().InvokeMember(

                "_shutDownStack",

                BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.GetField,

                null,

                runtime,

                null);


            Tool.Info("Web App Shut Down Reason", "shutDownMessage", shutDownMessage, "shutDownStack", shutDownStack);

        }



    }
}