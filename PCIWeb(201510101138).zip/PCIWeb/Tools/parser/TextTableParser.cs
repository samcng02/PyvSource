﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Web;

namespace PCIWeb.Tools
{
    public class TextTableParser:IParser
    {
        public string Kind
        {
            get
            {
                return "1";     //以File文件內容
            }
        }


        public T Read<T>(string text) where T : class
        {
            if (typeof(T) == typeof(object) || typeof(T) == typeof(DataTable))
                return read(text) as T;
            throw new ApplicationException("TextTableParser can only parse DataTable");
        }

        DataTable read(string text)
        {
            DataTable dt = null;
            Tool.Trace("[TextTableParser]Original", "text", text);

            //多行注釋
            text = Regex.Replace(text, @"/\*(.|\r|\n)*?\*/", "");
            Tool.Trace("[TextTableParser]After Replace /*...*/", "text", text);

            text += "\r\n";     //保證最后一行是注釋時，下一個匹配能執行
            //單行注釋
            //text = Regex.Replace(text, @"--.*\r\n", "");
            text = Regex.Replace(text, @"\r\n[ \t\v\f]*--.*(?=\r\n)", "\r\n");   //一行開頭，然後再空格，然後到\r\n，表示一行注釋

            Tool.Trace("[TextTableParser]After Replace--...:", "text", text);

            //空白行去除
            text = Regex.Replace(text, @"\r\n\s*\r\n", "\r\n");
            Tool.Trace("[TextTableParser]Replace Blank Line:", "text", text);

            text = text.Replace('\r', '\n');
            if (text != null && text.Trim().Length > 0)
            {
                string[] lines = text.Split(new char[] { '\n' });
                foreach (string line in lines)
                {
                    //第1行是column
                    if (line.Trim().Length > 0)
                    {
                        string[] fields = line.Split(new char[] { ',' });
                        bool isData = true;
                        if (dt == null)
                        {
                            dt = new DataTable();
                            isData = false;
                        }
                        DataRow dr = null;
                        if (isData)
                        {
                            dr = dt.NewRow();
                            Tool.Trace("[TextTableParser]Add New Row");
                        }
                        int i = 0;
                        foreach (string field in fields)
                        {
                            string fieldStr = field.Trim();
                            if (!isData)
                            {
                                dt.Columns.Add(fieldStr);
                                Tool.Trace("[TextTableParser]Add Column", "fieldStr", fieldStr);

                            }
                            else if (dr != null)
                            {
                                dr[i++] = fieldStr;
                                Tool.Trace("[TextTableParser]", "fieldStr", fieldStr);

                            }
                        }
                        if (dr != null)
                            dt.Rows.Add(dr);
                    }
                }
            }
            if (dt != null)
                dt.AcceptChanges();
            return dt;
        }

    }

}