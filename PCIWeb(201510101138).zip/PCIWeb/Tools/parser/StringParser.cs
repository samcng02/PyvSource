﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace PCIWeb.Tools
{
    /// <summary>
    /// 對JSON對象的封裝
    /// </summary>
    public class StringParser : IParser
    {
        public string Kind
        {
            get
            {
                return "1";     //以File文件內容
            }
        }

        public T Read<T>(string text) where T : class
        {
            if (typeof(T) == typeof(string))
                return text as T;// Tool.ToDic(text) as T;
            throw new ApplicationException("StringParser can only parse String");
        }
    }
}