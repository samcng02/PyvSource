﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Web;

namespace PCIWeb.Tools
{
    public class SqlParser : IParser
    {
        public string Kind
        {
            get
            {
                return "1";     //以File文件內容
            }
        }



        public T Read<T>(string text) where T : class
        {
            if (typeof(T) == typeof(object) || typeof(T) == typeof(Dictionary<string, string>))
                return read(text) as T;
            throw new ApplicationException("SqlParser can only parse Dictionary<string,string>");
        }

        Dictionary<string, string> read(string text)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            Tool.Trace("[SqlParser]Original","text", text);

            //多行注釋
            //text = Regex.Replace(text, @"/\*(.|\r|\n)*?\*/", "");
            text = Regex.Replace(text, @"/\*(.*\n)+?.*?\*/", "");      //.可以匹配\r
            Tool.Trace("[SqlParser]After Replace /*...*/", "text", text);

            //單行注釋
            text += "\r\n";     //保證最后一行是注釋時，下一個匹配能執行
            text = Regex.Replace(text, @"\r\n[ \t\v\f]*--.*(?=\r\n)", "\r\n");   //一行開頭，然後再空格，然後到\r\n，表示一行注釋
            //text = Regex.Replace(text, @"--.*\r\n", "");
            Tool.Trace("[SqlParser]After Replace--...:", "text", text);

            //dic資料填入
            TmpMatcher tm = new TmpMatcher(dic);
            MatchEvaluator me = new MatchEvaluator(tm.CapFunction);
            text = Regex.Replace(text, @".*?:.*", me);
            text = Regex.Replace(text, @"\r\n\s*\r\n", "\r\n");
            Tool.Trace("[SqlParser]Replace Blank Line(final)", "text", text);

            dic["Text"] = text;

            return dic;
        }

        class TmpMatcher
        {

            Dictionary<string, string> _dic;

            public TmpMatcher(Dictionary<string, string> dic)
            {
                _dic = dic;
            }

            public string CapFunction(Match match)
            {
                string mStr = match.ToString();
                string[] tmp = mStr.Split(new char[] { ':' });
                if (tmp[0].IndexOf("'") >= 0 || tmp[0].Trim().IndexOf(" ") >= 0)
                {
                    return mStr;
                }
                else
                {
                    _dic.Add(tmp[0], tmp[1].Replace("\r", "").Replace("\n", "").Trim());
                    Tool.Trace("[SqlParser]Add", "key", tmp[0], "value", _dic[tmp[0]]);
                    return "";
                }
            }
        }
    }
}