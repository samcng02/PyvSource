﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace PCIWeb.Tools
{
    /// <summary>
    /// 對JSON對象的封裝
    /// </summary>
    public class JsonParser : IParser
    {
        public string Kind
        {
            get
            {
                return "1";     //以File文件內容
            }
        }


        public T Read<T>(string text) where T : class
        {
            if (typeof(T) == typeof(object) || typeof(T) == typeof(Dictionary<string, object>))
                return read(text) as T;// Tool.ToDic(text) as T;
            throw new ApplicationException("JsonParser can only parse Dictionary<string,object>");
        }

        Dictionary<string, object> read(string text)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            Tool.Trace("[JsonParser]Original", "text",text);

            //多行注釋
            text = Regex.Replace(text, @"/\*(.|\r|\n)*?\*/", "");
            Tool.Trace("[JsonParser]After Replace /*...*/","text", text);

            text += "\r\n";     //保證最后一行是注釋時，下一個匹配能執行
            //單行注釋
            text = Regex.Replace(text, @"\r\n[ \t\v\f]*\/\/.*(?=\r\n)", "\r\n");   //一行開頭，然後再空格，然後到\r\n，表示一行注釋
            Tool.Trace("[JsonParser]After Replace//...:","text", text);

            //dic資料填入
            return Tool.ToDic(text);
        }


        #region 舊的方法(可多層搜尋key)

        /*

            //_gets = new Dictionary<string, object>();
        public string GetJson()
        {
            return JsonHelper.ToJson(_dic);
        }

        public Dictionary<string, object> Dic
        {
            get
            {
                return _dic;
            }
        }

        Dictionary<string, object> _gets;

        public T Get<T>(string key)
        {
            return this.Get<T>(key, '.');
        }

        public T Get<T>(string key, char splitKey)
        {
            if (_gets != null && _gets.ContainsKey(key))
                return (T)_gets[key];

            T ret = default(T);
            Dictionary<string, object> dic = _dic;
            string[] keys = key.Split(new char[] { splitKey });
            for (int i = 0; i < keys.Length; i++)
            {
                string itemKey = keys[i];
                if (dic == null || !dic.ContainsKey(itemKey))
                    break;
                    //throw new PCIAppException(this, "Dictionary is null",null, itemKey, key, i);
                if (i != keys.Length - 1)       //不是最後一個
                {
                    dic = dic[itemKey] as Dictionary<string, object>;
                }
                else
                {
                    ret = (T)dic[itemKey];
                }
            }

            if (ret != null)
            {
                _gets.Add(key, ret);
            }

            return ret;
        }

        public void Set(string key, object v)
        {
            this.Set(key, v, '.');
        }

        public void Set(string key, object v, char splitKey)
        {
            if (_gets != null)
                _gets[key] = v;

            Dictionary<string, object> dic = _dic;
            if (_dic == null)
                _dic = new Dictionary<string, object>();
            string[] keys = key.Split(new char[] { splitKey });
            for (int i = 0; i < keys.Length; i++)
            {
                string itemKey = keys[i];
                if (i != keys.Length - 1)       //不是最後一個
                {
                    Dictionary<string, object> nextDic = null;
                    if (dic.ContainsKey(itemKey))
                    {
                        if (dic[itemKey] is Dictionary<string, object>)
                            nextDic = dic[itemKey] as Dictionary<string, object>;
                        else
                            throw new ApplicationException("itemKey is a bottom level,but want to set as a middle key(itemkey:" + itemKey + " key:" +  key + " index:" +  i + ")");
                    }
                    if (nextDic == null)
                    {
                        nextDic = new Dictionary<string, object>();
                        dic.Add(itemKey, nextDic);
                    }
                    dic = nextDic;
                }
                else
                {
                    dic[itemKey] = v;
                }
            }

        }

        public void Remove(string key)
        {
            this.Remove(key, '.');
        }

        public void Remove(string key, char splitKey)
        {
            if (_gets != null && _gets.ContainsKey(key))
                _gets.Remove(key);

            Dictionary<string, object> dic = _dic;
            string[] keys = key.Split(new char[] { splitKey });
            for (int i = 0; i < keys.Length; i++)
            {
                string itemKey = keys[i];
                if (dic == null || !dic.ContainsKey(itemKey))
                    break;
                    // throw new PCIAppException(this, "Dictionary is null", null, itemKey, key, i);
                if (i != keys.Length - 1)       //不是最後一個
                {
                    dic = dic[itemKey] as Dictionary<string, object>;
                }
                else
                {
                    dic.Remove(itemKey);
                }
            }
        }
        */

        #endregion
    }
}