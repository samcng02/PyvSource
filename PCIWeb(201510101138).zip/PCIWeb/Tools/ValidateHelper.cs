﻿using System;
using System.Web;
using System.Web.Caching;
using System.Web.SessionState;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.OracleClient;
using System.Data.SqlClient;
using System.Text;
using System.Text.RegularExpressions;
using System.Reflection;

namespace PCIWeb.Tools
{
    /// <summary>
    /// Data Access Layer
    /// </summary>
    public class ValidateHelper
    {

        public static readonly ValidateHelper _instance = new ValidateHelper();

        public static ValidateHelper Instance
        {
            get
            {
                return _instance;
            }
        }

        FileConfig _cfg = new FileConfig("Valid", new JsonParser());

        public void Valid(Dictionary<string, object> validObj, string validName)
        {
            Dictionary<string, object> ruleCfg = _cfg.Parse<Dictionary<string, object>>(validName);
            if (ruleCfg != null)
            {
                if (!ruleCfg.ContainsKey("Valid"))
                    throw new ApplicationException(validName + " not contain Valid!");
                else if (!(ruleCfg["Valid"] is ArrayList))
                    throw new ApplicationException(validName + " Valid is not a array(item object)!");
                else
                {
                    ArrayList tmp = ruleCfg["Valid"] as ArrayList;
                    Valid(validObj, tmp);
                }
            }
        }

        public void Valid(Dictionary<string, object> validObj, ArrayList rulesArray)
        {
            Dictionary<string, object>[] rules = new Dictionary<string, object>[rulesArray.Count];
            rulesArray.CopyTo(rules);
            Valid(validObj, rules);
        }

        public void Valid(Dictionary<string, object> validObj, Dictionary<string, object>[] rules)
        {
            string validErrMsg = "";
            Dictionary<string, object> validResult = new Dictionary<string, object>();
            foreach (Dictionary<string, object> rule in rules)
            {
                string[] fields = null;
                if (rule.ContainsKey("Fields"))
                {
                    if (rule["Fields"] is string)
                        fields = new string[] { rule["Fields"].ToString() };
                    else
                    {
                        ArrayList fieldsAry = rule["Fields"] as ArrayList;
                        fields = new string[fieldsAry.Count];
                        if (fieldsAry != null)
                            fieldsAry.CopyTo(fields);
                    }
                }
                if (fields != null)
                {
                    bool hasValided = false;
                    foreach (string field in fields)
                    {
                        if (hasValided)
                            break;
                        if (field.IndexOf(",") > 0)
                        {
                            string[] tmp = field.Split(new char[] { ',' });
                            foreach (string fieldTmp in tmp)
                            {
                                if (validResult.ContainsKey(fieldTmp))
                                {
                                    hasValided = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            if (validResult.ContainsKey(field))
                            {
                                hasValided = true;
                                break;
                            }
                        }
                    }
                    if (hasValided)
                        continue;
                    if (rule.ContainsKey("Valid"))
                    {
                        string ruleMet = rule["Valid"].ToString();
                        string errMsg = rule.ContainsKey("Msg") ? rule["Msg"].ToString() : null;
                        Dictionary<string, object> ruleObj = rule.ContainsKey("Set") ? rule["Set"] as Dictionary<string, object> : null;
                        string validRet = valid(validObj, fields, ruleMet, ruleObj, errMsg);
                        if (validRet != null && validRet.Length > 0)
                        {
                            validErrMsg += validRet + "<br>";
                            foreach (string field in fields)
                            {
                                if (field.IndexOf(",") > 0)
                                {
                                    string[] tmp = field.Split(new char[] { ',' });
                                    foreach (string fieldTmp in tmp)
                                        validResult[fieldTmp] = validRet;
                                }
                                else
                                    validResult[field] = validRet;
                            }
                        }
                    }
                    else
                        throw new ApplicationException("Valid Rule Config Error:No Valid");
                }
                else
                    throw new ApplicationException("Valid Rule Config Error:No Fields");
            }
            if (validErrMsg.Length > 0)
            {
                PCIBusException ex = new PCIBusException(validErrMsg);
                ex.Data["ClientInfo"] = validResult;
                throw ex;
            }
        }

        class replaceDic
        {
            public replaceDic(Dictionary<string, object> args)
            {
                _args = args;
            }

            Dictionary<string, object> _args;

            public string capText(Match match)
            {
                string mStr = match.ToString();
                string paramName = mStr.Substring(1, mStr.Length - 2);        //*paramName*
                if (_args.ContainsKey(paramName))
                    return _args[paramName].ToString();
                return mStr;
            }
        }

        string valid(Dictionary<string, object> validObj, string[] fields, string ruleMet, Dictionary<string, object> ruleObj, string errMsg)
        {
            MethodInfo met = typeof(ValidateHelper).GetMethod(ruleMet);
            if (met != null)
            {
                object[] paramObjs = new object[fields.Length + (ruleObj == null ? 0 : ruleObj.Count)];
                int i = 0;
                foreach (string field in fields)
                {
                    //這里有bug，如果Dictionary或Array也只有一個field組成，怎么可能有，呢?
                    if (field.IndexOf(",") > 0)
                    {
                        string[] fieldTmp = field.Split(new char[] { ',' });
                        if (met.GetParameters()[i].ParameterType.IsArray)   //客戶端可以直接通過ruleMet=="Server"寫死
                        {
                            object[] paramTmp = new object[fieldTmp.Length];
                            int j = 0;
                            foreach (string tmp in fieldTmp)
                                paramTmp[j++] = validObj.ContainsKey(tmp) ? validObj[tmp] : null;
                            paramObjs[i++] = paramTmp;
                        }
                        else
                        {
                            Dictionary<string, object> paramTmp = new Dictionary<string, object>();
                            foreach (string tmp in fieldTmp)
                            {
                                //形如"Name,Name__NE|Name__W"的配置
                                int index = tmp.IndexOf("|");
                                if (index > 0)
                                    paramTmp.Add(tmp.Substring(0, index), validObj.ContainsKey(tmp.Substring(index + 1)) ? validObj[tmp.Substring(index + 1)] : null);
                                else
                                    paramTmp.Add(tmp, validObj.ContainsKey(tmp) ? validObj[tmp] : null);
                            }
                            paramObjs[i++] = paramTmp;
                        }

                    }
                    else
                    {  //這裡沒有那種驗証，因為用|分隔隻有出線在傳Dictionary參數時才有
                        if (met.GetParameters()[i].ParameterType.IsArray)   //客戶端可以直接通過ruleMet=="Server"寫死
                            paramObjs[i++] = new object[] { validObj.ContainsKey(field) ? validObj[field] : null };
                        else
                            paramObjs[i++] = validObj.ContainsKey(field) ? validObj[field] : null;
                    }
                }


                if (ruleObj != null)
                {
                    foreach (string key in ruleObj.Keys)
                        paramObjs[i++] = ruleObj[key];
                }

                try
                {
                    string fieldstr = "";
                    foreach (string field in fields)
                        fieldstr += (fieldstr.Length > 0 ? "," : "") + field;
                    object result = met.Invoke(null, paramObjs);
                    if (errMsg == null || errMsg == "")
                        errMsg = "Error: {0} not match " + ruleMet + " {1}";
                    if (met.ReturnType == typeof(Boolean) && !(Boolean)result)
                        return string.Format(errMsg, fieldstr, "");
                    else if (met.ReturnType == typeof(string) && result != null && (result.ToString()).Length > 0)
                        return string.Format(errMsg, fieldstr, result.ToString());
                    else if (met.ReturnType == typeof(Dictionary<string, object>) && result != null)
                    {
                        replaceDic rd = new replaceDic(result as Dictionary<string, object>);
                        return Regex.Replace(errMsg, @"\{.*?\}", new MatchEvaluator(rd.capText));
                    }
                    return null;

                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
            }
            return "No valid function";
        }

        #region 驗証函數

        public static bool Required(object input)
        {
            if (input == null || input.ToString().Trim().Length == 0)
                return false;
            return true;
        }

        public static bool Size(object input, int min, int max)
        {
            if (Required(input))
            {
                string tmp = input.ToString().Trim();
                if (tmp.Length < min ||
                    tmp.Length > max)
                    return false;
            }
            return true;
        }

        public static bool Number(object input)
        {
            if (Required(input))
            {
                string tmp = input.ToString();
                decimal outTmp;
                if (!decimal.TryParse(tmp, out outTmp))
                    return false;
            }
            return true;
        }

        public static bool Integer(object input)
        {
            if (Required(input))
            {
                string tmp = input.ToString();
                int outTmp;
                if (!int.TryParse(tmp, out outTmp))
                    return false;
            }
            return true;
        }

        public static bool MaxDecimalCount(object input,int maxDecimalCount)
        {
            if (Required(input))
            {
                if (Number(input))
                {
                    string tmp = input.ToString();
                    if (tmp.IndexOf('.') > 0)
                    {
                        return tmp.Split(new char[] { '.' })[1].Length <= maxDecimalCount;
                    }
                    return true;
                }
                return false;
            }
            return true;
        }

        public static bool Range(object input, object min, object max)
        {
            if (Required(input))
            {
                if (min is string)
                {
                    string tmp = input.ToString().Trim();
                    if (tmp.CompareTo(min) == -1 ||
                        tmp.CompareTo(max) == 1)
                        return false;
                }
                else
                {
                    decimal tmp = decimal.Parse(input.ToString());
                    if (tmp.CompareTo(decimal.Parse(min.ToString())) == -1 ||
                        tmp.CompareTo(decimal.Parse(max.ToString())) == 1)
                        return false;
                }
            }
            return true;
        }

        public static bool Date(object input)
        {
            if (Required(input))
            {
                DateTime tmp;
                if (!DateTime.TryParseExact(input.ToString().Trim(), "yyyyMMdd", null, System.Globalization.DateTimeStyles.None, out tmp))
                    return false;
            }
            return true;
        }

        public static bool Time(object input)
        {
            if (Required(input))
            {
                DateTime tmp;
                if (!DateTime.TryParseExact(input.ToString().Trim(), "HHmm", null, System.Globalization.DateTimeStyles.None, out tmp))
                    return false;
            }
            return true;
        }

        public static bool Beginend(object begin, object end, bool noEqual)
        {
            if (Required(begin) && Required(end))
            {
                if (noEqual)
                {        //相等也不行
                    if (begin.ToString().CompareTo(end) != -1)
                        return false;
                }
                else
                {
                    if (begin.ToString().CompareTo(end) == 1)
                        return false;
                }
            }
            return true;
        }

        public static Dictionary<string, object> DBExists(Dictionary<string, object> obj, string db, string table)
        {
            string cmd = "Select_" + table + "@" + db;
            DBHelper.Instance.NoCache(obj);
            //obj["__NoCache"] = "1";
            DataSet ds = DBHelper.Instance.Query(cmd, obj);
            return Tool.ToDic(ds);
        }

        public static Dictionary<string, object> DBCheck(Dictionary<string, object> obj, string cmd)
        {
            DataSet ds = DBHelper.Instance.Query(cmd, obj);
            DBHelper.Instance.NoCache(obj);
            //obj["__NoCache"] = "1";
            return Tool.ToDic(ds);
        }

        public static string Server(object[] obj, string cmd)
        {
            string objStr = cmd.Substring(0, cmd.LastIndexOf("."));
            object serviceObj = ObjectFactory.Default.Get(objStr);
            if (serviceObj == null)
                return "Service not found(service:" + obj + ")";
            string metstr = cmd.Substring(cmd.LastIndexOf(".") + 1);
            try
            {
                MethodInfo met = serviceObj.GetType().GetMethod(metstr);
                if (met == null)
                    return metstr + "is not found";
                object result = met.Invoke(serviceObj, obj);
                if (result != null)
                    return result.ToString();
                return "";
            }
            catch (Exception ex)
            {
                return "Valid failure:" + ex.Message;
            }
        }

        #endregion
    }
}