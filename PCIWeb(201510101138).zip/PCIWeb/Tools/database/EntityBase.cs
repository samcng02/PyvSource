using System;
using System.Collections.Generic;
using System.Data;

namespace PCIWeb.Tools
{
    //public interface ITable
    //{
    //    string Database { get;}
    //    string Table { get;}
    //    string[] Keys { get;}
    //    string[] Fields { get;}
    //    string[] FieldsType { get;}
    //}

    //public class DBTable : ITable
    //{

    //    public DBTable(string db, string table, string keys)
    //    {
    //        _database = db;
    //        _table = table;
    //        if (keys != null)
    //            _keys = keys.Split(new char[] { ',' });
    //        else
    //            _keys = null;
    //        initMeta();
    //    }

    //    void initMeta()
    //    {
    //        Dictionary<string, object> args = new Dictionary<string, object>();
    //        args.Add("1", "2");
    //        args.Add("__NoCache", "1");
    //        DataSet ds = DBHelper.Instance.Query("Select_" + _table + "@" + _database, args);

    //        _fields = new string[ds.Tables[0].Columns.Count];
    //        _fieldsType = new string[_fields.Length];
    //        int j = 0;
    //        foreach (DataColumn dc in ds.Tables[0].Columns)
    //        {
    //            _fields[j] = dc.ColumnName;
    //            _fieldsType[j] = dc.DataType.ToString();
    //            j++;
    //        }
    //    }

    //    #region ITable ����

    //    string _database;

    //    public string Database
    //    {
    //        get { return _database; }
    //    }

    //    string _table;
    //    public string Table
    //    {
    //        get { return _table; }
    //    }

    //    string[] _keys;
    //    public string[] Keys
    //    {
    //        get { return _keys; }
    //    }

    //    string[] _fields;
    //    public string[] Fields
    //    {
    //        get { return _fields; }
    //    }

    //    string[] _fieldsType;
    //    public string[] FieldsType
    //    {
    //        get { return _fieldsType; }
    //    }

    //    #endregion
    //}


    //public interface IEBTable
    //{
    //    string Database { get;}
    //    string Table { get;}
    //    string[] Keys { get;}
    //}

    public class EntityBase
    {

        protected string _table;
        protected string _database;
        protected string[] _keys;
        protected string _selectCmd;
        protected string _insertCmd;
        protected string _updateCmd;
        protected string _deleteCmd;

        //public string SelectCmd
        //{
        //    get
        //    {
        //        return _selectCmd;
        //    }
        //}

        //public string InsertCmd
        //{
        //    get
        //    {
        //        return _insertCmd;
        //    }
        //}
        //public string UpdateCmd
        //{
        //    get
        //    {
        //        return _updateCmd;
        //    }
        //}
        //public string DeleteCmd
        //{
        //    get
        //    {
        //        return _deleteCmd;
        //    }
        //}

        public object this[string key]
        {
            get
            {
                return this._data.ContainsKey(key) ? this._data[key] : null;
            }
            set
            {
                this._data[key] = value;
            }
        }

        //public EntityBase(IEBTable table)
        //    :this(table.Database,table.Table,table.Keys)
        //{
        //}

        public EntityBase(string database, string table, string keys)
            : this(database, table, keys.Split(new char[] { ',' }))
        {
        }

        public EntityBase(string database,string table,string[] keys)
        {
            _database = database;
            _table = table;
            _keys = keys;
            //initTable();
            this._data = new Dictionary<string, object>();
            initCommand();
        }

        //public EntityBase(DataSet ds)
        //{
        //    this.Read(ds);
        //}

        //public EntityBase(Dictionary<string, object> args)
        //{
        //    this.Read(args);
        //}

        //public EntityBase(params object[] keysValue)
        //{
        //    this.Read(keysValue);
        //}

        protected virtual void initTable()
        {

        }

        protected virtual void initCommand()
        {
            _selectCmd = "Select_" + _table + "@" + _database;
            _insertCmd = "Insert_" + _table + "@" + _database;
            _updateCmd = "Update_" + _table + "@" + _database;
            _deleteCmd = "Delete_" + _table + "@" + _database;
        }

        protected Dictionary<string, object> _data;

        public Dictionary<string, object> Data
        {
            get
            {
                return _data;
            }
            set
            {
                _data = value;
            }
        }

        //�s�W
        public virtual EntityBase Init()
        {
            this._data = new Dictionary<string, object>();
            return this;
        }

        //from database
        //�i�H�Ҽ{return -1���ܥ�Ū����ơA���L�o�ˤ]�O�@�˪�����Read().Data�P�_�N��
        public virtual EntityBase Read(DataSet ds)
        {
            Dictionary<string, object> args = Tool.ToDic(ds);
            if (args != null)
                this.Read(args);
            else
                this.Data = null;   //�P�_Data��null�A�h��Ƥ��s�b
            return this;
        }

        //from javascript json
        public virtual EntityBase Read(Dictionary<string, object> args)
        {
            this._data = args;
            return this;
        }

        public virtual int Insert()
        {
            //ValidateHelper.Instance.Valid(this._data, _insertCmd);

            return DBHelper.Instance.Execute(_insertCmd, this._data);
        }

        //�ھ�key�Aupdate�Ҧ����
        public virtual int Update()
        {
            return Update(this._keys);
        }

        //�ھ�key�Aupdate���w���
        public virtual int UpdateFields(string[] updateFields)
        {
            return Update(this._keys, updateFields);
        }

        //�ھ�whereFields,update
        public virtual int Update(string[] whereFields)
        {
            Dictionary<string, object> args = this._data;
            foreach (string key in whereFields)
            {
                args[key + "__W"] = this._data[key];
                // ValidateHelper.Instance.Valid(args, _updateCmd);
                args.Remove(key);
            }
            int ret = DBHelper.Instance.Execute(_updateCmd, args);
            foreach (string key in _keys)
            {   //�]��args�Othis._data
                args[key] = args[key + "__W"];
                args.Remove(key + "__W");
            }
            return ret;
        }

        //�ھ�whereFields,update���w���
        public virtual int Update(string[] whereFields, string[] updateFields)
        {
            Dictionary<string, object> args = new Dictionary<string, object>();
            foreach (string key in whereFields)
                args[key + "__W"] = this._data[key];
            foreach (string key in updateFields)
                args[key] = this._data[key];
           // ValidateHelper.Instance.Valid(args, _updateCmd);
            return DBHelper.Instance.Execute(_updateCmd, args);
        }

        public virtual int Delete()
        {
            //�p�G�Ȥ��user��FKey!N���A���������i��|�R���A�i�O���y�{������R�]�]�����~�����p�^
            Dictionary<string, object> args = new Dictionary<string, object>();
            foreach (string key in _keys)
                args[key] = this._data[key];
           // ValidateHelper.Instance.Valid(args, _deleteCmd);

            return DBHelper.Instance.Execute(_deleteCmd, args);
        }

        //��@�Dkey���ơ]�եήɤ�K�^
        public virtual EntityBase Read(object keyValue)
        {
            if (_keys.Length != 1)
                throw new ApplicationException("��@�Dkey�~��ϥγo�ؤ�k");
            Read(_keys, new object[] { keyValue });
            return this;
        }

        //�h�Dkey�����ơ]�n�g�A��params object[]�^
        public virtual EntityBase Read(params object[] keysValue)
        {
            Read(_keys, keysValue);
            return this;
            //Dictionary<string, object> args = new Dictionary<string, object>();
            //int i = 0;
            //foreach (string key in _keys)
            //    args[key] = keysValue[i++];
            //Read(DBHelper.Instance.Query(_selectCmd, args));
        }

        //������Read�iDictionary��DataSet�A�M��q��Ʈw�ǰt(Dictionary)�έ��s����(DataSet)
        public EntityBase Read()
        {
            return Read(_keys);
        }

        public EntityBase Read(string[] fields)
        {
            object[] values = new object[fields.Length];
            int i=0;
            foreach (string field in fields)
                values[i++] = this._data[field];
            return Read(fields, values);
        }

        //���ѳo�Ǽg�k�A�O���F�i�H��n���Q�ΰʺA��O
        public EntityBase Read(string[] fields, object[] values)
        {
            Dictionary<string, object> args = new Dictionary<string, object>();
            int i = 0;
            foreach (string field in fields)
                args[field] = values[i++];
            Read(DBHelper.Instance.Query(_selectCmd, args));
            return this;
        }

        public List<Dictionary<string, object>> Query()
        {
            return Tool.ToListDic(DBHelper.Instance.Query(_selectCmd, this._data));
        }

    }
}