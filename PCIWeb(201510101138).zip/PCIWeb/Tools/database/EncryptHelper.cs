﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using PCIWeb;

namespace PCIWeb.Tools
{
    public class EncryptHelper
    {
        public string Encrypt(string from)
        {
            return CookieAuthenticateModule.Encrypt(from, _KEY_64, _IV_64);
        }

        const string _KEY_64 = "aX~-8@Jk"; //必須是8個字符（64Bit)
        const string _IV_64 = "b*2^）5[?";  //必須是8個字符（64Bit)

        public static string Decrypt(string from)
        {
            return CookieAuthenticateModule.Decrypt(from, _KEY_64, _IV_64);
        }

        const string DATABASE_CFG_PREFIX = "Database_";

        public void EncryptDB(string db)
        {
            FileConfig config = ((FileConfig)ObjectFactory.Instance.Config);
            string configName = DATABASE_CFG_PREFIX + db;
            Dictionary<string, object> cfg = config.Parse<Dictionary<string, object>>(configName);
            if (!cfg.ContainsKey("$ref"))
            {
                ArrayList args = cfg["Args"] as ArrayList;
                string type = args[0].ToString();
                if (!type.StartsWith("$"))
                {
                    args[0] = "$" + type;
                    args[1] = Encrypt(args[1].ToString());
                }
                //有可能DecryptDB后，有緩存，造成不會保存
                config.SaveConfig(configName, Tool.ToJson(cfg));
                Tool.Info("encrypt db config", "db", db);
            }
        }

        public string DecryptDB(string db)
        {
            return DecryptDB(db, false);
        }

        public string DecryptDB(string db,bool save)
        {
            FileConfig config = ((FileConfig)ObjectFactory.Instance.Config);
            string configName = DATABASE_CFG_PREFIX + db;
            Dictionary<string, object> cfg = config.Parse<Dictionary<string, object>>(configName);
            if (cfg == null)
            {
                Tool.Warn("db cfg null", "db", db);
                return "null";
            }
            if (!cfg.ContainsKey("$ref"))
            {
                ArrayList args = cfg["Args"] as ArrayList;
                string type = args[0].ToString();
                string conn = args[1].ToString();
                if (type.StartsWith("$"))
                {
                    if (save)
                    {
                        args[0] = type.Substring(1);
                        args[1] = conn = Decrypt(conn);
                        config.SaveConfig(configName, Tool.ToJson(cfg));
                        Tool.Info("decrypt db config", "db", db);
                    }
                    else
                    {
                        conn = Decrypt(conn);
                    }
                }
                else
                {
                    if (save)
                    {
                        config.SaveConfig(configName, Tool.ToJson(cfg));
                        Tool.Info("no need decrypt", "db", db);
                    }
                }
                return conn;
            }
            else
            {
                return DecryptDB(cfg["$ref"].ToString(), false);
            }
        }


        public void EncryptAllDB()
        {
            List<string> allItems = ((FileConfig)ObjectFactory.Instance.Config).Items();
            foreach (string item in allItems)
            {
                if (item.StartsWith(DATABASE_CFG_PREFIX))
                {
                    EncryptDB(item.Substring(DATABASE_CFG_PREFIX.Length));
                }
            }
        }


        public void DecryptAllDB()
        {
            List<string> allItems = ((FileConfig)ObjectFactory.Instance.Config).Items();
            foreach (string item in allItems)
            {
                if (item.StartsWith(DATABASE_CFG_PREFIX))
                {
                    DecryptDB(item.Substring(DATABASE_CFG_PREFIX.Length),true);
                }
            }
        }

    }
}