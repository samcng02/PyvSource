﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace PCIWeb.Tools
{
    internal class SqlReplaceHelper
    {
        Dictionary<string, object> _args;
        StringBuilder _textSb;

        public SqlReplaceHelper(string text,Dictionary<string, object> args)
        {
            _textSb = new StringBuilder(text);
            _args = args;
        }

        public string TranText()
        {
            replaceText();
            applyFunctions();
            //replaceServiceVar();
            return _textSb.ToString();
        }

        void replaceText()
        {
            if (_args != null)
            {
                foreach (string key in _args.Keys)
                {
                    string repKey = "#" + key + "#";
                    if (_args.ContainsKey(key) && _args[key]!=null)
                        _textSb.Replace(repKey, _args[key].ToString());
                }
            }
        }

        void applyFunctions()
        {
            MatchEvaluator me = new MatchEvaluator(capFunction);
            //TODO:想辦法把中間的()自動匹配掉，這樣在寫sql時就不用在函數里使用{}來代替()了
            //或者簡單起見，就用[]或{}來代替()，看sql中出現哪種的機率小
            //@Insert(WEB_BD_REASON|ITEMNO,REASON,REASON_INDO)
            string text = Regex.Replace(_textSb.ToString(), @"@.*?\)", me);   //start with @(, and end with )    
            _textSb = new StringBuilder(text);
        }

        string capFunction(Match match)
        {
            string mStr = match.ToString();
            string functionText = mStr.Substring(1, mStr.Length - 1);        //-1,remove @
            string[] tmp = functionText.Trim().Split(new char[] { '(' });
            string name = tmp[0];
            if (tmp.Length == 2)
            {
                string paramStr = tmp[1].Substring(0, tmp[1].Length - 1);   //-1,remove)
                return SqlFunction.Instance.Call(name, paramStr, _args);
            }
            else
            {
                return mStr;
             //   throw new ApplicationException("Format is invalid:" + mStr);
            }
        }
        /*
        void replaceServiceVar()
        {
            MatchEvaluator me = new MatchEvaluator(capServiceVar);
            string text = Regex.Replace(_textSb.ToString(), @"~[0-9_a-zA-Z\|]*?~", me);   //~DBKIND^XX~ 
            _textSb = new StringBuilder(text);
        }

        string capServiceVar(Match match)
        {
            string mStr = match.ToString();
            string varName = mStr.Substring(1, mStr.Length - 2);        //~paramName~
            int defaultValueIndex = varName.IndexOf("|");
            string defaultValue = "";
            if (defaultValueIndex > 0)
            {
                defaultValue = varName.Substring(defaultValueIndex + 1);
                varName = varName.Substring(0, defaultValueIndex);
            }
            return AppEventHanlder.Instance.ServiceVar(varName) ?? defaultValue;
        }
        */
    }

    public class SqlHelper
    {

        static string cfgDir = "SqlHelper";
        //使用App_Data/Config/SqlHelper下的配置
        //public static readonly SqlHelper Instance = new SqlHelper(new AutoSqlConfig(new FileConfig(cfgDir, new SqlParser())));
        public static readonly SqlHelper Instance = new SqlHelper(new AutoSqlConfig(cfgDir));
        //使用資料庫存儲DB文件（有利於多系統協作）
        //public static readonly SqlHelper Instance = new SqlHelper(new AutoSqlConfig(new SqlConfig(cfgDir)));

        FileConfig _config;

        public SqlHelper(FileConfig config)
        {
            _config = config;
        }

        public string CountSql(string sql)
        {
            //string[] tmp = sql.Split(new string[] { "FROM" }, 2, StringSplitOptions.None);
            StringBuilder countsb = new StringBuilder();
            countsb.AppendFormat("SELECT count(*) FROM ({0}) tbl", sql);
            return countsb.ToString();
        }

        /// <summary>
        /// oracle的order請加上主key排序，否則分頁不正確
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="order"></param>
        /// <param name="pagesize"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        public string PageSql(string sql, string order, int pagesize, int page)
        {
            StringBuilder pagesb = new StringBuilder();
            //string[] tmp = sql.Split(new string[] { "FROM" }, 2, StringSplitOptions.None);
            //pagesb.Append("SELECT * FROM(");
            //pagesb.AppendFormat("{0},ROW_NUMBER() OVER (ORDER BY {1}) AS ROWNUMBER FROM {2}", tmp[0], order, tmp[1]);        //替換第一個FROM
            //pagesb.AppendFormat(")QueryTbl WHERE ROWNUMBER > {0} AND ROWNUMBER<= {1}", (page - 1) * pagesize, page * pagesize);            
            //這里的ROW_NUMBER() OVER(ORDER BY order參數)存在漏洞
            //在Oracle中，通過這個Row_number如果是，非主key，則取不準，即翻到第二頁時，資料沒有和第一頁銜接
            //Bonding Test的前端已加入兩個主key排序，不過如果是動態Sort，則不具備這個功能
            //改版時要考慮如何解決這個問題
            if (pagesize > 0)
            {
                pagesb.Append("SELECT * FROM(");
                pagesb.AppendFormat("SELECT tbl.*,ROW_NUMBER() OVER (ORDER BY {0}) AS ROWNUMBER FROM ({1}) tbl", order, sql);
                pagesb.AppendFormat(")QueryTbl WHERE ROWNUMBER > {0} AND ROWNUMBER<= {1}", (page - 1) * pagesize, page * pagesize);
            }
            else
            {
                pagesb.AppendFormat("SELECT tbl.* FROM ({1}) tbl ORDER BY {0}", order, sql);
            }
            return pagesb.ToString();
        }

        public FileConfig Config
        {
            get
            {
                return _config;
            }
        }

        string getCmdCfg(string cmdName, string key)
        {
            //這裡在界面上改了後不會清空，怎麼辦?(增加清空按鈕? or 自動判斷清空)
            Dictionary<string, string> tmp = Config.Parse<Dictionary<string, string>>(cmdName + ".sql");
            if (tmp != null && tmp.ContainsKey(key))
                return tmp[key];
            return null;
        }

        public string[] CommandCacheKeys(string cmdName)
        {
            string tmp = getCmdCfg(cmdName,"Tables");
            if(tmp!=null && tmp.Length>0)
                return tmp.ToLower().Trim().Split(new char[]{','});   //Tables(緩存鍵)大小寫無關
            return null;
        }

        public string CommandDb(string cmdName)
        {
            string ret = getCmdCfg(cmdName, "DB");
            //可用於客戶端直接下Select語句，不給定Database，以及需要同時訪問2個Database的情況（如某些人使用測試資料庫進入系統）
            if (System.Web.HttpContext.Current != null && System.Web.HttpContext.Current.Items.Contains("DB_KIND_SET"))
            {
                string setDB = System.Web.HttpContext.Current.Items["DB_KIND_SET"].ToString();
                ret += (ret != null && ret.Length > 0 && setDB!=null && setDB.Length>0 ? "_" : "") + setDB;
            }
            return ret;
        }

        public string CommandType(string cmdName)
        {
            return getCmdCfg(cmdName, "Type");
        }

        public string CommandSql(string cmdName, Dictionary<string, object> args)
        {
            string text = getCmdCfg(cmdName, "Text");
            if (text!=null)
            {
                SqlReplaceHelper sr = new SqlReplaceHelper(text, args);
                return sr.TranText();
            }
            else
                throw new ApplicationException("Command Text is null(cmd:" +  cmdName + ")");
        }

        //將默認參數寫入
        public void FillCfgParams(string cmdName, Dictionary<string, object> args)
        {
            Dictionary<string, string> tmp = Config.Parse<Dictionary<string, string>>(cmdName + ".sql");
            if (tmp != null)
            {
                foreach (string key in tmp.Keys)
                {
                    //默認參數
                    if (key.StartsWith("@") && !args.ContainsKey(key.Substring(1)))
                    {
                        //TODO:可以使用UserID,Today,Now等動態計算值
                        args[key.Substring(1)] = getFixedValue(tmp[key],args);
                    }
                }
            }
        }

        string getFixedValue(string fixedValue, Dictionary<string, object> args)
        {
            //暫時這樣寫（因為目前沒碰到其它情況
            //如果有，可以考慮用StateFlow的Expression來完成，當然這里少了一些參數
            if (fixedValue == "@UserID")
            {
                return AuthenticateHelper.Instance.UserID ?? "";
            }
            else if (fixedValue == "@UserIDNo00")
            {
                return (AuthenticateHelper.Instance.UserID ?? "").Replace(".00","");
            }
            else if (fixedValue == "@Today")
            {
                return DateTime.Today.ToString("yyyyMMdd");
            }
            else if (fixedValue == "@Now")
            {
                return DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            return fixedValue;
        }
    }
}