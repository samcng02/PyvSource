﻿using System;
using System.IO;
using System.Web;
using System.Web.Caching;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace PCIWeb.Tools
{
    /*
    public class SqlConfig : AConfig
    {
        public SqlConfig(string dbname)
            : base(dbname)
        {
            DBHelper.OrgInstance.OnExecute += new DBHelper.CommandExecuteHandler(Instance_OnExecute);
        }

        void Instance_OnExecute(object result, DbCommand command, DbTransaction tran, string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (cmdName.Equals("Insert_Config_DataAccess@" + _subDir)
                || cmdName.Equals("Update_Config_DataAccess@" + _subDir)
                || cmdName.Equals("Delete_Config_DataAccess@" + _subDir))
                this.ClearCache(args["Name"].ToString() + ".sql");
        }

        public override List<string> Items()
        {
            throw new ApplicationException("SqlConfig doesn't support items()");
        }


        public override bool HasConfig(string name)
        {
            throw new ApplicationException("SqlConfig doesn't support HasConfig(),just objectfactory use this method now(kevin.zou 2010.1.23)");
        }

        public override T Parse<T>(string name, out string path)
        {
            if (typeof(T) != typeof(Dictionary<string, string>))
                throw new ApplicationException("AutoSqlConfig can only Parse Dictionary<string,string>");
            path = null;        //無cache文件依賴
            name = name.Replace(".sql", "");

            Database db = ObjectFactory.Default.Get<Database>("Database_" + _subDir);

            //不這樣做，因為可以自己調用ObjectFactory.Default.Register注冊
            //Database db = null;
            //if (db == null)
            //{
            //    string cfgConn = System.Configuration.ConfigurationManager.AppSettings["SqlConfig_" + _subDir];
            //    if (cfgConn == null)
            //        cfgConn = "server=172.19.8.6;database=NewWeb2;uid=sa;pwd=pciwebgroup";
            //    string type = System.Configuration.ConfigurationManager.AppSettings["SqlConfig_" + _subDir + "_Type"];
            //    if (type == null)
            //        type = "sql";
            //    db = new Database(type, cfgConn);
            //}
            string cfgSql = "SELECT * FROM Config_DataAccess Where Name= '" + name + "'";
            //Console.WriteLine("Sql Config:" + cfgSql);
            DataSet ds = db.ExecuteDataSet(CommandType.Text, cfgSql);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                Dictionary<string, string> ret = new Dictionary<string, string>();

                foreach (DataColumn dc in ds.Tables[0].Columns)
                    ret.Add(dc.ColumnName, ds.Tables[0].Rows[0][dc].ToString());

                return ret as T;
            }
            //else
            //    throw new ApplicationException("Command:" + name + " is not exists in Database_" + _subDir);
            return null;
        }
    }
    */
}