﻿//非主資料庫事務同步原理
//將非當前資料庫的操作轉化成當前資料庫WEB_META_EXRECORD的insert動作
//同步作業的特點：必須是與主事務可斷，可重試，加入先后順序無關，只有同一BATCHID要滿足先后執行
//利用當機，資料庫掛，網路不通，磁碟已滿等的低機率，與人工通過log檢核機制，來判斷某個執行是否成功或失敗，然後再刪除或重試
//因為資料庫的預寫機制在此不適用，那個可以還原，可是這里，郵件,簡訊已發出，文件已刪除，另一個系統已執行，無法再回滾
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Text;
using PCIWeb;

namespace PCIWeb.Tools
{
    public class SynTranHelper
    {
        //public static readonly SynTranHelper Instance = new SynTranHelper();
        
        //目前有哪些資料庫存有WEB_META_EXRECORD資料表，需要處理
        ArrayList exDBList;
        string exTable = "WEB_META_EXRECORD";

        public SynTranHelper(ArrayList exDBList)
        {
            this.exDBList = exDBList;// SystemConfig.Instance.Get<ArrayList>("WEB_META_EXRECORD_DB_LIST");
            lock (_lockTranListObj)
            {
                this.init();
            }
        }

        static object _lockTranListObj = new object();
        Dictionary<string, Dictionary<string, object>> tranList = new Dictionary<string, Dictionary<string, object>>();
        Dictionary<string, List<string>> requestTranList = new Dictionary<string, List<string>>();
        
        //當前request的某個transaction等待要執行的tranList
        Dictionary<string, List<string>> requestWaitExecTranList = new Dictionary<string, List<string>>();
        
        //某個request(線程)的當前是否有正在執行的Ex ID(如果從這里面又出來的tran，其ExID會不一樣)
        Dictionary<string, string> requestCurrentTranID = new Dictionary<string, string>();

        //當前正在執行的batch list
        List<string> currentExecBatch = new List<string>();
        static object _lockBatchObj = new object();

        //TRY_MSG如果是START_EXEC_KEY_WORD開頭的，則說明需要人工干預，不能job執行
        const string START_EXEC_KEY_WORD = "START_EXEC_TRAN_";
        
        void init()
        {
            Dictionary<string, object> args = new Dictionary<string, object>();
            DBHelper.Instance.NoUseDefaultTran(args);
            foreach (string db in exDBList)
            {
                DataRowCollection drs = Tool.ToRows(DBHelper.Instance.Query("Select_" + exTable + "@" + db, args));
                if (drs != null)
                {
                    foreach (DataRow dr in drs)
                    {
                        //if (!dr["TRY_MSG"].ToString().StartsWith(START_EXEC_KEY_WORD))
                        //{
                            tranList.Add(dr["EX_ID"].ToString(), Tool.ToDic(
                                "Row", Tool.ToDic(dr)
                                , "BatchID", dr["EX_BATCH_ID"]
                                , "Finish", dr["TRY_MSG"].ToString().StartsWith(START_EXEC_KEY_WORD)?"2":"0"           //0未開始，1已完成，2需要人工干預
                                , "DB", db));
                        //}
                    }
                }
            }
        }

        string getBatchFirstTran(string batchID)
        {
            List<string> exList = new List<string>();
            foreach (string exID in tranList.Keys)
            {
                string exBatchID = tranList[exID]["BatchID"].ToString();
                if (exBatchID == batchID)// && tranList[exID]["Finish"].ToString() != "1")
                {
                    exList.Add(exID);
                }
            }
            exList.Sort();
            string ret = exList.Count > 0 ? exList[0] : null;
            if (ret != null)
            {
                return tranList[ret]["Finish"].ToString() == "2" ? null : ret;
            }
            return null;
        }

        #region 定時叫醒job執行接口(每5分鐘)

        static object _lockObj = new object();
        bool isRunning = false;
        public void Run()
        {
            lock (_lockObj)
            {
                if (isRunning)
                {
                    Tool.Warn("還有Job在運行(SynTranHelper JOB)");
                    return;
                }
                isRunning = true;
            }
            try
            {
                removeFinishTran();
                wakeTranExec();
            }
            finally
            {
                lock (_lockObj)
                {

                    isRunning = false;
                }
            }
        }

        #endregion

        //將已完成的tran移除掉，避免記憶體太大
        void removeFinishTran()
        {
            lock (_lockTranListObj)
            {
                List<string> removeKeys = new List<string>();
                foreach (string key in tranList.Keys)
                {
                    string status = tranList[key]["Finish"].ToString();
                    if (status == "1" || status=="2")
                    {
                        removeKeys.Add(key);
                    }
                }
                foreach (string key in removeKeys)
                {
                    tranList.Remove(key);
                }
            }
        }

        void wakeTranExec()
        {
            //按時間順序執行tran
            List<string> execList = new List<string>(tranList.Keys);
            execList.Sort();
            foreach (string tranID in execList)
            {
                RetryTran(tranID);
            }
        }

        public void RetryTran(string exID)
        {
            if (tranList.ContainsKey(exID))
            {
                Dictionary<string, object> tran = tranList[exID];
                string batchID = tran["EX_BATCH_ID"].ToString();
                if (batchID != "")    //有batchID，從第一個開始執行起
                {
                    retryBatch(batchID);
                }
                else
                {
                    retryTran(exID);
                }
            }
        }

        void retryBatch(string batchID)
        {
            bool batchExec;
            lock (_lockBatchObj)
            {
                batchExec = currentExecBatch.Contains(batchID);
                if (!batchExec)
                {
                    currentExecBatch.Add(batchID);
                }
            }
            if(!batchExec)
            {
                string firstExID = getBatchFirstTran(batchID);
                if (firstExID != null)
                {
                    string retryInfo = retryTran(firstExID);
                    if (retryInfo.Length > 0)
                        Tool.Warn("事務處理后的異種事務失敗", "Info", retryInfo);
                    else
                    {
                        tranList[firstExID]["Finish"] = "1";
                        retryBatch(batchID);
                    }
                }
                else
                {
                    lock (_lockBatchObj)
                    {
                        currentExecBatch.Remove(batchID);
                    }
                }
            }
        }

        string retryTran(string exID)
        {
            Dictionary<string, object> tran = tranList[exID];
            Dictionary<string, object> tranDr = tran["Row"] as Dictionary<string, object>;
            string errMsg = "";
            try
            {
                execTran(exID);
            }
            catch (Exception ex)
            {
                errMsg = "重試失敗:" + ex.ToString();// Message;
            }
            if (errMsg.Length == 0)
            {
                try
                {
                    Tool.Trace("開始刪除異種處理執行序列", "ExID", exID);
                    deleteEx(exID, tranList[exID]["DB"].ToString());
                    Tool.Trace("刪除異種處理執行序列完畢", "ExID", exID);
                    return "";
                }
                catch (Exception ex2)
                {
                    return "重試成功，但刪除失敗(！*請注意*：請執行忽略或手動刪除資料，否則可能會重複執行！):" + ex2.Message;
                }
            }
            else
            {
                try
                {
                    Tool.Trace("開始更新異種處理執行序列", "ExID", exID);
                    updateEx(exID, errMsg, int.Parse(tranDr["TRY_COUNT"].ToString()), tran["DB"].ToString());
                    Tool.Trace("更新異種處理執行序列完畢", "ExID", exID);
                    return errMsg;
                }
                catch (Exception ex2)
                {
                    return "重試失敗，記錄失敗(沒關係，可以手動重新執行):" + ex2.Message;
                }
            }
        }

        void execTran(string exID)
        {
            Dictionary<string, object> dr = tranList[exID]["Row"] as Dictionary<string,object>;
            string service = dr["SERVICE"].ToString();
            string jsonArgs = dr["ARGS"].ToString();
            ArrayList argsList = Tool.ToList(jsonArgs);
            object[] args = null;
            if (argsList != null)
            {
                args = new object[argsList.Count];
                argsList.CopyTo(args);
            }
            Tool.Info("開始執行異種處理", "ExID", exID);
            updateExStart(exID, tranList[exID]["DB"].ToString());
            ServiceCaller.Instance.Call(ServiceCaller.CallType.TransactionCall, service, args);
            Tool.Info("異種處理執行完畢", "ExID", exID);
        }

        void updateExStart(string exID, string db)
        {
            Dictionary<string, object> args = Tool.ToDic(
                "EX_ID__W", exID
                , "TRY_TIME", DateTime.Now.ToString("yyyyMMddHHmmss")
                , "TRY_MSG", "START_EXEC_TRAN_" + AppEventHanlder.Instance.RequestID    //START_EXEC_TRAN_開頭表示已經有準備執行了，如果資料庫有這個資料存在，需要去查log為什么沒執行完，至少也要有錯誤訊息吧
            );
            DBHelper.Instance.NoUseDefaultTran(args);
            DBHelper.Instance.Execute("Update_" + exTable + "@" + db, args);
        }

        void deleteEx(string exID, string db)
        {
            Dictionary<string, object> args = Tool.ToDic(
                "EX_ID", exID
            );
            DBHelper.Instance.NoUseDefaultTran(args);
            DBHelper.Instance.Execute("Delete_" + exTable + "@" + db, args);
        }

        void updateEx(string exID, string errInfo, int tryCount, string db)
        {
            Dictionary<string, object> args = Tool.ToDic(
                "EX_ID__W", exID
                , "TRY_TIME", DateTime.Now.ToString("yyyyMMddHHmmss")
                , "TRY_COUNT", tryCount + 1
                //第一次錯誤（可能是程式原始執行的錯誤，應該和后面重試時的錯誤分開來）
                , tryCount == 0 ? "EX_MSG" : "TRY_MSG", errInfo.Length > 200 ? errInfo.Substring(0, 190) : errInfo
            );
            DBHelper.Instance.NoUseDefaultTran(args);
            DBHelper.Instance.Execute("Update_" + exTable + "@" + db, args);
        }

        //AP調用
        public void AddOtherDeal(string requestID, string batchID,string service, object[] args)
        {
            string exID = IdGenerator.Instance.NextNo("EX", "DealingException");
            string argsJson = Tool.ToJson(args);
            Dictionary<string, object> row = Tool.ToDic(
                "EX_ID", exID
                , "EX_BATCH_ID", batchID      //批次執行ID，同一ID需按時間先后順序執行
                , "SERVICE", service
                , "ARGS", argsJson          //新增時再序列化可能有些引用的值變掉了，所以直接記錄
                , "TRY_COUNT", 0          //0執行了幾次
                , "EX_TIME", DateTime.Now.ToString("yyyyMMddHHmmss")
                , "EX_MSG", "待Job執行(Waiting Job Execute)"
                , "USER_ID", AuthenticateHelper.Instance.UserID
                , "REQUEST_IP", AppEventHanlder.Instance.UserHost
                , "REQUEST_ID", AppEventHanlder.Instance.RequestID
                );
            tranList.Add(exID, Tool.ToDic(
                                "Row", row
                                , "BatchID", batchID
                                , "Finish", "0"           //0未開始，1進行中，2已完成（可以刪除了）
                                ));
            //一定是某個request調用的，所以這里沒有多線程問題
            if (!requestTranList.ContainsKey(requestID))
            {
                requestTranList[requestID] = new List<string>();
            }
            requestTranList[requestID].Add(exID);
        }

        //Commit事務前調用
        public string InsertRequestTrans(string requestID,string db)
        {
            //執行insert
            if(requestTranList.ContainsKey(requestID))
            {
                List<string> trans = requestTranList[requestID];
                foreach(string tranID in trans)
                {
                    Dictionary<string, object> insertArgs = tranList[tranID]["Row"] as Dictionary<string, object>;
                    DBHelper.Instance.Execute("Insert_" + exTable + "@" + db, insertArgs);
                }
                //移走TranList
                requestWaitExecTranList.Add(requestID, requestTranList[requestID]);
                requestTranList.Remove(requestID);
            }
            return requestID;
        }

        //Commit事務提交后調用
        public void CommitTran(string requestID)
        {
            if (requestWaitExecTranList.ContainsKey(requestID))
            {
                foreach (string tranID in requestWaitExecTranList[requestID])
                {
                    RetryTran(tranID);
                }
            }
        }


        /*
        //2分鐘job重試
        public void Retry()         //log開始執行,update開始執行，執行，再回報(如無回報，則看是否開始執行，如果是，則人工干預，否則直接可重試)
        {

        }

        public void Ignore()        //刪除
        {

        }

        //Rollback事務時調用
        public void RollbackDeal(string requestID)
        {

        }
        public string Retry(string exID, string db)
        {
            DataSet ds = DBHelper.Instance.Query("Select_" + exTable + "@" + db, Tool.ToDic(
                "EX_ID", exID
            ));
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count == 1)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                string errMsg = retry(dr, db);
                if (errMsg.Length > 0)
                    throw new PCIBusException(errMsg);
                else
                    return "重試成功";
            }
            else
                throw new PCIBusException("未找到(或有多筆)異常處理:" + exID);
        }

        string retry(DataRow dr, string db)
        {
            string exID = dr["EX_ID"].ToString();
            string batchID = dr["EX_BATCH_ID"].ToString();
            if (batchID.Length > 0)
            {
                DataSet ds2 = DBHelper.Instance.Query("Select_" + exTable + "@" + db, Tool.ToDic(
                    "EX_ID__L", exID     //小于這個ID
                    , "EX_BATCH_ID", batchID
                ));
                if (ds2 != null && ds2.Tables.Count > 0 && ds2.Tables[0].Rows.Count > 0)
                {
                    //Tool.Trace("該批次還有更早的Ex未執行成功，因此不能執行", "ExID", exID, "BatchID", batchID, "Count", ds2.Tables[0].Rows.Count
                    //    , "第1筆ExID", ds2.Tables[0].Rows[0]["ExID"].ToString());
                    return "該批次還有更早的Ex未執行成功，因此不能執行(BatchID:" + batchID + ",筆數:" + ds2.Tables[0].Rows.Count + ",第1筆ID:" + ds2.Tables[0].Rows[0]["EX_ID"].ToString() + ")";
                }
            }

            string errMsg = "";
            try
            {
                retryEx(dr);
            }
            catch (Exception ex)
            {
                errMsg = "重試失敗:" + ex.ToString();// Message;
            }

            if (errMsg.Length == 0)
            {
                try
                {
                    Tool.Trace("開始刪除異種處理執行序列", "ExID", exID);
                    deleteEx(exID, db);
                    Tool.Trace("刪除異種處理執行序列完畢", "ExID", exID);
                    return "";
                }
                catch (Exception ex2)
                {
                    //Tool.Error("重試成功，但刪除失敗(！*請注意*：請執行忽略或手動刪除資料，否則可能會重複執行！)", "exID", exID, "ex2", ex2);
                    return "重試成功，但刪除失敗(！*請注意*：請執行忽略或手動刪除資料，否則可能會重複執行！):" + ex2.Message;
                }
            }
            else
            {
                try
                {
                    Tool.Trace("開始更新異種處理執行序列", "ExID", exID);
                    updateEx(exID, errMsg, int.Parse(dr["TRY_COUNT"].ToString()), db);
                    Tool.Trace("更新異種處理執行序列完畢", "ExID", exID);
                    return errMsg;
                }
                catch (Exception ex2)
                {
                    //Tool.Info("重試失敗，記錄失敗(沒關係，可以手動重新執行)", "exID", exID, "ex2", ex2);
                    return "重試失敗，記錄失敗(沒關係，可以手動重新執行):" + ex2.Message;
                }
            }
        }

        void deleteEx(string exID, string db)
        {
            Dictionary<string, object> args = Tool.ToDic(
                "EX_ID", exID
            );
            DBHelper.Instance.NoUseDefaultTran(args);
            DBHelper.Instance.Execute("Delete_" + exTable + "@" + db, args);
        }

        public string Ignore(string exID, string db)
        {
            try
            {
                deleteEx(exID, db);     //錯誤的話，直接會正常的Exception回去
                return "忽略成功，已刪除";
            }
            catch (Exception ex)
            {
                throw new PCIBusException("刪除Ex失敗:" + ex.Message);     //轉成PCIBusException,表示是用戶邏輯失敗
            }
        }

        */
    }
}
