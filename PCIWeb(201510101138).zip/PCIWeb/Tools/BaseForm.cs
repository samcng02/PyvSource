/*
 * 2011.6.10
 * kevin.zou
 * �H���A�r�q�@���y�{�B�઺�覡�]���Ǭy�{�A���Τ_�}��y�{�A�p�@�ӥ��Ȥ��t���h�ӤH�æ�i��^
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace PCIWeb.Tools
{
    public abstract class BaseForm : FlowForm//, IService
    {

        public class TaskSet
        {
            public string Task;
            public string Status;
            public bool ValidTaskRight;         //�O�_�ݭn���ӥ��Ȫ��v��
            public bool FieldIsActorID;         //DataRightField�����ȡA�O���O�N�O�B�z�̪��Τ�ID
            public string DataRightKind;        //�p�G��null�ΪšA�h��BaseKind.Task
            public string DataRightField;       //�ƾ��v�����W
            public string FieldInitExp;         //DataRightField������l�ƪ��F��
            public string TaskRightKind;        //�q�{��TaskRightKind
            public string TaskRightData;        //�q�{��Task.���ȦW
            public string AllowActions;         //�ӥ��Ȥ��\���ʧ@
        }

        /// <summary>
        /// �Ψӻ��UStatus�A�}�B�������eStatus�����ȳB�z�H�O�֪����W
        /// </summary>
        protected string FlowDealerField
        {
            get
            {
                return FlowFieldPrefix + DealerField;
            }
        }

        protected string FlowStatusField
        {
            get
            {
                return FlowFieldPrefix + StatusField;
            }
        }

        public virtual string BaseKind
        {
            get
            {
                return this.flowNo;// FormTable.Replace("_Form", "");
            }
        }

        string flowNo;

        public BaseForm()
        {
            this.initParams();
            initStateFlow(FormTable.Replace("_Form", ""));      //default flow no
        }

        public BaseForm(string flowNo)
        {
            //this.initParams();        //BaseForm�u�nflowNo
            initStateFlow(flowNo);
        }

        #region override FlowForm ��k(�D�n�O���l�ȶi��]�w)(�ҥH�l���Aoverride,���ӥ[�WBase.XXX)

        protected virtual void initParams()
        {
            Database = "Flow";
            KeyField = "FormNo";
            StatusField = "Status";
            NoPrefix = "";
            refKeys = "";
            refJoin = "";
            dealActions = "Pass,Back";
            _initStatus = "New";
        }

        void initStateFlow(string flowNo){
            this.flowNo = flowNo;
            _stateFlow = new StateFlow(BaseKind);

            _agentSet = new AgentSet();
            _noticeSet = new NoticeSet();

            _taskSet = new Dictionary<string, TaskSet>();
            initTaskSet();

            _taskActionSet = new Dictionary<string, string[]>();
            initTaskActionSet();

            _statusEvents = new Dictionary<string, string[]>();
            initStatusEvents();

        }

        public Dictionary<string, List<string>> ActionStatus()
        {
            return _stateFlow.ActionStatus;
        }

        public Dictionary<string, List<string>> StatusAction()
        {
            return _stateFlow.StatusAction;
        }


        protected virtual string StatusMarkField
        {
            get
            {
                return "StatusMark";
            }
        }

        protected virtual string DealerField
        {
            get
            {
                return "Dealer";
            }
        }


        //�@���q�{����s���A�pStatusMark�@����s
        //�p�G�l����StatusMark���O�o�ӷN��A�h�ioverride����k�A�}���\������
        protected virtual void defaultBeforeActionUpdate(Dictionary<string, object> form, string oldStatus, string newStatus, string formno, string action, string flowUserID, Dictionary<string, object> args, Dictionary<string, object> updateArgs, bool hasNewStatus)
        {
            if(StatusMarkField!=null && StatusMarkField.Length>0)
                updateArgs.Add(StatusMarkField, DateTime.Now.ToString("yyyyMMddHHmmssfff"));        //�o�������q���n�F(�N��Update�]�S���Y)

        }

        protected override void beforeActionUpdate(Dictionary<string, object> form, string oldStatus, string newStatus, string formno, string action, string flowUserID, Dictionary<string, object> args, Dictionary<string, object> updateArgs, bool hasNewStatus)
        {
            fillFieldInitExp(form, oldStatus, newStatus,  action, flowUserID, args, updateArgs, hasNewStatus);
            defaultBeforeActionUpdate(form, oldStatus, newStatus, formno, action, flowUserID, args, updateArgs, hasNewStatus);
        }

        protected virtual void fillFieldInitExp(Dictionary<string, object> form, string oldStatus, string newStatus, string action, string flowUserID, Dictionary<string, object> args, Dictionary<string, object> updateArgs, bool hasNewStatus)
        {
            if (hasNewStatus)       //�u���b���s���A�ɡA�N��BossCheck->BossCheck�~�ݭn�o�ӡA�ӹ��@��Update,CheckUpdate,MakeCost�o�˪��h���ݭn
            {
                foreach (string task in _taskSet.Keys)
                {
                    string status = _taskSet[task].Status;
                    if (status == newStatus)        //���A�ǰt���ɭԶ}�l
                    {
                        string initExp = _taskSet[task].FieldInitExp;
                        if (initExp != null && initExp.Length > 0)
                        {
                            string field = FlowDealerField;       //�`�N�����O��field�u��OFlow���������A�_�h���|��s
                            if (field.StartsWith(FlowFieldPrefix))
                            {
                                field = field.Substring(5);
                                string result = _stateFlow.CalculateExpression(initExp, Tool.ToDic("FlowUserID", flowUserID, "OldStatus", oldStatus, "NewStatus", newStatus, "Action", action), form, args);
                                updateArgs[field] = result;
                            }
                            else
                                throw new ApplicationException("��l�ƪ��F���u�ରFlow���������:" + task + "," + field + "," + initExp);
                        }
                    }
                }
            }
        }
        

        #endregion

        #region �ݭn�Υi�H�b�l����override����k�����

        protected Dictionary<string, TaskSet> _taskSet;

        protected virtual string TaskRightKind
        {
            get
            {
                return BaseKind + ".Task";
            }
        }

        protected string getDBFieldStr(DataRow dr, string field)
        {
            if (dr[field] == DBNull.Value)
                return "";
            else
                return dr[field].ToString();
        }

        protected virtual void initTaskSet()
        {
            //Key:���ȦW
            //Value:
            //0.���O(�ثe�u��UserField,FieldRight)
            //1.���A
            //2.���\���ʧ@(�γr�����}�A�pñ�֤H���A����ե�withdraw��k)[�i��,�p�G�S���A���ܩҦ��ʧ@�Ҥ��\]
            //3.��l�ƪ��F��(StateFlow�ӭp��)
            //4.�O�_�n���ҥ����v��(�v�����OTaskRightKind)(1�n�A0���n)
            //5.�v�����W(�v�����O�q�{��BaseKind + "." + ���ȦW)[�i��]
            //6.�v�����O(�p�G���A�hFieldRight�A�i�H�۩w�q�v�����O,UserField�����L��)[�i��]
            /*
            _taskSet.Add("ManagerCheck", new string[] { "UserField", "ManagerCheck","","","0","Manager"});
            _taskSet.Add("BossCheck", new string[] { "FieldRight", "BossCheck","","","1"});
            _taskSet.Add("PreMakeCheck", new string[] { "FieldRight", "PreMakeCheck","","","0","PreMakeKind","Pwm.PreMake"});
            _taskSet.Add("Check", new string[] { "FieldRight", "Check","","","0","Flow_Dealer"});
            */

            DataSet ds = DBHelper.Instance.Query("Select_WF_StateTask@Flow", Tool.ToDic("FlowNo", BaseKind));
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    TaskSet taskSet = new TaskSet();
                    taskSet.Task = getDBFieldStr(dr, "Task");
                    taskSet.Status = getDBFieldStr(dr, "Status");
                    taskSet.AllowActions = getDBFieldStr(dr, "AllowActions");
                    taskSet.FieldInitExp = getDBFieldStr(dr, "FieldInitExp");
                    taskSet.ValidTaskRight = getDBFieldStr(dr, "ValidTaskRight") == "1";
                    string taskRightKind = getDBFieldStr(dr, "TaskRightKind");
                    taskSet.TaskRightKind = taskRightKind.Length == 0 ? TaskRightKind : taskRightKind;
                    string taskRightData = getDBFieldStr(dr, "TaskRightData");
                    taskSet.TaskRightData = taskRightData.Length == 0 ? taskSet.Task : taskRightData;
                    taskSet.FieldIsActorID = getDBFieldStr(dr, "FieldIsActorID") == "1";
                    string dataRightKind = getDBFieldStr(dr, "DataRightKind");
                    taskSet.DataRightKind = dataRightKind.Length == 0 ? BaseKind + "." + taskSet.Task : dataRightKind;
                    _taskSet.Add(taskSet.Task, taskSet);
                }
            }


        }

        AgentSet _agentSet;

        protected virtual string getAgentKind(string task)
        {
            //��^null���ܦ��جy�{���ϥΥN�z
            //�q�{�@�ت���u�Τ@�إN�z���O(�p�G�n���P�A��override����k)
            return BaseKind;
        }

        NoticeSet _noticeSet;

        protected virtual string NoticeKind
        {
            get
            {
                return BaseKind;
            }
        }

        protected Dictionary<string, string[]> _taskActionSet;

        protected virtual void initTaskActionSet()
        {
            /*
            //Action,Form�D���ק諸���AFormFlow�ק諸���AWF_Step���ƪ`���
            //�O�_�n����ñ�]���󬣨��^�A���]�O�_�o²�T�T�{�^�A�ƪ`
            //�p�G�b�o���S�[�J�A�h���ܰʧ@�u�O���ܪ��A�A�䥦������
            //���OTask Action�H�~���ʧ@���ઽ���o�ˡA�pApply,ForceBack���A�]��Task�O���Ҥ��q�L
            _taskActionSet.Add("Back", new string[] { "", "DealMemo", "DealMemo", "PCIWeb.Odd.Form.Back" });
             */
            DataSet ds = DBHelper.Instance.Query("Select_WF_StateAction@Flow", Tool.ToDic("FlowNo", BaseKind));
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string action = getDBFieldStr(dr, "Action");
                    string formFields = getDBFieldStr(dr, "FormFields");
                    string flowFields = getDBFieldStr(dr, "FlowFields");
                    string stepFields = getDBFieldStr(dr, "StepFields");
                    string validName = getDBFieldStr(dr, "ValidName");
                    string eventsService = getDBFieldStr(dr, "EventsService");      //���o�Ӱʧ@�Z�A�ݭn�դ��\�~��service
                    _taskActionSet.Add(action, new string[] { formFields, flowFields, stepFields, validName, eventsService });
                }
            }
        }

        protected TaskSet getTaskSet(string task)
        {
            if (!_taskSet.ContainsKey(task))
                throw new ApplicationException("�S���]�w�o�إ���(_taskSet�b_initTaskSet��):" + task);
            return _taskSet[task];
        }

        #endregion

        #region �������

        /// <summary>
        /// �Y�������v������Ȫ���
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="setting"></param>
        /// <returns></returns>
        protected virtual Dictionary<string, object> getUserTask(string userID, string task)
        {
            TaskSet setting = getTaskSet(task);

            //���ҬO�_�ݭn�����v��
            //if (setting.ValidTaskRight && !RightsProvider.Instance.HasRight(userID, TaskRightKind, setting.Task))
            if (setting.ValidTaskRight && !RightsProvider.Instance.HasRight(userID, setting.TaskRightKind, setting.TaskRightData))
                    return null;

            Dictionary<string, object> args = new Dictionary<string, object>();
            args[FlowStatusField] = setting.Status;

            //�O�_�ݭn��DealerField�i���v���ΥΤ�ID�ۤǰt�L�o
            string filterStr = "";
            if (setting.FieldIsActorID)
                filterStr += userID;

            if (setting.FieldInitExp != null && setting.FieldInitExp.Length > 0)
            {
                string rightKind = setting.DataRightKind;// BaseKind + "." + setting.Task;       //�pOdd.LemCheck
                if (!RightsProvider.Instance.HasAllRight(rightKind, userID))
                {

                    List<string> rights = RightsProvider.Instance.RightsData(rightKind, userID);
                    if (rights != null && rights.Count > 0)
                    {
                        foreach (string right in rights)
                            filterStr += (filterStr.Length > 0 ? "," : "") + right;
                    }

                    if (filterStr == null || filterStr.Length == 0)
                        return null;

                    args[FlowDealerField + "__IN"] = filterStr;          //�bSqlFunction���|���C�@���[�W��޸�


                }
                //else �֦��Ҧ��v���A���L�o
            }
            else if (filterStr.Length > 0)      //�u�O�ݭn�Τ�ǰt
            {
                args[FlowDealerField] = userID;
            }
            return getForms(args, "", 0, 1);
        }

        protected virtual Dictionary<string, Dictionary<string, object>> getUserAgentTask(string userID, string task)
        {
            Dictionary<string, Dictionary<string, object>> ret = new Dictionary<string, Dictionary<string, object>>();
            string agentKind = getAgentKind(task);
            if (agentKind != null)
            {
                Dictionary<string, string> agents = _agentSet.GetAgented(agentKind, userID);
                if (agents != null)
                {
                    foreach (string agentedID in agents.Keys)
                    {
                        string key = agentedID + "#" + agents[agentedID];
                        ret.Add(key, getUserTask(agentedID, task));
                    }
                }
            }
            return ret;
        }

        protected virtual Dictionary<string, Dictionary<string, object>> getTask(string userID, string task)
        {
            Dictionary<string, Dictionary<string, object>> ret = getUserAgentTask(userID, task);
            ret.Add("", getUserTask(userID, task));
            return ret;
        }

        public virtual Dictionary<string, Dictionary<string, Dictionary<string, object>>> GetAllTask(string userID)
        {
            Dictionary<string, Dictionary<string, Dictionary<string, object>>> ret = new Dictionary<string, Dictionary<string, Dictionary<string, object>>>();
            foreach (string task in _taskSet.Keys)
                ret.Add(task, getTask(userID, task));
            return ret;
        }

        public virtual Dictionary<string, Dictionary<string, object>> GetTask(string task)
        {
            return getTask(PCIWeb.AuthenticateHelper.Instance.UserID, task);
        }

        public virtual Dictionary<string, Dictionary<string, Dictionary<string, object>>> GetAllTask()
        {
            return GetAllTask(PCIWeb.AuthenticateHelper.Instance.UserID);
        }

        /// <summary>
        /// �H��榡��^��(�H�Z�i�H�Ҽ{����)
        /// </summary>
        /// <returns></returns>
        public List<Dictionary<string, object>> GetAllTaskList()
        {
            List<Dictionary<string,object>> ret = new List<Dictionary<string,object>>();
            Dictionary<string, Dictionary<string, Dictionary<string, object>>> tasks = GetAllTask();
            foreach(string task in tasks.Keys)
            {
                foreach(string user in tasks[task].Keys)
                {
                    Dictionary<string,object> rows = tasks[task][user];
                    if(rows!=null && int.Parse(rows["Count"].ToString())>0) //�S���v����
                    {
                        DataRowCollection drs = rows["Rows"] as DataRowCollection;
                        if(drs!=null)
                        {
                            foreach(DataRow dr in drs)
                            {
                                Dictionary<string,object> dic = Tool.ToDic(dr);
                                dic["TaskKind"] = task;
                                string agentUserID = "";
                                string agentUser = "";
                                if(user.Length > 0)
                                {
                                    string[] agents = user.Split(new char[] { '#' }, 2);
                                    agentUserID = agents[0];
                                    agentUser = agents[1];
                                }
                                dic["AgentUserID"] = agentUserID;
                                dic["AgentUser"] = agentUser;

                                ret.Add(dic);
                            }
                        }
                    }
                }
            }
            return ret;
        }

        public List<Dictionary<string, object>> GetAllTaskList(string task)
        {
            List<Dictionary<string, object>> ret = new List<Dictionary<string, object>>();
            Dictionary<string, Dictionary<string, object>> tasks = GetTask(task);
            foreach (string user in tasks.Keys)
            {
                Dictionary<string, object> rows = tasks[user];
                if (int.Parse(rows["Count"].ToString()) > 0)
                {
                    DataRowCollection drs = rows["Rows"] as DataRowCollection;
                    if (drs != null)
                    {
                        foreach (DataRow dr in drs)
                        {
                            Dictionary<string, object> dic = Tool.ToDic(dr);
                            dic["TaskKind"] = task;
                            string agentUserID = "";
                            string agentUser = "";
                            if (user.Length > 0)
                            {
                                string[] agents = user.Split(new char[] { '#' }, 2);
                                agentUserID = agents[0];
                                agentUser = agents[1];
                            }
                            dic["AgentUserID"] = agentUserID;
                            dic["AgentUser"] = agentUser;

                            ret.Add(dic);
                        }
                    }
                }
            }
            return ret;
        }


        public virtual string[] GetAllTaskForm()
        {
            return GetAllTaskForm(PCIWeb.AuthenticateHelper.Instance.UserID);
        }

        public virtual string[] GetAllTaskForm(string userID)
        {
            if (!userID.EndsWith(".00"))
                userID = userID + ".00";        //����Ǫ��ɭԱ��F.00
            List<string> ret = new List<string>();
            Dictionary<string, Dictionary<string, Dictionary<string, object>>> tasks = GetAllTask(userID);
            foreach (string task in tasks.Keys)
            {
                if (tasks[task] != null)
                {
                    foreach (string user in tasks[task].Keys)
                    {
                        if (tasks[task][user] != null)
                        {
                            DataRowCollection rows = tasks[task][user]["Rows"] as DataRowCollection;
                            if (rows != null && rows.Count > 0)
                            {
                                foreach (DataRow dr in rows)
                                {
                                    string formNo = dr[KeyField].ToString();
                                    if (!ret.Contains(formNo))
                                        ret.Add(formNo);
                                }
                            }
                        }
                    }
                }
            }
            if (ret.Count == 0)
                return null;
            string[] tmp = new string[ret.Count];
            ret.CopyTo(tmp);
            return tmp;
        }

        #endregion

        #region �������

        protected virtual bool validTaskRight(string userID, string formNo, string task, string action, Dictionary<string, object> args)
        {
            TaskSet setting = getTaskSet(task);

            //���Ȫ��A�P��ڪ��A�O�_�۵�����
            DataRow dr = getFormByNo(formNo);
            string status = setting.Status;
            string formStatus = dr[FlowStatusField].ToString();
            if (formStatus != status)
                throw new PCIBusException("�o�i��ڥi��w�Q�B�z�L,�Ш�s����(please refresh again)<br>�{�����H��:����" + task + "���A" + status + "�P���" + formNo + "���A" + formStatus + "���@�P");


            //���ҥ��ȬO�_�i�H�i��Y���ʧ@
            string allowActions = setting.AllowActions;
            if (allowActions != null && allowActions.Length > 0)
            {
                //�pPass�MBack�O���e���ȤH���i�i�檺�A���OCancel�u��O�W�@�����H�i�H�i��A��Withdraw�h�u���ӽЪ̤~�i�H
                if (("," + allowActions + ",").IndexOf("," + action + ",") < 0)
                    throw new PCIBusException("�o�i��ڥi��w�Q�B�z�L,�Ш�s����(please refresh again)<br>�{�����H��:����" + task + "�u���\:" + allowActions + "�A�]������i��" + action);
            }

            //���ҬO�_�ݭn�����v��
            //if (setting.ValidTaskRight && !RightsProvider.Instance.HasRight(userID, TaskRightKind, task))
            if (setting.ValidTaskRight && !RightsProvider.Instance.HasRight(userID, setting.TaskRightKind, setting.TaskRightData))
            {
                Tool.Trace("�L�����v��", "userID", userID, "TaskRightKind", TaskRightKind, "task", task);
                return false;   //�L�����v�� 
                //throw new ApplicationException("�S�������v��:" + TaskRightKind + ":" + task);
            }

            //���ݭn�ƾ��v��(�u�n�����v��)
            if (!setting.FieldIsActorID && (setting.FieldInitExp == null || setting.FieldInitExp.Length == 0))
                return true;

            if (setting.FieldIsActorID && userID == dr[FlowDealerField].ToString())
                return true;
            else if (setting.FieldInitExp != null && setting.FieldInitExp.Length > 0)
            {
                string rightKind = setting.DataRightKind;// BaseKind + "." + task;       //�pOdd.LemCheck
                return RightsProvider.Instance.HasRight(userID, rightKind, dr[FlowDealerField].ToString());
            }
            Tool.Trace("�L�ƾ��v��", "userID", userID, "FieldIsActorID", setting.FieldIsActorID
                , "FieldInitExp", setting.FieldInitExp, "DealerField", dr[FlowDealerField].ToString()
                , "rightKind", setting.DataRightKind);
            return false;
        }

        protected virtual void beforePerformTask(string actUserID, string formNo, string task, string action, Dictionary<string, object> args, string flowUserID)
        {

        }

        protected virtual void afterPerformTask(string actUserID, string formNo, string task, string action, Dictionary<string, object> args, string flowUserID)
        {

        }

        //return StepMemo
        //�ioverride����k�A�[�Wif task==���\�Ӧ۩w�q�A�M��base.performTaskByTaskActionSet�O���䥦�q��
        protected virtual string performTaskByTaskActionSet(string actUserID, string formNo, string task, string action, Dictionary<string, object> args, string flowUserID, out Dictionary<string, object> updateFlowValues)
        {

            updateFlowValues = null;
            string stepMemo = "";
            if (_taskActionSet.ContainsKey(action))
            {
                string[] taskActionSet = _taskActionSet[action];
                string formUpdateFields = taskActionSet[0];
                string flowUpdateFields = taskActionSet[1];
                string stepMemoFields = taskActionSet[2];
                string validName = taskActionSet[3];

                //�p�h��ɥ�����J��]�b�o������
                if (validName.Length > 0)
                {
                    if (validName.StartsWith("$"))
                        ServiceCaller.Instance.Call(ServiceCaller.CallType.BaseCall, validName.Substring(1), formNo, args);
                    else 
                        ValidateHelper.Instance.Valid(args, validName);
                }

                if (!formUpdateFields.StartsWith("$"))
                {
                    Dictionary<string, object> updateFormValues = filterArgs(args, formUpdateFields, actUserID, formNo, task, action, flowUserID);
                    if (updateFormValues != null && updateFormValues.Count > 0)
                    {
                        updateFormValues[KeyField] = formNo;
                        updateNoAddStep(updateFormValues);
                    }
                }
                else  //$���ܬOservice�W��
                {
                    string service = formUpdateFields.Substring(1);
                    ServiceCaller.Instance.Call(ServiceCaller.CallType.BaseCall, service, formNo,args);
                }

                updateFlowValues = filterArgs(args, flowUpdateFields, actUserID, formNo, task, action, flowUserID);

                Dictionary<string, object> stepMemoValues = filterArgs(args, stepMemoFields, actUserID, formNo, task, action, flowUserID);
                if (stepMemoValues != null && stepMemoValues.Count > 0)
                {
                    foreach (string memoKey in stepMemoValues.Keys)
                        stepMemo += " " + (stepMemoValues[memoKey]!=null?stepMemoValues[memoKey].ToString():"");
                }
            }
            return stepMemo;
        }

        protected virtual string getStepInfo(DataRow beforeDr,string formNo, string action, string flowUserID, Dictionary<string,object> args, Dictionary<string,object> updateFlowValues, string oldStatus, string newStatus)
        {
            return beforeDr[FlowDealerField].ToString();            //�q�{�N���e�B�z�̪��ҭʥM��flow_dealer�ȫO�s�_�ӡA���M�l���i�Hoverride����k�A��ܱM�����ȫO�s
        }

        //�ioverride����k,���ѯS�����y�{�B�z���(�]�AActionStep�]�ۤv�g)
        protected virtual void innerPerformTask(string actUserID, string formNo, string task, string action, Dictionary<string, object> args, string flowUserID)
        {
            Dictionary<string, object> updateFlowValues;
            string stepMemo = performTaskByTaskActionSet(actUserID, formNo, task, action, args, flowUserID, out updateFlowValues);
            string oldStatus;
            string newStatus;
            DataRow beforeDr = getFormByNo(formNo);
            doAction(formNo, action, flowUserID, args, updateFlowValues, out oldStatus, out newStatus); 
            string info = getStepInfo(beforeDr,formNo, action, flowUserID, args, updateFlowValues, oldStatus, newStatus);
            addActionStep(formNo, action, stepMemo, flowUserID,oldStatus,newStatus,info);
        }

        protected virtual DataRow performTask(string actUserID, string formNo, string task, string action, Dictionary<string, object> args, string flowUserID)
        {
            //if (!_taskActionSet.ContainsKey(action))
            //    throw new ApplicationException("�S���]�w�o�عB�@��_taskActionSet:" + action);
            beforePerformTask(actUserID, formNo, task, action, args, flowUserID);



            innerPerformTask(actUserID, formNo, task, action, args, flowUserID);

            afterPerformTask(actUserID, formNo, task, action, args, flowUserID);
            return getFormByNo(formNo);
        }


        protected virtual object getFixedValue(string fixedValue, Dictionary<string, object> args, string key, string fields, string actUserID, string formNo, string task, string action, string flowUserID)
        {
            //�Ȯɳo�˼g�]�]���ثe�S�I��䥦���p
            //�p�G���A�i�H�Ҽ{��StateFlow��Expression�ӧ����A���M�o���֤F�@�ǰѼ�
            if (fixedValue == "@FlowUserID")
            {
                return flowUserID;
            }
            else if (fixedValue == "@Today")
            {
                return DateTime.Today.ToString("yyyyMMdd");
            }
            else if (fixedValue == "@Now")
            {
                return DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            else if (fixedValue.StartsWith("$"))
            {
                return args.ContainsKey(fixedValue.Substring(1)) ? args[fixedValue.Substring(1)].ToString() : fixedValue;
            }
            return fixedValue??"";
        }


        protected virtual Dictionary<string, object> filterArgs(Dictionary<string, object> args, string fields, string actUserID, string formNo, string task, string action, string flowUserID)
        {
            Dictionary<string, object> ret = null;
            if (fields != null && fields.Length > 0)
            {
                ret = new Dictionary<string, object>();
                string[] addFields = fields.Split(new char[] { ',' });
                foreach (string key in addFields)
                {
                    if (key.IndexOf("=") > 0)
                    {
                        string[] keyTmp = key.Split(new char[] { '=' }, 2);
                        string fixedValue = keyTmp[1];
                        ret.Add(keyTmp[0], getFixedValue(fixedValue, args, key, fields, actUserID, formNo, task, action, flowUserID));
                    }
                    //��valid����A�o���P�_�A�K�o���`(���L�e�ݵ{���]�קK�����`)
                    else
                    {
                        try
                        {
                            ret.Add(key, args[key] ?? "");
                        }
                        catch (System.Collections.Generic.KeyNotFoundException kex)
                        {
                            Tool.Error("key is not exists.","task",task,"action",action,"key",key,"kex",kex.Message);
                            throw;
                        }
                    }
                }
            }
            return ret;
        }

        //����@�i��u��P�ɥѤ@�ӤH�B�z(���M�]�s�b�A�b�f�A�L�b�M��A���]�o�ͱ��p�֡A�ҥH������@��X��)
        //kevin.zou 2011.10.18�`

        List<string> dealingList = new List<string>();
        object _lockDealingObject = new object();

        protected virtual void lockFormDealing(string formNo)
        {
            lock (_lockDealingObject)
            {
                if (!dealingList.Contains(formNo))
                {
                    dealingList.Add(formNo);
                    return;
                }
            }
            throw new PCIBusException("���H���b�B�z����ڡA�Ш�s����(someone is dealing this data,please refresh again)");
        }

        protected virtual void unLockFormDealing(string formNo)
        {
            lock (_lockDealingObject)
            {
                dealingList.Remove(formNo);
            }
        }

        protected virtual DataRow dealUserTask(string actUserID, string formNo, string task, string action, Dictionary<string, object> args, string flowUserID)
        {
            lockFormDealing(formNo);
            try
            {
                //�����v��
                if (!validTaskRight(flowUserID, formNo, task, action, args))
                    throw new PCIBusException("����ڥi��w�Q�H�B�z�A�Ш�s����(someone has dealed this data,please refresh again)�{�����H��:����v�����~(" + formNo + "," + flowUserID + "," + task + "," + action + ")");
                    //throw new ApplicationException("����v�����~(" + formNo + "," + flowUserID + "," + task + "," + action + ")");
                DataRow ret = performTask(actUserID, formNo, task, action, args, flowUserID);
                return ret;
            }
            finally
            {
                unLockFormDealing(formNo);
            }
        }

        protected virtual void checkAgent(string task, string userID,string agentedID)
        {
            if (agentedID != null && agentedID.Trim().Length >0)
            {
                string agentKind = getAgentKind(task);
                if (agentKind == null)
                    throw new ApplicationException("���y�{�����\�N�z,_agentKind��null");
                if (!_agentSet.IsAgent(agentKind, userID, agentedID))
                    throw new PCIBusException("Sorry,you are not a agent of " + agentedID);
            }
        }

        protected virtual DataRow dealTask(string userID, string formNo, string task, string action, Dictionary<string, object> args, string agentedID)
        {
            checkAgent(task, userID, agentedID);
            return dealUserTask(userID
                , formNo
                , task
                , action
                , args
                , agentedID == null || agentedID.Trim().Length == 0 ? userID:agentedID);  //�y�{�����u��UserID
        }

        public DataRow DealTask(string formNo, string task, string action, Dictionary<string, object> args, string agentedID)
        {
            return dealTask(PCIWeb.AuthenticateHelper.Instance.UserID, formNo, task, action, args, agentedID);
            // if (AppEventHanlder.Instance.UserHost == "172.19.48.10")
            //     throw new ApplicationException("���չq���A����f��");
        }

        #endregion

        #region ���ȤH�������k

        /// <summary>
        /// �������v����user
        /// </summary>
        /// <param name="dr"></param>
        /// <param name="setting"></param>
        /// <param name="checkDataRight"></param>
        /// <returns></returns>
        protected virtual List<string> getTaskUserByTaskRight(Dictionary<string,object> dr, TaskSet setting, out bool checkRight)
        {
            checkRight = false;
            if (setting.ValidTaskRight)
            {
                checkRight = true;
                //return RightsProvider.Instance.RightsOwner(TaskRightKind, setting.Task, true);
                return RightsProvider.Instance.RightsOwner(setting.TaskRightKind, setting.TaskRightData, true);
            }
            return null;
        }

        /// <summary>
        /// ���ƾ��v����user
        /// </summary>
        /// <param name="dr"></param>
        /// <param name="setting"></param>
        /// <returns></returns>
        protected virtual List<string> getTaskUserByDataRight(Dictionary<string,object> dr, TaskSet setting, out bool checkRight)
        {
            checkRight = false;
            List<string> dataRightUsers = new List<string>();
            if (setting.FieldIsActorID)
            {
                dataRightUsers.Add(dr[FlowDealerField].ToString());
                checkRight = true;
            }
            if (setting.FieldInitExp != null && setting.FieldInitExp.Length > 0)
            {
                checkRight = true;
                string rightKind = setting.DataRightKind;// BaseKind + "." + setting.Task;       //�pOdd.LemCheck
                dataRightUsers.AddRange(RightsProvider.Instance.RightsOwner(rightKind, dr[FlowDealerField].ToString(), true));
            }
            return dataRightUsers;
        }

        protected virtual List<string> getTaskUser(Dictionary<string,object> dr, string task)
        {
            TaskSet setting = getTaskSet(task);
            bool checkTaskRight;
            bool checkDataRight;
            List<string> taskRightUsers = getTaskUserByTaskRight(dr, setting, out checkTaskRight);
            List<string> dataRightUsers = getTaskUserByDataRight(dr, setting, out checkDataRight);
            string formNo = dr.ContainsKey(KeyField) ? dr[KeyField].ToString() : "";

            bool isReturnNull = false;
            if (!checkTaskRight && !checkDataRight)
            {
                Tool.Warn("�J�S���]�w�����v���A�S�S���]�w�ƾ��v��", "task", task, "formNo", formNo);
                isReturnNull = true;
            }
            if (checkTaskRight && (taskRightUsers == null || taskRightUsers.Count == 0))
            {
                Tool.Warn("�ݭn�����v���A���S�S�����t�����v��������H", "TaskRightKind", TaskRightKind, "task", task, "formNo", formNo);
                isReturnNull = true;
            }
            if (checkDataRight && (dataRightUsers == null || dataRightUsers.Count == 0))
            {
                Tool.Warn("�ݭn�ƾ��v���A���S�S�����t�ƾ��v��������H", "�ƾ��v������", dr[FlowDealerField].ToString(), "task", task, "formNo", formNo);
                isReturnNull = true;
            }

            if (isReturnNull)
                return null;

            if (!checkTaskRight)
                return dataRightUsers;
            else if (!checkDataRight)
                return taskRightUsers;
            else
            {
                List<string> ret = new List<string>();
                foreach (string user in dataRightUsers)
                {
                    if (taskRightUsers.Contains(user))
                        ret.Add(user);
                }
                if (ret == null || ret.Count == 0)
                    Tool.Warn("���ƾ��v�����H�S�@�Ӧ������v��", "task", task, "dataRightUsers", dataRightUsers, "taskRightUsers", taskRightUsers, "formNo", formNo);
                return ret;
            }
        }

        public DataRowCollection GetTaskUser(string formNo)
        {
            DataRow dr = getFormByNo(formNo);
            return GetTaskUser(Tool.ToDic(dr));
        }

        public DataRowCollection GetTaskUser(Dictionary<string, object> dr)
        {
            List<string> tasks;
            string oneTask;
            return GetTaskUser(dr,false, out oneTask,null,null,out tasks);
        }

        public DataRowCollection GetTaskUser(Dictionary<string, object> dr,bool onlyOneTask,out string oneTask, string specialTask, string allowAction, out List<string> tasks)
        {
            List<string> users = new List<string>();
            string usersIDStr = "";

            //DataRow dr = getFormByNo(formNo);
            string status = dr[FlowStatusField].ToString();
            tasks = new List<string>();
            foreach (string task in _taskSet.Keys)
            {
                string taskStatus = _taskSet[task].Status;
                string allowActions = _taskSet[task].AllowActions;
                if (status == taskStatus && (
                        allowAction == null
                        || allowActions == null
                        || allowActions.Length == 0
                        || ("," + allowActions + ",").IndexOf("," + allowAction + ",") >= 0
                        ))        //���A�ǰt���ɭԶ}�l
                {
                    tasks.Add(task);
                }
            }
            oneTask = null;
            foreach (string task in tasks)
            {
                //�����w���ȮɡA�u��ӥ��Ȫ�user�A�_�h���������user
                if (specialTask == task || specialTask == null)
                {
                    List<string> taskUsers = getTaskUser(dr, task);
                    if (taskUsers != null && taskUsers.Count>0)
                    {
                        foreach (string taskUser in taskUsers)
                        {
                            if (!users.Contains(taskUser))
                            {
                                users.Add(taskUser);
                                usersIDStr += (usersIDStr.Length > 0 ? "," : "") + taskUser;

                            }
                        }
                        if (onlyOneTask)
                        {
                            break;
                        }
                    }
                }
            }

            if (usersIDStr.Length > 0)
            {
                DataSet ds = DBHelper.Instance.Query("Common_Users_Query", Tool.ToDic("UsersID", usersIDStr));
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    return ds.Tables[0].Rows;
            }
            return null;

        }

        #endregion

        #region ���ͷ��e�Ҧ���ڪ����ȳq������

        protected void fillUserTask(Dictionary<string, Dictionary<string, Dictionary<string, DataRow>>> tasks, string user, string task, DataRow dr)
        {
            if (!tasks.ContainsKey(user))
                tasks.Add(user, new Dictionary<string, Dictionary<string, DataRow>>());
            if (!tasks[user].ContainsKey(task))
                tasks[user].Add(task, new Dictionary<string, DataRow>());
            string formNo = dr[KeyField].ToString();
            if (!tasks[user][task].ContainsKey(formNo))
                tasks[user][task].Add(formNo, dr);
        }

        protected void fillUsersTask(Dictionary<string, Dictionary<string, Dictionary<string, DataRow>>> tasks, List<string> users, string task, DataRow dr)
        {
            if (users != null)
            {
                foreach (string user in users)
                {
                    fillUserTask(tasks, user, task, dr);
                    //�A��o��user�Q���ǤH�N�z�F
                    string agentKind = getAgentKind(task);

                    Dictionary<string, string> agentList = _agentSet.GetAgenting(agentKind, user);
                    if (agentList != null)
                    {
                        foreach (string agent in agentList.Keys)
                            fillUserTask(tasks, agent, task, dr);
                    }
                }
            }
        }

        protected void fillTask(Dictionary<string, Dictionary<string, Dictionary<string, DataRow>>> tasks, string task, FilterTaskRowHandler filterHandler, object filterArgs)
        {
            TaskSet setting = getTaskSet(task);
            string status = setting.Status;

            Dictionary<string, object> args = new Dictionary<string, object>();
            args.Add(FlowStatusField, status);        //getForms�@���Φ��Ѽ�(�]���w�g�ഫ)
            Dictionary<string, object> allForms = getForms(args, "", 0, 1);     //�������i�H����order by
            DataRowCollection allRows = allForms["Rows"] as DataRowCollection;
            if (allRows != null && allRows.Count > 0)
            {
                foreach (DataRow dr in allRows)
                {
                    if (filterHandler == null || filterHandler(dr, task, filterArgs))
                    {
                        List<string> users = getTaskUser(Tool.ToDic(dr), task);
                        fillUsersTask(tasks, users, task, dr);
                    }
                }
            }
        }

        public delegate bool FilterTaskRowHandler(DataRow dr, string task, object filterArgs);

        //�o�ӥu�@�X�}�o�e�l���²�T�q��
        //���o�Τᵧ��
        //userID(���ޥN�z�٬O������),task(�i�g_taskNoticeMap�X�}),Dictionary<FormNo,DataRow>
        public Dictionary<string, Dictionary<string, Dictionary<string, DataRow>>> GetTaskUsers(FilterTaskRowHandler filterHandler, object filterArgs)
        {
            Dictionary<string, Dictionary<string, Dictionary<string, DataRow>>> ret = new Dictionary<string, Dictionary<string, Dictionary<string, DataRow>>>();
            foreach (string task in _taskSet.Keys)
                fillTask(ret, task, filterHandler, filterArgs);
            return ret;
        }

        public Dictionary<string, Dictionary<string, Dictionary<string, DataRow>>> GetTaskUsers()
        {
            return GetTaskUsers(null, null);
        }

        #endregion

        #region �����q���]�m

        public Dictionary<string, object> MsgNotice_Get()
        {
            return _noticeSet.Get(NoticeKind);
        }

        public void MsgNotice_Set(Dictionary<string, object> set)
        {
            _noticeSet.Set(NoticeKind, set);
        }

        #endregion

        #region �d�ߡ]�H�Τ@�ǵL�ƾ��v�����@�άd�ߡ^

        public Dictionary<string, object> Query(Dictionary<string, object> args, string order, int pagesize, int page)
        {
            return getForms(args, order, pagesize, page);
        }

        public List<Dictionary<string, object>> Steps(string formNo)
        {
            return getSteps(formNo);
        }

        #endregion

        #region �y�{�ʧ@
        public string DoFlowAction(string formNo, string action, Dictionary<string, object> args)
        {
            return this.DoFlowAction(formNo, action, args, null, null);
        }

        public string DoFlowAction(string formNo, string action, Dictionary<string, object> args,string task,string agentedID)
        {
            if (task != null && task.Length > 0)
            {
                this.DealTask(formNo, task, action, args, agentedID);
            }
            else
            {
                string userId = AuthenticateHelper.Instance.UserID;
                string userIP = AppEventHanlder.Instance.UserHost;
                string objKind = "FlowAction";      //���wFlowAction�v���~���|��TASK�q�o��๶i��
                string objId = this.BaseKind + "." + action;
                if (!RightsProvider.Instance.HasServiceRight(objKind, objId, userIP, userId))
                {
                    if (userId == null)
                        throw new PCINeedLoginException(objKind + "." + objId);
                    else
                        throw new PCINoPermissionException(userId + ":" + objKind + "." + objId);
                }
                formNo = FlowAction(formNo, action, args, task, agentedID);
                //if (this.cfg.ContainsKey("Actions"))
                //{
                //    throw new ApplicationException("service config no Actions setting");
                //}
                //Dictionary<string, object> actions = this.cfg["Actions"] as Dictionary<string, object>;
                //if (actions == null)
                //{
                //    throw new ApplicationException("Actions in service config is not Dictionary");
                //}
            }
            return formNo;
            /*
            string service = actions[action].ToString();
            object serviceResult = null;
            //4�Oservice.command
            object[] serviceArgs = new object[2 + otherArgs.Length];
            otherArgs[0] = formNo;
            otherArgs[1] = args;        //�e����ӰѼƩT�w
            otherArgs.CopyTo(serviceArgs, 2);
            serviceResult = ServiceCaller.Instance.Apply(ServiceCaller.CallType.BaseCall, service, serviceArgs);
            this.doAction(formNo, action, null, args, null);
            this.addActionStep(formNo, action, serviceResult == null ? "" : serviceResult.ToString());
            */
            //}
            //else
            //{
            //    this.DealTask(formNo, otherArgs[0].ToString(), action, args, otherArgs.Length > 1 ? otherArgs[1].ToString() : null);
            //}
        }

        public string FlowAction(string formNo, string action, Dictionary<string, object> args)
        {
            return FlowAction(formNo, action, args, null, null);
        }

        public string FlowAction(string formNo, string action, Dictionary<string, object> args, string task, string agentedID)
        {
            if (task != null && task.Length > 0)
            {
                this.DealTask(formNo, task, action, args, agentedID);
            }
            else
            {
                if (formNo == null || formNo.Length == 0)
                {
                    formNo = IdGenerator.Instance.NextNo("BaseFlow." + Database + "." + FormTable);
                    this.insertFlow(formNo.ToString());
                }
                //�p�G�S���y�{�A���s�W(���A���A�������ҰʡA�����N�}�l)
                //if (actions.ContainsKey(action))        //�S���t�m�A�����N�Otask�B�z
                //{
                string userID = AuthenticateHelper.Instance.UserID;
                innerPerformTask(userID, formNo, null, action, args, userID);
            }
            return formNo;
        }

        #endregion

        #region �y�{�ƥ�

        Dictionary<string, string[]> _statusEvents;

        void initStatusEvents()
        {
            DataSet ds = DBHelper.Instance.Query("Select_WF_StateStatus@Flow", Tool.ToDic("FlowNo", BaseKind));
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string status = dr["Status"].ToString();
                    string eventsService = dr["EventsService"].ToString().Trim();
                    if (eventsService.Length > 0)
                    {
                        string[] events = eventsService.Split(new char[] { ',' });
                        _statusEvents.Add(status, events);
                    }
                }
            }
        }

        //�l���������޳o�ӡA�ҥH����override���F�A�]�w�|�L��
        protected override void afterActionUpdate(Dictionary<string, object> form, string oldStatus, string newStatus, string formno, string action, string flowUserID, Dictionary<string, object> args, Dictionary<string, object> updateArgs, bool hasNewStatus)
        {
            if (_taskActionSet.ContainsKey(action))
            {
                string[] taskActionSet = _taskActionSet[action];
                if (taskActionSet[4].Trim().Length > 0)
                {
                    string[] services = taskActionSet[4].Split(new char[] { ',' });
                    foreach (string service in services)
                    {
                        //�H$�}�Y���ܦP�B�ư�
                        if (service.StartsWith("$"))
                        {
                            ServiceCaller.Instance.Call(ServiceCaller.CallType.BaseCall, service.Substring(1),  form,  oldStatus,  newStatus,  formno,  action,  flowUserID, args, updateArgs, hasNewStatus);
                        }
                        else
                        {
                            //�i�_�ư�
                            ServiceCaller.Instance.AddOtherDeal(new string[] { service, BaseKind + "_" + formno + "_Event", this.Database }, form,  oldStatus,  newStatus,  formno,  action,  flowUserID, args, updateArgs, hasNewStatus);
                            //ServiceCaller.Instance.AddOtherDeal(new string[] { service, "", this.Database }, formno);
                        }
                    }
                }
            }
            if (_statusEvents.ContainsKey(newStatus))
            {
                string[] services = _statusEvents[newStatus];
                foreach (string service in services)
                {
                    if (service.StartsWith("$"))
                    {
                        ServiceCaller.Instance.Call(ServiceCaller.CallType.BaseCall, service.Substring(1),  form,  oldStatus,  newStatus,  formno,  action,  flowUserID, args, updateArgs, hasNewStatus);
                    }
                    else
                    {
                        //�i�_�ư�
                        ServiceCaller.Instance.AddOtherDeal(new string[] { service, BaseKind + "_" + formno + "_Event", this.Database },form,  oldStatus,  newStatus,  formno,  action,  flowUserID, args, updateArgs, hasNewStatus);
                        //ServiceCaller.Instance.AddOtherDeal(new string[] { service, "", this.Database }, formno);
                    }
                }
            }

        }

        #endregion

        //���@�����٬O�n�ΤϮg
        //#region service���f

        //public object Call(string command, object[] args)
        //{
        //    DoFlowAction(args[0].ToString(), command, args.Length > 0 ? args[1] as Dictionary<string, object> : null);
        //    return null;
        //}

        //#endregion


        #region ���ȤH������(�ѥD���|���o���A���D�n�ʧ@�i��y�{����)

        public List<Dictionary<string, object>> CalculateFlowUsers(Dictionary<string, object> formDic)
        {
            List<Dictionary<string, object>> users = new List<Dictionary<string, object>>();
            formDic[FlowStatusField] = _initStatus;
            caculateFillFlowUsers(formDic, users);
            return users;
        }

        public List<Dictionary<string,object>> CalculateFlowUsers(string formNo)
        {
            DataRow form = getFormByNo(formNo);
            Dictionary<string, object> formDic = Tool.ToDic(form);
            List<Dictionary<string, object>> users = new List<Dictionary<string, object>>();
            List<Dictionary<string,object>> steps = getSteps(formNo);
            DataSet ds = DBHelper.Instance.Query("Select_" + WFTable + "@" + WFDataBase,Tool.ToDic(
                "FormKind",wfStepFormKind
                , "FormNo", formNo
                ));
            DataView stepView = ds.Tables[0].DefaultView;
            stepView.Sort = "StepID";
            DataRowCollection drs = stepView.ToTable().Rows;
            foreach (DataRow dr in drs)
                users.Add(Tool.ToDic(dr));
            caculateFillFlowUsers(formDic, users);
            return users;
        }

        protected void caculateFillFlowUsers(Dictionary<string, object> formDic, List<Dictionary<string, object>> users)
        {
            DataRowCollection taskUserRows;// = GetTaskUser(form);
            //users.Add(taskUserRows);
            string flowUserID;// taskUserRows == null ? "" : taskUserRows[0]["UserID"].ToString();
            bool currentMark = true;
            do
            {
                string curStatus = formDic[FlowStatusField].ToString();
                DataRow statusRow = Tool.ToRow(DBHelper.Instance.Query("Select_wf_statetran@Flow", Tool.ToDic(new object[]{
                    "FlowNo",BaseKind
                    ,"MainPath","Y"
                    ,"Status",curStatus
                })));
                //�S�����D���|�A�h�즹����
                if(statusRow == null)
                    break;
                //�p�G�@�Ӫ��A�]�w�F�h�ӥD���|�ʧ@�A�h����@��
                string action = statusRow["Action"].ToString();

                //�H�Z�i�����U���q�{���Ѽ�
                Dictionary<string,object> args = new Dictionary<string,object>();

                if (curStatus == _initStatus)
                {
                    users.Add(Tool.ToDic(
                        "KIND", "APPLY_USER"
                        , "STATUS", curStatus
                        , "ACTION", action
                        ,"Actor","�e�f��(Applicant)"
                        , "CURRENT_MARK", currentMark
                    ));
                    flowUserID = "";// AuthenticateHelper.Instance.UserID;

                }
                else
                {
                    //��X�����w�ʧ@�����Ȫ��H��
                    List<string> actionTasks;
                    string oneTask;
                    //�u��]�t��action���䤤�@�Ӧ��B�z�H����task(�O�_�n���w�D���|?)
                    //TODO:�H�Z�p�G�u���P�@�Ӫ��A���ʧ@�A���h�ӥ��ȳ��]�t�A�h�i�H���w�@�ӥD���ȡA�H�K�o�����y�{������i��U�h
                    taskUserRows = GetTaskUser(formDic,true, out oneTask,null, action, out actionTasks);
                    if (taskUserRows != null)
                    {
                        StringBuilder sb = new StringBuilder();
                        foreach (DataRow dr in taskUserRows)
                            sb.AppendFormat("{0}<font title='Email:{2}'>{1}</font>"
                                , sb.Length > 0 ? "," : ""
                                , dr["Name"]
                                ,dr["Email"]
                                ,dr["Account"].ToString().Split(new char[]{'@'}[0])[0]
                                ,dr["UserID"]
                                );
                        users.Add(Tool.ToDic(
                            "KIND","TASK_USERS"
                            , "STATUS", curStatus
                            , "ACTION", action
                            , "TASKS", actionTasks
                            , "ONE_TASK", oneTask
                            , "USERS", taskUserRows
                            , "Actor", sb.ToString()
                            , "CURRENT_MARK", currentMark

                        ));
                        flowUserID = taskUserRows == null ? "" : taskUserRows[0]["UserID"].ToString();
                    }
                    else
                    {
                        //�p�G�o�Ӫ��A�M�ʧ@�S���������
                        //�Ϊ̦����ȡA���O�������ȤH��(���`)
                        users.Add(Tool.ToDic(
                            "KIND", actionTasks.Count == 0 ? "TASK_NOT_FOUND" : "TASK_USER_NOT_FOUND"
                            , "STATUS", curStatus
                            , "ACTION", action
                            , "TASKS", actionTasks
                            , "ONE_TASK", oneTask
                            , "Actor", actionTasks.Count == 0 ? action : oneTask
                            , "CURRENT_MARK", currentMark
                        ));
                        flowUserID = "";
                    }
                }
                string newStatus;
                try
                {
                    newStatus = _stateFlow.NextStatus(action, curStatus, formDic, args, flowUserID);
                }
                catch(Exception ex)
                {
                    //�y�{���F���X���A���ӬO������쥼�]�w�Υ��ǤJ
                    users.Add(Tool.ToDic(
                        "KIND","CALCULATE_STATUS_ERROR"
                        ,"INFO",ex.Message
                        , "STATUS", curStatus
                        , "ACTION", action
                        , "Memo", "Calculate Error(Status)" + ex.Message
                        , "CURRENT_MARK", currentMark
                        ));
                    break;
                }
                if (newStatus == null || newStatus == "")
                    throw new ApplicationException("�D���|�]���n�p����ȤH���A����]�w�������ͷs���A���ʧ@" + curStatus + "[" + action + "]");
                Dictionary<string,object> updateArgs = new Dictionary<string,object>();
                //�H�Z�Ҽ{beforeActionUpdate�MafterActionUpdate�O�_�|��y�{���V�M�������_�@��?
                try
                {
                    fillFieldInitExp(formDic, curStatus, newStatus, action, flowUserID, args, updateArgs, true);
                }
                catch (Exception ex)
                {
                    //�y�{���F���X���A���ӬO������쥼�]�w�Υ��ǤJ
                    users.Add(Tool.ToDic(
                        "KIND", "CALCULATE_DEALER_ERROR"
                        , "INFO", ex.Message
                        , "STATUS", curStatus
                        , "ACTION", action
                        , "Memo", "Calculate Error(Expression)"
                        , "CURRENT_MARK", currentMark
                        ));
                    break;
                }

                //������s
                foreach (string key in updateArgs.Keys)
                    formDic[FlowFieldPrefix + key] = updateArgs[key];
                formDic[FlowStatusField] = newStatus;
                currentMark = false;
            } while (true);
        }

        #endregion

        public virtual void NewFlow(string formNo)
        {
            insertFlow(formNo);
        }
    }
}