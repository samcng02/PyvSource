﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Web.Services.Description;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Text;
using System.Net;
using Microsoft.CSharp;
using System.Reflection;

namespace PCIWeb.Tools
{
    public class ObjectFactory
    {
        #region 單例並保証其它地方以簡單方式獲取此對象

        public static readonly ObjectFactory Instance = new ObjectFactory
            (new FileConfig("ObjectFactory", new JsonParser()));

        //,new FileConfig(cfgDir,new JsonParser()));

        //隻有此對象的Config寫死，其它都可以通過
        //ObjectFactory.Default.Get<IConfig>("Name")來獲取

        public static ObjectFactory Default
        {
            get
            {
                return Instance;
            }
        }

        #endregion

        IConfig _config;

        public IConfig Config
        {
            get
            {
                return _config;
            }
        }

        static int _totalCount = 0;

        public ObjectFactory(IConfig config)
        {
            _totalCount++;
            Tool.Info("創建ObjectFactory對象","_totalCount", _totalCount);
            if (_totalCount > 1)
            {
                Tool.Warn("有兩個或以上ObjectFactory對象被創建");
            }
 

            _stores = new Dictionary<string, object>();
            _config = config;
            //因對象是可看到的單例，所以只+=事件，不-=事件不會存在內存洩露
            _config.OnConfigRefresh += new ConfigRefreshCallback(_config_OnConfigRefresh);

            _dyDllObjects = new Dictionary<string, List<string>>();
            _dyDllConfig = new FileConfig("Dll", "*.dll.service",new AssemblyParser());
            _dyDllConfig.OnConfigRefresh += new ConfigRefreshCallback(_dyconfig_OnConfigRefresh);

        }

        static object _lockObj = new object();

        void _config_OnConfigRefresh(string name)
        {
            if (this.removeObj(name))
            {
                Tool.Info("因config刷新而丟棄ObjectFactory中的對象", "name", name);
            }
        }

        static object _lockDyDllObj = new object();
        FileConfig _dyDllConfig;
        Dictionary<string, List<string>> _dyDllObjects;

        public Dictionary<string, List<string>> DyDllObjects()
        {
            return _dyDllObjects;
        }

        void _dyconfig_OnConfigRefresh(string name)
        {
            if (this._dyDllObjects.ContainsKey(name))
            {
                lock (_lockDyDllObj)
                {
                    if (this._dyDllObjects.ContainsKey(name))
                    {
                        List<string> objects = _dyDllObjects[name];
                        foreach (string obj in objects)
                        {
                            if (this.removeObj(obj))
                            {
                                Tool.Info("動態dll文件改變而丟棄ObjectFactory中的對象", "name", obj);
                            }
                        }
                        _dyDllObjects.Remove(name);
                        Tool.Warn("動態dll文件刷新，但web應用程序重啟前，舊版本Assembly會一直存于AppDomain中", "name", name);
                    }
                }
                if (AssemblyParser.DynamicDllRefs.ContainsKey(name))
                {
                    foreach (string refDll in AssemblyParser.DynamicDllRefs[name])
                    {
                        Tool.Info("Begin to clear Ref Dll Object", "refed dll", name, "ref dll", refDll);
                        _dyDllConfig.ClearCache(refDll);
                        //clearObjectByDyDll(refDll);
                    }
                }
            }
        }

        /// <summary>
        /// 提供管理訊息
        /// </summary>
        public FileConfig DyConfig
        {
            get
            {
                return _dyDllConfig;
            }
        }

        public void RefreshObject(string name)
        {
            if (this.removeObj(name))
            {
                Tool.Info("手動刷新丟棄ObjectFactory中的對象", "name", name);
            }
        }

        public List<Dictionary<string, object>> Store()
        {
            List<Dictionary<string, object>> ret = new List<Dictionary<string, object>>();
            Dictionary<string,object>.KeyCollection ks = _stores.Keys;
            foreach (string k in ks)
            {
                if(_stores.ContainsKey(k))
                    ret.Add(Tool.ToDic("ObjectID", k,"Type",_stores[k].GetType().FullName));
            }
            return ret;
        }

        bool removeObj(string name)
        {
            if (this._stores.ContainsKey(name))
            {
                lock (_lockObj)
                {
                    if (this._stores.ContainsKey(name))
                    {
                        this._stores.Remove(name);
                        return true;
                    }
                }
            }
            return false;
        }

        object[] objectCfg(string objectID)
        {
            string key = objectID;
            Dictionary<string, object> cfg = _config.Parse<Dictionary<string, object>>(key);
            if (cfg != null)
            {
                if (cfg.ContainsKey("$ref"))
                {
                    cfg = _config.Parse<Dictionary<string, object>>(cfg["$ref"].ToString());
                }
                return new object[] { 
                    cfg.ContainsKey("Type")?cfg["Type"].ToString():null
                    ,cfg.ContainsKey("Dll")?cfg["Dll"].ToString():null
                    ,cfg.ContainsKey("Args")?(ArrayList)cfg["Args"]:null
                    ,cfg.ContainsKey("Url")?cfg["Url"].ToString():null
                    ,cfg.ContainsKey("SoapHeader")?(Dictionary<string,object>)cfg["SoapHeader"]:null
                    ,cfg.ContainsKey("DyDll")?cfg["DyDll"].ToString():null
                    ,cfg.ContainsKey("Fields")?(Dictionary<string,object>)cfg["Fields"]:null
                    //不作別名，是以別名第一次創建對象會失敗，建議以資料庫形式儲存Config對象
                };
            }
            return null;
        }

        public bool ObjectConfig(string objectID)
        {
            return _config.Parse<Dictionary<string, object>>(objectID) != null;
        }

        /// <summary>
        /// 直接以Type獲取該類別的對象實例
        /// 這樣的好處：
        /// 1:免寫接口
        /// 2:有行為修改時，可以在ObjectFactory配置檔中增加一項配置，調用新的子類實現
        /// 3:直接類型設計時應該注意
        /// a:嚴格檢查public方法和屬性
        /// b:有變化的請用virtual標記
        /// c:私有變量請檢查是否提供protected訪問
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public T Get<T>() where T : class
        {
            return this.Get<T>(typeof(T).FullName);
        }


        //js.net好像不支持范型，因此Get被認為有三個方法，增加一個GetByName方法供其調用
        public object GetByName(string name)
        {

            return this.Get(name);
        }

        /// <summary>
        /// Ajax呼叫未知Type的對象(可以傳類名稱(加,dll名稱),也可以傳ID）
        /// 然後在有修改時或臨時變動時，直接在配置文件中增加一項，並配置給其它對象
        /// 建議有ajax呼叫的程式，其serviceID以QueryString方式傳入主程式中
        /// 這樣隻需要修改菜單的程式鏈接配置也可修改前端ID
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public object Get(string name)
        {
            return this.Get<object>(name);
        }

        object[] dealParams(ArrayList targs)
        {
            if (targs == null || targs.Count == 0)
                return null;
            object[] ret = new object[targs.Count];
            int i = 0;
            foreach (object arg in targs)
            {
                if (arg.ToString().StartsWith("#"))
                    ret[i++] = this.Get(arg.ToString().Substring(1));
                else
                    ret[i++] = arg;
            }
            return ret;
        }

        Dictionary<string, object> _stores;

        public object Register(object o)
        {
            return this.Register(o.GetType().FullName, o,null);
        }

        static Dictionary<string, int> _objectCounts = new Dictionary<string, int>();

        public object Register(string objectID, object o,string dyDll)
        {
            lock (_lockObj)
            {
                if (!_stores.ContainsKey(objectID))
                {
                    _stores.Add(objectID, o);
                    Tool.Info("註冊產生ObjectFactory中的對象", "objectID", objectID);
                    if (_objectCounts.ContainsKey(objectID))
                    {
                        Tool.Trace("對象已產生過多次","objectID",objectID,"次數", _objectCounts[objectID]);
                        _objectCounts[objectID]++;
                    }
                    else
                    {
                        _objectCounts[objectID] = 1;
                    }

                    if (dyDll != null && dyDll.Length > 0)
                    {
                        lock (_lockDyDllObj)
                        {
                            if (!this._dyDllObjects.ContainsKey(dyDll))
                            {
                                this._dyDllObjects.Add(dyDll,new List<string>());
                            }
                            _dyDllObjects[dyDll].Add(objectID);
                            Tool.Info("註冊Object依賴動態dll", "objectID", objectID, "dyDll", dyDll);
                        }
                    }
                }
                else
                {
                    Tool.Warn("ObjectFactory對象已存在(放棄剛剛創建的對象)", "objectID", objectID);
                }
                o = _stores[objectID];
                //else  //多線程不直接管控，如果有，則放棄創建的對象，以_stores中的對象為主(盡量保証使用的是同一對象，但注意此方法產生的對象不保証嚴格單例)
                //    _stores[objectID] = o;
            }
            return o;
        }

        public string GetObjectName(object o)
        {
            foreach (string key in _stores.Keys)
            {
                if (_stores[key] == o)
                    return key;
            }
            return null;
        }

        static object _lockGetLockObjId = new object();
        static Dictionary<string, object> _lockID = new Dictionary<string, object>();

        static object getLockObj(string objectID)
        {
            lock (_lockGetLockObjId)
            {
                if (!_lockID.ContainsKey(objectID))
                {
                    _lockID.Add(objectID, new object());
                }
                return _lockID[objectID];
            }
        }

        /// <summary>
        /// 如果是嚴格單類實例，請不要使用此方法獲取，此方法隻緩存，不保証永遠單例（因為多線程和cache(配置在HttpCache中每小時丟一次)可丟掉的原因）
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="name"></param>
        /// <returns></returns>
        public T Get<T>(string objectID) where T : class
        {

            string cacheKey = objectID;
            string configName = AppEventHanlder.Instance.ServiceVarContent();// ("Config");
            if (configName != null && configName.Length > 0)
            {
                cacheKey = objectID + "$" + configName;
            }


            lock (getLockObj(cacheKey))
            {
                T ret = null;

                if (_stores.ContainsKey(cacheKey))
                {
                    lock (_lockObj)
                    {
                        if (_stores.ContainsKey(cacheKey))
                            ret = (T)_stores[cacheKey];
                    }
                }

                if (ret == null)
                {
                    //默認以objectID作為objectType進行CreateInstance
                    string objectType = objectID;
                    //因為objectType是PCIWeb.Tools.BaseForm，而objectID是PCIWeb.Odd.Form
                    //if (typeof(T) != typeof(object))
                    //    objectType = typeof(T).FullName;
                    string dll = null;
                    object[] args = null;
                    string url = null;
                    Dictionary<string, object> soapHeader = null;
                    string dyDll = null;            //動態載入dll,需要緩存(WS不緩存,因為一個WS一般就一個對象，而一個dll則可能有多個service)

                    Dictionary<string, object> fields = null;
                    //是否配置
                    object[] cfg = objectCfg(objectID); //不需要知道config的方式，甚或是如何配置，一個文件or any other way(隻要得到三個結果即可)
                    if (cfg != null)
                    {
                        if (cfg[0] != null && cfg[0].ToString().Length > 0)
                            objectType = cfg[0].ToString();
                        dll = cfg[1] as string;
                        ArrayList targs = cfg[2] as ArrayList;  //debug是否正確
                        args = this.dealParams(targs);
                        url = cfg[3] as string;
                        soapHeader = cfg[4] as Dictionary<string, object>;
                        dyDll = cfg[5] as string;

                        fields = cfg[6] as Dictionary<string, object>;

                    }

                    if (url != null && url != "")
                        ret = CreateWSObject(objectType, url, soapHeader) as T;
                    else if (fields != null)
                        ret = JsonToObject<T>(objectType, dll, fields, ref dyDll, objectType == objectID);
                    else
                        ret = CreateObject<T>(objectType, dll, args, ref dyDll, objectType == objectID);        //等于才可以try T，因為等于，表示沒有明示配置Type

                    if (ret != null)
                        ret = Register(cacheKey, ret, dyDll) as T;
                }
                return ret;     //為null時拋不拋出異常由調用方決定?
            }
        }

        Type parseTypeIfObjectIDInApp(string objectType,ref string dyDll)
        {
            Type t = null;
            string appFolder = null;
            //PCI.CTS.Form
            string objectIDName = AppEventHanlder.Instance.GetInstallNameByHardCode(objectType);
            string[] names = objectIDName.Split(new char[] { '.' });

            string appPath = null;
            for (int i = 1; i < names.Length; i++)
            {

                //有安裝目錄變化
                //TODO:可以在sjs端直接用.來調用,表示當前app的namespace,然後在callService處理處統一將.替換成當前app的ID,而在后端的code中,也使用.語法,這樣也可以將調用轉成當前的真正app調用
                //讓一套代碼同時支持多個appID
                //多個appID可以安裝在同一個地方,使用同一套source code,利用Install.js找物理位置
                //appID作緩存
                string installPath = SystemConfig.Instance.Get<string>("Install.js", String.Join(".", names, 0, names.Length - i), '$');
                if (installPath != null)
                {
                    names = (installPath + "/" + String.Join("/", names, names.Length - i, i)).Split(new char[] { '/' });
                    appFolder = System.AppDomain.CurrentDomain.BaseDirectory + "Apps\\" +
                        installPath.Replace(".", "\\") + "\\_service";
                    appPath = String.Join(".", names, 0, names.Length - i);
                    break;
                }
                appFolder = System.AppDomain.CurrentDomain.BaseDirectory + "Apps\\" +
                    String.Join("\\", names, 0, names.Length - i) + "\\_service";
                Tool.Trace("search App", "objectID", objectType, "appFolder", appFolder);
                if (Directory.Exists(appFolder))
                {
                    appPath = String.Join(".", names, 0, names.Length - i);
                    break;
                }
            }
            
            if (appPath != null)
            {
                appFolder += "\\Dll";
                if (Directory.Exists(appFolder))
                {
                    DirectoryInfo dir = new DirectoryInfo(appFolder);
                    FileInfo[] files = dir.GetFiles("*.dll", SearchOption.AllDirectories);
                    foreach (FileInfo file in files)
                    {
                        string fileRelativePath = file.Directory.FullName.Substring(dir.FullName.Length).Replace("\\", ".");
                        string dllName = appPath + fileRelativePath + "." + file.Name;
                        try
                        {
                            Assembly ass = _dyDllConfig.Parse<Assembly>(dllName);
                            if (ass != null)
                            {
                                t = ass.GetType(objectType);
                                if (t != null)
                                {
                                    dyDll = dllName;
                                    break;
                                }
                            }
                            else
                                Tool.Warn("未找到dll", "dllName", dllName);
                        }
                        catch (Exception ex)
                        {
                            //throw;
                            Tool.Error(".service動態解析獲取類型失敗", "dllName", dllName, "appFolder", appFolder , "objectType", objectType, "ex", ex);
                        }
                    }

                }
            }
            return t;
        }

        public Type GetType<T>(string objectType, string dll, ref string dyDll, bool tryT) where T : class
        {
            Type t = null;
            //無配置:objectID就是Type T是object(前端抓)  Get("PCI.OT.Form")
            //無配置:objectID不是Type T是Type(后臺用)    Get<PCI.Install.AppService>()
            //有配置，無Type:  Get<PCIWeb.Tools.BaseForm>("PCIWeb.Odd.Form")
            //有配置，有Type:  Get<TestGit.EntityRepository>("TestGit.RoomEntity")

            //如果會給前端用Get(objectID)，或造型成接口或抽象類Get<IorA>(objectID)，Get<T>()，Get<T>(objectID)
            //有配置，有TYPE：objectID != objectType   typeof(T)不適用
            //有配置，無TYPE：objectID == objectType   typeof(T)適用
            //無配置：objectID == objectType           typeof(T)適用

            string tType = tryT && typeof(T) != typeof(object) && typeof(T).FullName != objectType && !typeof(T).IsInterface && !typeof(T).IsAbstract ? typeof(T).FullName : null;
            //if (objectType != null && objectType.Length > 0)
            //{
            if (dyDll != null && dyDll.Length > 0)     //有指明dyDll，則到App_Data/Config/Dll下搜，且一定有type，也不再試T
            {
                Assembly dynamicAss = _dyDllConfig.Parse<Assembly>(dyDll);
                t = dynamicAss.GetType(objectType);
            }
            else
            {
                //假如service在bin目錄的dll中，那加上dll，會讓搜尋速度變快，否則會嘗試搜完所有的DyDll才會出來。不過如果沒有載入bin中的dll好像也不行，但第二次就OK了
                if (dll != null && dll.Length > 0)   //bin目錄下(好像也不會初始化，要用到才會)
                    t = Type.GetType(objectType + "," + dll);


                //還是未找到，則從App_Data/config/dll下搜索
                if (t == null && (dll == null || dll.Length == 0))
                {
                    List<string> dllNameList = _dyDllConfig.Items();
                    foreach (string dllName in dllNameList)
                    {
                        try
                        {
                            Assembly ass = _dyDllConfig.Parse<Assembly>(dllName);
                            t = ass.GetType(objectType);
                            if (t != null)
                            {
                                dyDll = dllName;
                                break;
                            }
                            else if (tType != null)
                            {
                                t = ass.GetType(tType);
                                if (t != null)
                                {
                                    dyDll = dllName;
                                    break;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            //throw;
                            Tool.Error("dll.service動態解析以獲取類型失敗", "dllName", dllName, "objectType", objectType, "ex", ex);
                        }
                    }
                }

                //搜索Apps
                if (t == null && (dll == null || dll.Length == 0))
                {
                    //如果App中的class name和App ID不一致，是抓不到的（雖然后面可以抓到）
                    //所以如果是在Apps中的dll，請保持里面所有要公開給客戶端調用的service的namespace都為AppID的名稱
                    //如果在里面則可以抓得到，因為dll已經進來了，然后后面的for循環就可以找到了
                    t = parseTypeIfObjectIDInApp(objectType, ref dyDll);
                    //雖然T已經有了，但還是用名稱重新抓一遍，因為有可能dll更新了(這時候會運行時出錯吧，因為更新后的Type和T不一樣?)
                    //所以直接用現在的T去創建好了，因為可能只是配置有變后重新來過

                    //objectID大部分時候和objectType一樣
                    //如果不一樣，那就是有配置，且上面有手動設定Type，這時候objectID和objectType不一致

                    //一律用ID當作Type抓類型，如果沒有配置類型，ID又不是類型，最后才用T去創建對象
                    //這里用objectType去抓是因為objectType有配置成另一個App的Type(按道理不允許，但現在都公用PCI.Tools的東西)
                    //如PCI.Install.AppSvnDeployService里面用到PCI.Tools.SvnDeployService
                    //如果T是Abstract或Interface，那objectID一定是類型或有配置Type在objectfactory中
                    //如果T可以被實例化，那應該有提供配置檔
                    //直接抓PCI.Tools.SvnDeployService

                    //T是dyDll中的，它也變了
                    //objectID:TestGit.RoomEntity    T:TestGit.EntityRepository
                    //沒有配置，但是ID也抓不到，這就要去try T了
                    if (t == null && tType != null)
                        t = parseTypeIfObjectIDInApp(tType, ref dyDll);
                }

                //當前載入的dll全部去搜尋
                if (t == null)// && (dll == null || dll.Length == 0))
                {
                    //因為.net使用延遲加載，如果主程序沒用到，即使在bin目錄下，也會找不到的
                    Assembly[] asses = System.AppDomain.CurrentDomain.GetAssemblies();
                    //如果有相同的dll，說明是重復的，是動態dll，一定要能在cache中找到
                    Dictionary<string, int> repeatAsses = new Dictionary<string, int>();
                    foreach (Assembly ass in asses)
                    {
                        if (!ass.GlobalAssemblyCache)
                        {
                            if (!repeatAsses.ContainsKey(ass.FullName))
                                repeatAsses.Add(ass.FullName, 0);
                            repeatAsses[ass.FullName]++;
                        }
                    }
                    foreach (Assembly ass in asses)
                    {
                        //不找.net本身的類作服務對象?
                        if (!ass.GlobalAssemblyCache)
                        {
                            t = ass.GetType(objectType, false);
                            if (t != null)
                            {
                                //TODO:排除那些是動態dll，但是又找不到的，說明過時了，有新版本
                                //TODO:如果需要在app或dll中引用第三方dll，又不想把它放到bin目錄下，是可以的
                                //但是要用版本號，保持一致
                                dyDll = _dyDllConfig.GetKey(ass);
                                //凡是用這種直接找的方式，如果不是cache，說明過期了，應該有最新版本在
                                if (repeatAsses[ass.FullName] == 1 || dyDll != null)
                                    break;
                            }
                            else if (tType != null)
                            {
                                t = ass.GetType(tType, false);
                                if (t != null)
                                {
                                    dyDll = _dyDllConfig.GetKey(ass);
                                    if (repeatAsses[ass.FullName] == 1 || dyDll != null)
                                        break;
                                }
                            }
                        }
                    }
                }
            }

            //Assembly.Load
            //}
            //明示獲取對象，且給出了對象名稱時，一定要配置出來
            //這種取type放到動態dll取type之后，是防止動態dll有更新時，要優先于內存中讀取
            if (t == null && tType != null)       //typeof(T)==typeof(object)，說明一定要以objectID為Type或ID名稱產生對象(Get(string name)方法)
                t = typeof(T);
            return t;
        }

        public T CreateObject<T>(string objectType, string dll, object[] args,ref string dyDll,bool tryT) where T : class
        {
            T ret = null;
            Type t = GetType<T>(objectType, dll, ref dyDll, tryT);
            //對于有Instance的靜態實際對象，而constructor又是private時，直接取Instance，而不是new
            if (t != null)
            {
                //這里先用靜態Instance判斷一下，省確二次調用的麻煩
                FieldInfo fi = t.GetField("Instance", BindingFlags.Public | BindingFlags.Static);
                if (fi != null)
                {
                    try
                    {
                        ret = fi.GetValue(null) as T;
                    }
                    catch (Exception ex)
                    {
                        Tool.Warn("Instance屬性獲取失敗", "t.FullName", t.FullName, "ex", ex);
                    }
                }
                if (ret == null)
                {
                    try
                    {
                        ret = (T)Activator.CreateInstance(t, args);
                    }
                    catch (Exception ex)
                    {
                        //throw new ApplicationException("反射創建對象出錯，可能是構建器中的內容", ex.InnerException == null ? ex : ex.InnerException);
                        Tool.Error("CreateInstance error", "objectType", objectType, "dll", dll, "args", args, "dyDll", dyDll, "tryT", tryT);
                        throw new Exception("反射創建對象出錯，可能是構建器中的內容", ex.InnerException == null ? ex : ex.InnerException);
                    }
                }

            }
            return ret;
        }

        public T JsonToObject<T>(string objectType, string dll, Dictionary<string,object> fields, ref string dyDll, bool tryT) where T : class
        {

            T ret = null;
            Type t = GetType<T>(objectType, dll, ref dyDll, tryT);
            //對于有Instance的靜態實際對象，而constructor又是private時，直接取Instance，而不是new
            if (t != null)
            {
                PCIWeb.DDD.JsonObjectHelper jHelper = new DDD.JsonObjectHelper();
                try
                {
                    ret = jHelper.DicToObject(t,fields) as T;
                }
                catch (Exception ex)
                {
                    Tool.Warn("Instance屬性獲取失敗", "t.FullName", t.FullName, "ex", ex);
                }
            }
            return ret;
        }
        public object CreateWSObject(string objectType, string url, Dictionary<string, object> soapHeader)
        {
            object ret = null;
            string ns = objectType.Substring(0, objectType.LastIndexOf("."));
            string classname = objectType.Substring(objectType.LastIndexOf(".") + 1);
            ServiceDescriptionImporter importer1 = new ServiceDescriptionImporter();
            importer1.AddServiceDescription(ServiceDescription.Read(new WebClient().OpenRead(url + "?WSDL")), "", "");
            CodeNamespace namespace1 = new CodeNamespace(ns);
            CodeCompileUnit unit1 = new CodeCompileUnit();
            unit1.Namespaces.Add(namespace1);
            importer1.Import(namespace1, unit1);
            CompilerParameters parameters1 = new CompilerParameters();
            parameters1.GenerateExecutable = false;
            parameters1.GenerateInMemory = true;
            parameters1.ReferencedAssemblies.Add("System.dll");
            parameters1.ReferencedAssemblies.Add("System.XML.dll");
            parameters1.ReferencedAssemblies.Add("System.Web.Services.dll");
            parameters1.ReferencedAssemblies.Add("System.Data.dll");
            CompilerResults results1 = new CSharpCodeProvider().CompileAssemblyFromDom(parameters1, new CodeCompileUnit[] { unit1 });
            if (results1.Errors.HasErrors)
            {
                StringBuilder builder1 = new StringBuilder();
                foreach (CompilerError error1 in results1.Errors)
                {
                    builder1.Append(error1.ToString());
                    builder1.Append(Environment.NewLine);
                }
                throw new Exception(builder1.ToString());
            }
            Assembly assembly = results1.CompiledAssembly;
            Type type1 = assembly.GetType(ns + "." + classname, true, true);
            ret = Activator.CreateInstance(type1);
            System.Web.Services.Protocols.WebClientProtocol retWs = (System.Web.Services.Protocols.WebClientProtocol)ret;
            retWs.Timeout = 600000;
            //加soap頭
            if (soapHeader != null)
            {
                string soapClassName = soapHeader["ClassName"].ToString();
                //Soap头开始   
                FieldInfo client = type1.GetField(soapClassName + "Value");

                //获取客户端验证对象   
                Type typeClient = assembly.GetType(ns + "." + soapClassName);

                //为验证对象赋值   
                object clientkey = Activator.CreateInstance(typeClient);

                Dictionary<string,object> headerFields = soapHeader["Fields"] as Dictionary<string,object>;
                foreach (string key in headerFields.Keys)
                {
                    typeClient.GetField(key).SetValue(clientkey, headerFields[key]);
                }
                client.SetValue(retWs, clientkey);

                //設置timeout 30秒,防止像EFP這樣的程式總是不回來,造成request阻塞
                //(ret as System.Web.Services.Protocols.SoapHttpClientProtocol).Timeout = 30 * 1000;
                //EFP不是用ws,而是直接連oracle資料庫,所以暫時取消,免得打擾程式,以后有需要再來

            }
            return retWs;
        }
    }
}