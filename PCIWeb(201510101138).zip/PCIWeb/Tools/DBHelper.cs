﻿using System;
using System.Web;
using System.Web.Caching;
using System.Web.SessionState;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.OracleClient;
using System.Data.SqlClient;
using System.Text;
using System.Text.RegularExpressions;

namespace PCIWeb.Tools
{
    /// <summary>
    /// Data Access Layer
    /// </summary>
    public class DBHelper
    {

        //Dictionary<string, object> nullArgs = new Dictionary<string, object>();

        public delegate void CommandExecuteHandler(object result,DbCommand command,DbTransaction tran,string tranID, string cmdName, Dictionary<string, object> args);

        public event CommandExecuteHandler OnExecute;

        public static readonly DBHelper OrgInstance = new DBHelper();
        //2014.10.18 取消cache（1.用cache的地方很少，估計對性能也沒明顯改善。以后是否考慮其它方式緩存數據？如service直接緩存?或者專業的緩存，如分佈式web server+統一的緩存server+database這種架構？ 2.不想為Config動態化修改cache的抓法（如果以后要啟用cache，只修改cache key的判斷就好了））
        public static readonly DBHelper Instance = OrgInstance;//new CacheDBHelper(OrgInstance);//ObjectFactory.Default.Get<DBHelper>("DBHelper");//
        
        #region 事務處理及其它

        public void SetDefaultTran()
        {
            HttpContext.Current.Items["__DEFAULTTRANID"] = DBHelper.Instance.BeginTran();
        }

        public void ClearDefaultTran()
        {
            string tranID = HttpContext.Current.Items["__DEFAULTTRANID"] as string;
            if (tranID != null)
                HttpContext.Current.Items.Remove("__DEFAULTTRANID");
        }                        


        public void CommitTran()
        {
            string tranID = HttpContext.Current.Items["__DEFAULTTRANID"] as string;
            string db= null;
            if (tranID != null)
            {
                if (HttpContext.Current.Items.Contains(tranID))
                {
                    Database tranDB = HttpContext.Current.Items["DB_" + tranID] as Database;
                    if (tranDB != null)
                    {
                        string dbName = ObjectFactory.Instance.GetObjectName(tranDB);
                        db = dbName.IndexOf(".") < 0 ? dbName.Substring("Database_".Length):dbName;
                    }
                }
                //if (tranID == null)
                //    this.SetDefaultTran();      //保證后面的other deal是事務提交的
                //tranID = HttpContext.Current.Items["__DEFAULTTRANID"] as string;
                bool haveOtherDeal = ServiceCaller.Instance.SaveEx(db, tranID);
                if (tranID != null)
                    CommitTran(tranID);
                ClearDefaultTran();

                //每次事務處理后，就開始檢查與這次主事務有關的異種處理開始執行
                //避免像Rec轉檔很慢，還沒開始處理異種事務時
                //新的簽核已開始，導致大面積的異種事務處理延遲
                //kevin.zou 2011.10.19注
                if (haveOtherDeal)
                {
                    ServiceCaller.Instance.DealOtherDeal(db, tranID);
                }
            }
            else if (ServiceCaller.Instance.HaveEx())
            {
                Tool.Warn("有程式的AddOtherDeal不會執行，請檢查是否有TranID存在");
            }
        }

        public void RollbackTran()
        {
            string tranID = HttpContext.Current.Items["__DEFAULTTRANID"] as string;
            if (tranID != null)
                RollbackTran(tranID);
            ClearDefaultTran();
            ServiceCaller.Instance.ClearEx();

        }

        public string BeginTran()
        {
            return Guid.NewGuid().ToString();
        }

        public DbTransaction GetDefaultTran(Database db)
        {
            string tranID = HttpContext.Current.Items["__DEFAULTTRANID"] as string;
            if (tranID != null)
                return getTran(db, tranID, true);
            return null;
        }

        DbTransaction getTran(Database db, string tranID,bool isOpen)
        {
            DbTransaction tran = null;
            if (tranID != null)
            {
                if (HttpContext.Current == null)
                    return null;//throw new ApplicationException("Get Tran Failure,HttpContext.Current is null");
                else
                {
                    if (HttpContext.Current.Items.Contains(tranID))
                    {
                        //一次隻能執行一個事務
                        tran = HttpContext.Current.Items[tranID] as DbTransaction;
                        Database tranDB = HttpContext.Current.Items["DB_" + tranID] as Database;
                        if (tran != null && tranDB!=null && db!=null && (tranDB == db || tranDB.IsSameConnection(db)))
                            return tran;
                        else
                        {
                            //因RequestID(cef2ba6c-304a-48fe-8451-612728746668)的處理過程出現中途沒有transaction的情況
                            //因此加上這些日志用于判斷日后再出現此類狀況時的分析
                            //kevin.zou 2011.12.22注
                            if (isOpen)     //只有Execute時，抓不到Tran，才需要Log
                            {
                                if (tran == null)
                                    Tool.Warn("從HttpContext.Current.Items中取出DbTransaction為null", "tranID", tranID);
                                else if (tranDB == null || db == null)
                                    Tool.Warn("DB為null", "tranDB", tranDB == null ? "null" : "OK", "db", db == null ? "null" : "OK");
                                else if (!tranDB.IsSameConnection(db))
                                    Tool.Warn("tranDB與db不是同一個connection string，請程式員檢查程式，用異種事務方式解決不同DB的事務處理", "tranDB ID", ObjectFactory.Instance.GetObjectName(tranDB), "db ID", ObjectFactory.Instance.GetObjectName(db));
                                else if (tranDB != db)      //這種情況應該不會再發生了，代碼還是先放這吧 kevin.zou 2011.12
                                    Tool.Warn("DB不一樣，可能是ObjectFactory取到兩個實例", "tranDB ID", ObjectFactory.Instance.GetObjectName(tranDB), "db ID", ObjectFactory.Instance.GetObjectName(db));
                            }
                            return null;// throw new ApplicationException("Get Tran Failure,tranID is not a DbTransaction!(" + tranID + ")");
                        }
                    }
                    else if(isOpen)
                    {
                        tran = db.BeginTransaction();
                        HttpContext.Current.Items.Add(tranID, tran);
                        HttpContext.Current.Items.Add("DB_" + tranID, db);
                        Tool.Info("Begin Transaction", "tranID",tranID);
                    }
                }
            }
            return tran;
        }

        /// <summary>
        /// 以後可以將transaction存放的地址單獨放在一個類中管理，這樣web應用程式和windows程式就可以共用此類（目前不行）
        /// </summary>
        /// <param name="tranID"></param>
        public void CommitTran(string tranID)
        {
            try
            {
                //throw new ApplicationException("[Commit]Get Tran Failure,HttpContext.Current is null");
                if (HttpContext.Current != null)
                {
                    if (HttpContext.Current.Items.Contains(tranID))
                    {
                        DbTransaction tran = HttpContext.Current.Items[tranID] as DbTransaction;
                        if (tran != null)
                        {
                            DbConnection conn = tran.Connection;
                            tran.Commit();
                            if (conn != null)
                                conn.Close();
                            HttpContext.Current.Items.Remove(tranID);
                            HttpContext.Current.Items.Remove("DB_" + tranID);

                            Tool.Info("Commit Transaction", "tranID", tranID);
                        }
                        //else
                        //    throw new ApplicationException("[Commit]Get Tran Failure,tranID is not a DbTransaction!(" + tranID + ")");
                    }
                    //else
                    //    throw new ApplicationException("[Commit]HttpContext.Current.Items do not contain tranID(" + tranID + ")");
                }
            }
            catch (Exception ex)
            {
                Tool.Error("Commit Tran Self Error", "ex", ex);
            }
        }

        public void RollbackTran(string tranID)
        {
            try
            {
                //throw new ApplicationException("[Rollback]Get Tran Failure,HttpContext.Current is null");
                if (HttpContext.Current != null)
                {
                    if (HttpContext.Current.Items.Contains(tranID))
                    {
                        DbTransaction tran = HttpContext.Current.Items[tranID] as DbTransaction;
                        if (tran != null)
                        {
                            DbConnection conn = tran.Connection;
                            tran.Rollback();
                            if (conn != null)
                                conn.Close();
                            HttpContext.Current.Items.Remove(tranID);
                            HttpContext.Current.Items.Remove("DB_" + tranID);

                            Tool.Warn("Rollback Transaction", "tranID", tranID);
                        }
                        //else
                        //    throw new ApplicationException("[Rollback]Get Tran Failure,tranID is not a DbTransaction!(" + tranID + ")");
                    }
                    //else
                    //    throw new ApplicationException("[Rollback]HttpContext.Current.Items do not contain tranID(" + tranID + ")");
                }
            }
            catch (Exception ex)
            {
                Tool.Error("Rollback Tran Self Error", "ex", ex);
            }

        }

        #endregion

        #region 命令調用

        void addOutputParameters(DbCommand cmd,Dictionary<string,object> args)
        {
            if (args.ContainsKey("__OutputParams"))
            {
                Dictionary<string, object> outputParams = new Dictionary<string, object>();
                foreach (DbParameter p in cmd.Parameters)
                {
                    if (p.Direction == ParameterDirection.InputOutput
                        || p.Direction == ParameterDirection.Output
                        || p.Direction == ParameterDirection.ReturnValue)
                        outputParams.Add(p.ParameterName, p.Value);
                }
                args["__OutputParams"] = outputParams;
            }
        }

        public virtual DataSet QueryPage(string cmdName, Dictionary<string, object> args, string order, int pagesize, int page, out int count)
        {
            return QueryPage(null, cmdName, args, order, pagesize, page, out count);
        }

        public virtual DataSet QueryPage(string tranID, string cmdName, Dictionary<string, object> args, string order, int pagesize, int page, out int count)
        {
            if (args == null)
                args = new Dictionary<string, object>();// nullArgs;
            Database db;
            string dbName;
            DbCommand cmd = PrepareCommand(cmdName, args, out db,out dbName);
            DataSet ds = null;
            count = 0;
            if (tranID == null && !args.ContainsKey("__NODEFAULTTRAN"))
                tranID = HttpContext.Current.Items["__DEFAULTTRANID"] as string;

            DbTransaction tran = this.getTran(db, tranID, false);
            SqlHelper sqlhelper = SqlHelper.Instance;
            string sql = cmd.CommandText;

            //Tool.Trace("[DBHelper.Query]", "tranID", tran==null?"null":tranID, "cmd", cmd);
            if (pagesize > 0 && order != null && order != "")
            {
                if (!cmd.CommandType.Equals(CommandType.Text))
                {
                    throw new ApplicationException("By page query must is a sql,can not is a procedure(Cmd:" + cmdName + ")");
                }
                else
                {
                    if (page < 1)
                        page = 1;
                    try
                    {
                        cmd.CommandText = sqlhelper.CountSql(sql);
                        Tool.Trace("[DBHelper.QueryPage]Count Sql", "tranID", tranID, "tran", tran == null ? "null" : "OK","DBName",dbName, "cmd", cmd);
                        if (tran == null)
                            count = int.Parse(db.ExecuteScalar(cmd).ToString());
                       else
                            count = int.Parse(db.ExecuteScalar(cmd,tran).ToString());
                        Tool.Trace("[DBHelper.QueryPage]Count Result", "count", count);
                    }
                    catch (Exception ex)
                    {
                        Tool.Error("[DBHelper.QueryPage]Count Sql", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd, "ex", ex.Message);
                        throw;
                        /*
                        throw new ApplicationException("Query count fail(Message:" + ex.Message
                            + " cmdName:" + cmdName
                            + " sql:" + cmd.CommandText, ex);
                        */
                    }

                    if (count > 0)
                    {

                        if ((page - 1) * pagesize >= count)
                            page = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(count) / Convert.ToDecimal(pagesize)));

                        cmd.CommandText = sqlhelper.PageSql(sql, order, pagesize, page);
                        try
                        {
                            Tool.Trace("[DBHelper.QueryPage]Page Sql", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd);
                            if (tran == null)
                                ds = db.ExecuteDataSet(cmd);
                            else
                                ds = db.ExecuteDataSet(cmd, tran);

                            //ds = db.ExecuteDataSet(cmd);
                            Tool.Trace("[DBHelper.QueryPage]Page Result(Rows)", "ds", ds);
                        }
                        catch (Exception ex)
                        {
                            Tool.Error("[DBHelper.QueryPage]Page Sql", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd, "ex", ex.Message);
                            throw;
                            /*
                            throw new ApplicationException("Query data fail(Message:" + ex.Message
                                        + " cmdName:" + cmdName
                                        + " sql:" + cmd.CommandText, ex);
                            */
                        }
                    }
                }
            }
            else
            {
                try
                {
                    if (order != null && order != "")
                    {
                        if (order.StartsWith(","))
                            order = order.Substring(1);
                        cmd.CommandText = sqlhelper.PageSql(sql, order, 0, page);
                    }

                    //ds = db.ExecuteDataSet(cmd);
                    Tool.Trace("[DBHelper.QueryPage]NoPage Sql", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd);
                    if (tran == null)
                        ds = db.ExecuteDataSet(cmd);
                    else
                        ds = db.ExecuteDataSet(cmd, tran);


                    Tool.Trace("[DBHelper.QueryPage]NoPage Result(Rows)", "ds", ds);
                    if (ds != null && ds.Tables.Count > 0)
                        count = ds.Tables[0].Rows.Count;
                    Tool.Trace("[DBHelper.QueryPage]NoPage Result(Count)", "count", count);

                }
                catch (Exception ex)
                {
                    Tool.Error("[DBHelper.QueryPage]NoPage Sql", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd, "ex", ex.Message);
                    throw;
                    /*
                    throw new ApplicationException("Query no page data fail(Message:" + ex.Message
                       + " cmdName:" + cmdName
                       + " sql:" + cmd.CommandText, ex);
                    */
                }
            }
            return ds;
        }

        public virtual DataSet Query(string cmdName, Dictionary<string, object> args)
        {
            return Query(null, cmdName, args);
        }

        public DbCommand GetCommand(string cmdName, Dictionary<string, object> args)
        {
            Database db;
            string dbName;
            DbCommand cmd = PrepareCommand(cmdName, args, out db,out dbName);
            string tranID = HttpContext.Current.Items["__DEFAULTTRANID"] as string;
            DbTransaction tran = this.getTran(db, tranID,false);
            if (tran != null)
                cmd.Transaction = tran;
            return cmd;
        }

        public virtual DataSet Query(string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (args == null)
                args = new Dictionary<string, object>();// nullArgs;

            DataSet ds = null;
            Database db;
            string dbName;
            DbCommand cmd = PrepareCommand(cmdName, args, out db,out dbName);
            DbTransaction tran = null;
            try
            {
                if (tranID == null && !args.ContainsKey("__NODEFAULTTRAN"))
                    tranID = HttpContext.Current.Items["__DEFAULTTRANID"] as string;

                tran = this.getTran(db, tranID,false);
                Tool.Trace("[DBHelper.Query]", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd);
                if (tran == null)
                    ds = db.ExecuteDataSet(cmd);
                else
                    ds = db.ExecuteDataSet(cmd, tran);
                Tool.Trace("[DBHelper.Query]Result(Rows)", "ds", ds);
                addOutputParameters(cmd,args);

            }
            catch (Exception ex)
            {
                Tool.Error("[DBHelper.Query]", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd, "ex", ex.Message);
                throw;
                /*
                throw new ApplicationException("Query fail(Message:" + ex.Message
                   + " cmdName:" + cmdName
                   + " tranID:" + tranID
                   + " sql:" + cmd.CommandText, ex);
               */
            }
            return ds;
        }

        public virtual object QueryObject(string cmdName, Dictionary<string, object> args)
        {
            return QueryObject(null, cmdName, args);
        }

        public virtual object QueryObject(string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (args == null)
                args = new Dictionary<string, object>();// nullArgs;
            object o = null;
            Database db;
            string dbName;
            DbCommand cmd = PrepareCommand(cmdName, args, out db, out dbName);
            DbTransaction tran = null;
            try
            {
                if (tranID == null && !args.ContainsKey("__NODEFAULTTRAN"))
                    tranID = HttpContext.Current.Items["__DEFAULTTRANID"] as string;
                tran = this.getTran(db, tranID, false);
                Tool.Trace("[DBHelper.QueryObject]", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd);
                if (tran == null)
                    o = db.ExecuteScalar(cmd);
                else
                    o = db.ExecuteScalar(cmd, tran);
                Tool.Trace("[DBHelper.QueryObject]Result", "o", o);
                addOutputParameters(cmd, args);
            }
            catch (Exception ex)
            {
                Tool.Error("[DBHelper.QueryObject]", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd, "ex", ex.Message);
                throw;
                /*
                throw new ApplicationException("QueryObject fail(Message:" + ex.Message
                   + " cmdName:" + cmdName
                   + " tranID:" + tranID
                   + " sql:" + cmd.CommandText, ex);
               */
            }
            return o;
        }

        public virtual IDataReader QueryReader(string cmdName, Dictionary<string, object> args)
        {
            return QueryReader(null, cmdName, args);
        }

        public virtual IDataReader QueryReader(string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (args == null)
                args = new Dictionary<string, object>();// nullArgs;
            IDataReader o = null;
            Database db;
            string dbName;
            DbCommand cmd = PrepareCommand(cmdName, args, out db, out dbName);
            DbTransaction tran = null;
            try
            {
                if (tranID == null && !args.ContainsKey("__NODEFAULTTRAN"))
                    tranID = HttpContext.Current.Items["__DEFAULTTRANID"] as string;
                tran = this.getTran(db, tranID, false);
                Tool.Trace("[DBHelper.QueryReader]", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd);
                if (tran == null)
                    o = db.ExecuteReader(cmd);
                else
                    o = db.ExecuteReader(cmd, tran);
                Tool.Trace("[DBHelper.QueryReader]Result", "o", o);
                addOutputParameters(cmd, args);
            }
            catch (Exception ex)
            {
                Tool.Error("[DBHelper.QueryReader]", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd, "ex", ex.Message);
                throw;
                /*
                throw new ApplicationException("QueryObject fail(Message:" + ex.Message
                   + " cmdName:" + cmdName
                   + " tranID:" + tranID
                   + " sql:" + cmd.CommandText, ex);
               */
            }
            return o;
        }

        public virtual int Execute(string cmdName, Dictionary<string, object> args)
        {
            return this.Execute(null, cmdName, args);
        }

        public virtual int Execute(string tranID, string cmdName, Dictionary<string, object> args)
        {
            return this.Execute<int>(null, cmdName, args);
        }

        public virtual object ExecuteObject(string cmdName, Dictionary<string, object> args)
        {
            return this.ExecuteObject(null, cmdName, args);
        }

        public virtual object ExecuteObject(string tranID, string cmdName, Dictionary<string, object> args)
        {
            return this.Execute<object>(null, cmdName, args);
        }

        public virtual IDataReader ExecuteReader(string cmdName, Dictionary<string, object> args)
        {
            return this.ExecuteReader(null, cmdName, args);
        }

        public virtual IDataReader ExecuteReader(string tranID, string cmdName, Dictionary<string, object> args)
        {
            return this.Execute<IDataReader>(null, cmdName, args);
        }

        public virtual DataSet ExecuteDataSet(string cmdName, Dictionary<string, object> args)
        {
            return this.ExecuteDataSet(null, cmdName, args);
        }

        public virtual DataSet ExecuteDataSet(string tranID, string cmdName, Dictionary<string, object> args)
        {
            return this.Execute<DataSet>(null, cmdName, args);
        }

        public virtual T Execute<T>(string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (args == null)
                args = new Dictionary<string, object>();// nullArgs;
            Database db;
            string dbName;
            DbCommand cmd = PrepareCommand(cmdName, args, out db,out dbName);
            DbTransaction tran = null;
            try
            {
                object ret;
                if (tranID == null && !args.ContainsKey("__NODEFAULTTRAN"))
                    tranID = HttpContext.Current.Items["__DEFAULTTRANID"] as string;

                tran = this.getTran(db, tranID,true);
                Tool.Trace("[DBHelper.Execute]", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd);
                if (tran == null)
                {
                    if (typeof(T) == typeof(int))
                    {
                        ret = db.ExecuteNonQuery(cmd);
                    }
                    else if (typeof(T) == typeof(DataSet))
                    {
                        ret = db.ExecuteDataSet(cmd);
                    }
                    else if (typeof(T) == typeof(IDataReader))
                    {
                        ret = db.ExecuteReader(cmd);
                    }
                    else
                    {
                        ret = db.ExecuteScalar(cmd);
                    }
                }
                else
                {
                    if (typeof(T) == typeof(int))
                    {
                        ret = db.ExecuteNonQuery(cmd, tran);
                    }
                    else if (typeof(T) == typeof(DataSet))
                    {
                        ret = db.ExecuteDataSet(cmd, tran);
                    }
                    else if (typeof(T) == typeof(IDataReader))
                    {
                        ret = db.ExecuteReader(cmd,tran);
                    }
                    else
                    {
                        ret = db.ExecuteScalar(cmd, tran);
                    }
                }
                /*
                /// <summary>
                /// 注Log的原則:
                /// 指DBHelper.Execute
                /// 如果是用戶業務過程產生的數據，如送審，退單，核准等。應該記錄
                /// 而如果是系統Job或系統行為，則不應該也不需要記錄此項Log數據(需要調用此類的NoLogResult方法停止日志過程)
                /// 而是記錄這項系統Job的行為 ,如發送Email的Job，只記錄有Email發送數據的開始和結束過程即可
                 * 以及如批次發送簡訊，執行報廢樣品單送審，批次回寫注記等過程則為同一原則
                 * 而如果是由用戶發起（如PccMessenger主動收取信息，則一般不需要記錄Log，因為訊息發送資料行會完成記錄這個過程）
                 * Kevin.zou 2010.11.25 注
                /// </summary>
                */
                if (!args.ContainsKey("__NoLogResult") 
                    || args["__NoLogResult"].ToString().Trim() != "1")
                    Tool.Info("[DBHelper.Execute]", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, "cmd", cmd, "ret", ret);
                addOutputParameters(cmd, args);
                if (this.OnExecute != null)
                    this.OnExecute(ret, cmd, tran, tranID, cmdName, args);
                return (T)ret;
            }
            catch (Exception ex)
            {
                Tool.Error("[DBHelper.Execute]", "tranID", tranID, "tran", tran == null ? "null" : "OK", "DBName", dbName, " cmd", cmd, "ex", ex.Message);
                throw;
                /*
                throw new ApplicationException("Execute fail(Message:" + ex.Message
                   + " cmdName:" + cmdName
                   + " tranID:" + tranID
                   + " sql:" + cmd.CommandText, ex);
               */
            }
        }

        #endregion

        #region 參數設置

        public void NoUseDefaultTran(Dictionary<string, object> args)
        {
            args["__NODEFAULTTRAN"] = 1;
        }

        public void SetDB(Dictionary<string, object> args, string db)
        {
            args["__DB"] = db.IndexOf(".")<0? "Database_" + db:db;
        }

        public void SetSql(Dictionary<string, object> args, string sql)
        {
            args["__SQL"] = sql;
        }

        public void SetOutputParams(Dictionary<string, object> args)
        {
            args["__OutputParams"] = 1;
        }


        public void SetTimeOut(Dictionary<string, object> args,int timeoutSeconds)
        {
            args["__TIMEOUT"] = timeoutSeconds;
            //gscm轉檔很多，寫很多日志浪費
            //Tool.Info("Set Command TimeOut(oracle無效)", "seconds", timeoutSeconds);
        }

        public Dictionary<string, object> GetOutputParams(Dictionary<string, object> args)
        {
            if(args.ContainsKey("__OutputParams"))
                return args["__OutputParams"] as Dictionary<string,object>;
            return null;
        }

        public void NoLogResult(Dictionary<string, object> args)
        {
            args["__NoLogResult"] = 1;
        }

        public void AddParameterManual(Dictionary<string, object> args)
        {
            args["__ADD_PARAMETERS"] = 1;
        }

        public void NoCache(Dictionary<string, object> args)
        {
            args["__NoCache"] = 1;
        }

        public bool IsMatchCatch(Dictionary<string, object> args)
        {
            return args.ContainsKey("__MatchCatch");
        }

        #endregion

        #region private member(preparecommand)

        DbCommand PrepareCommand(string cmdName, Dictionary<string, object> args, out Database db, out string name)
        {
            try
            {
                SqlHelper sqlHelper = SqlHelper.Instance;
                sqlHelper.FillCfgParams(cmdName, args);
                string text = "";
                if (args.ContainsKey("__SQL"))
                    text = args["__SQL"].ToString();
                else
                    text = sqlHelper.CommandSql(cmdName, args);
                string type = sqlHelper.CommandType(cmdName);
                //string name = "";
                if (args.ContainsKey("__DB"))
                    name = args["__DB"].ToString();
                else
                    name = sqlHelper.CommandDb(cmdName);
                //string dbMapName = AppEventHanlder.Instance.ServiceVar(name);
                //if (dbMapName!=null && dbMapName.Length > 0)
                //{
                //    Tool.Trace("get service var(map current db)", "db", name, "new", dbMapName);
                //    name = dbMapName;
                //}
                Tool.Trace("parse database", "DB", name);
                try
                {
                    db = ObjectFactory.Default.Get<Database>(name);
                }
                catch(Exception ex)
                {
                    throw new ApplicationException("get db error:" + name + ",ex:" + ex.ToString());
                }
                DbCommand ret;
                if (type != null && type.Equals("procedure"))
                    ret = PrepareProcCommand(db, text.Trim().Replace("\r", "").Replace("\n", ""), args);
                else
                    ret = PrepareSqlCommand(db, text, args);
                if (args.ContainsKey("__TIMEOUT"))
                    ret.CommandTimeout = (int)args["__TIMEOUT"];
                return ret;
            }
            catch (Exception ex)
            {
                throw new ApplicationException("PrepareCommand exception,cmdName:" + cmdName + ",ex:" + ex.ToString());
            }
        }

        void addProcParameters(Database db, DbCommand cmd, Dictionary<string, object> args)
        {
            if (args != null)
            {


                if (args.ContainsKey("__ADD_PARAMETERS") && args["__ADD_PARAMETERS"].ToString()=="1")
                {
                    foreach (string key in args.Keys)
                    {
                        if (!key.StartsWith("__"))
                            cmd.Parameters.Add(db.CreateParameter(key, args[key] ?? DBNull.Value));
                    }
                }
                else
                {
                    for (int i = cmd.Parameters.Count -1; i >=0; i--)
                    {
                        DbParameter p = cmd.Parameters[i];
                        if (p.Direction.Equals(ParameterDirection.Input) || p.Direction.Equals(ParameterDirection.InputOutput))
                        {
                            string argKey = p.ParameterName.Replace("@", "");   //sql server的參數會帶@
                            if (args.ContainsKey(argKey))
                            {
                                p.Value = args[argKey] ?? DBNull.Value;
                            }
                            else
                            {
                                //未傳參數，則使用procedure的默認參數 
                                //目前看應該不會影響到各系統，有的話，再修改
                                //kevin.zou 2010.12.04注
                                cmd.Parameters.RemoveAt(i);
                                //p.Value = DBNull.Value;
                            }
                        }
                    }
                }

            }
        }

        DbCommand PrepareProcCommand(Database db, string procname, Dictionary<string, object> args)
        {
            DbCommand cmd = db.GetStoredProcCommand(procname);
            using (DbConnection conn = db.CreateConnection())
            {
                try
                {
                    cmd.Connection = conn;
                    cmd.Connection.Open();
                    if (db.DBType.Equals(DatabaseType.Oracle))
                        OracleCommandBuilder.DeriveParameters((OracleCommand)cmd);
                    else
                        SqlCommandBuilder.DeriveParameters((SqlCommand)cmd);
                    cmd.Connection.Close();
                    addProcParameters(db,cmd, args);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException("PrepareProcCommand Fail(in Connection Open or DeriveParameters)(Message:" + ex.Message
                           + " procname:" + procname
                           + " db:" + db.DBType.ToString(), ex);
                }

            }
            return cmd;
        }

        class SqlDyHelper
        {
            public SqlDyHelper(Database db, DbCommand cmd, Dictionary<string, object> args)
            {
                _db = db;
                _cmd = cmd;
                _args = args;
            }

            Dictionary<string, object> _args;
            DbCommand _cmd;
            Database _db;

            public string capText(Match match)
            {
                string mStr = match.ToString();
                string paramName = mStr.Substring(1, mStr.Length - 2);        //*paramName*
                if (!_args.ContainsKey(paramName))
                    throw new ApplicationException("The sql paramter is not provided(Param:" + paramName + ")");
                else
                {
                    string realParamName = (_db.DBType.Equals(DatabaseType.Oracle) ? "" : "@") + paramName;
                    if (!_cmd.Parameters.Contains(realParamName))
                    {
                        //不知道，為什么，如果用這種方式加Parameter，就會讓QueryReader，oracle查詢long欄位類型超慢，所以改成下面的方式代替
                        //原因暫時不明，可能是Database.ConfigureParameter方法有動到什么吧?以后有興趣再查
                        //_db.AddInParameter(_cmd, realParamName, _args[paramName]);
                        _cmd.Parameters.Add(_db.CreateParameter(realParamName, _args[paramName] ?? DBNull.Value));
                    }
                    return (_db.DBType.Equals(DatabaseType.Oracle) ? ":" : "@") + paramName;
                }
            }
        }

        DbCommand PrepareSqlCommand(Database db, string sql, Dictionary<string, object> args)
        {
            DbCommand cmd = db.GetSqlStringCommand("");
            SqlDyHelper dyHelper = new SqlDyHelper(db, cmd, args);
            MatchEvaluator me = new MatchEvaluator(dyHelper.capText);
            sql = Regex.Replace(sql, @"\*[0-9_a-zA-Z]*?\*", me);
            cmd.CommandText = sql;
            return cmd;
        }

        #endregion
    }

    /*
    /// <summary>
    /// 用Decorator模式實現Cache比繼承實現Cache可多方面進行切入
    /// 但是需要有2個配置文件
    /// </summary>
    public class CacheDBHelper : DBHelper
    {

        DBHelper _dbHelper;
        HttpCache _cache;
        Dictionary<string, List<string>> _cacheKeys;

        public CacheDBHelper()
            :this(DBHelper.OrgInstance)
        {
        }

        public CacheDBHelper(DBHelper dbHelper)
        {
            _dbHelper = dbHelper;
            _cache = new HttpCache(this.GetType().FullName);
            _cacheKeys = new Dictionary<string, List<string>>();
            SqlHelper.Instance.Config.OnConfigRefresh += new ConfigRefreshCallback(Config_OnConfigRefresh);
        }

        void Config_OnConfigRefresh(string name)
        {
            //修改keys依賴時，可能帶來的負面影響
            Tool.Trace("DBHelper的Config變化","name",name);
            try
            {
                name = name.Substring(0, name.Length - 4);
                _cache.Clear(name);      //clear .sql
                // throw new Exception("The method or operation is not implemented.");

                foreach (string key in _cacheKeys.Keys)
                {
                    if (_cacheKeys[key].Contains(name))
                        _cacheKeys[key].Remove(name);
                }
            }
            catch (Exception ex)
            {
                Tool.Warn("CacheDBHelper的Config_OnConfigRefresh異常","ex", ex);
                //忽略多線程帶的來cache存儲問題
            }

        }

        #region cache 相關

        string composeParams(Dictionary<string, object> args)
        {
            StringBuilder sb = new StringBuilder();
            if (args != null)
            {
                if (args.ContainsKey("__NoCache"))
                    return null;
                foreach (string key in args.Keys)
                {
                    if (args[key] != null)
                        sb.AppendFormat("{0}{1}={2}", sb.Length > 0 ? "#" : "", key, args[key].ToString().Trim());
                }
            }
            return sb.ToString();
        }

        string composeParams(Dictionary<string, object> args, string order, int pagesize, int page)
        {
            string argStr = composeParams(args);
            if (argStr != null)
                return argStr + "_" + order + "_" + pagesize.ToString() + "_" + page.ToString();
            return null;
        }

        void saveCache(string cmdname, string queryParams, object queryResult)
        {
            if (queryParams == null)
                return;
            try
            {
                //記錄key與command的對應關系
                string[] keys = SqlHelper.Instance.CommandCacheKeys(cmdname);
                if (keys != null && keys.Length > 0)
                {
                    Dictionary<string, object> result;
                    if (!_cache.Contains(cmdname))
                    {
                        result = new Dictionary<string, object>();
                        //string depPath = SqlHelper.Instance.Config.DepPath(cmdname);
                        _cache.Set(cmdname, result);//, depPath);
                    }
                    result = _cache.Get<Dictionary<string, object>>(cmdname);
                    if (result.ContainsKey(queryParams))
                        result[queryParams] = queryResult;
                    else
                        result.Add(queryParams, queryResult);

                    foreach (string key in keys)
                    {
                        if (!_cacheKeys.ContainsKey(key))
                            _cacheKeys.Add(key, new List<string>());
                        if (!_cacheKeys[key].Contains(cmdname))
                            _cacheKeys[key].Add(cmdname);
                    }
                }
            }
            catch (Exception ex)
            {
                Tool.Warn("CacheDBHelper的saveCache異常","ex", ex);
                //忽略多線程帶的來cache存儲問題
            }

        }

        const string CACHENOTFOUND = "CACHENOTFOUND";

        object getCache(string cmdname, string queryParams)
        {
            if (queryParams == null)
                return CACHENOTFOUND;
            try
            {
                if (_cache.Contains(cmdname))
                {
                    Dictionary<string, object> result = _cache.Get<Dictionary<string, object>>(cmdname);
                    if (result.ContainsKey(queryParams))
                        return result[queryParams];
                }
            }
            catch (Exception ex)
            {
                Tool.Warn("CacheDBHelper的getCache異常", "ex", ex);
                //忽略多線程帶的來cache存儲問題
            }
            return CACHENOTFOUND;
        }

        void clearCache(string cmdname)
        {
            try
            {
                string[] keys = SqlHelper.Instance.CommandCacheKeys(cmdname);
                if (keys != null)
                {
                    foreach (string key in keys)
                    {
                        if (_cacheKeys.ContainsKey(key))
                        {
                            List<string> cmds = _cacheKeys[key];
                            foreach (string cmd in cmds)
                            {
                                Tool.Trace("Clear Cache","key", key,"cmdname", cmdname);

                                _cache.Clear(cmd);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Tool.Warn("CacheDBHelper的clearCache異常", "ex", ex);
                //忽略多線程帶的來cache存儲問題
            }

        }

        #endregion

        #region 命令調用

        public override DataSet QueryPage(string cmdName, Dictionary<string, object> args, string order, int pagesize, int page, out int count)
        {
            if (args != null && args.ContainsKey("__MatchCatch"))
                args.Remove("__MatchCatch");
            DataSet ds = null;
            count = 0;
            string queryParams = composeParams(args, order, pagesize, page);
            object cache = getCache(cmdName, queryParams);
            if (cache != null && cache.ToString() == CACHENOTFOUND)
            {
                ds = _dbHelper.QueryPage(cmdName, args, order, pagesize, page, out count);
                saveCache(cmdName, queryParams, new object[] { ds, count });
            }
            else
            {
                Tool.Trace("Match Cache", "cmdName", cmdName, "queryParams", queryParams);
                object[] ret = cache as object[];
                ds = ret[0] as DataSet;
                count = (int)ret[1];
                if (args != null)
                    args["__MatchCatch"] = queryParams;

            }
            return ds;
        }

        public override DataSet Query(string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (args != null && args.ContainsKey("__MatchCatch"))
                args.Remove("__MatchCatch");
            if (tranID == null)     //事物處理不緩存
            {
                DataSet ds = null;
                string queryParams = composeParams(args);
                object cache = getCache(cmdName, queryParams);
                if (cache != null && cache.ToString() == CACHENOTFOUND)
                {
                    ds = _dbHelper.Query(tranID, cmdName, args);
                    saveCache(cmdName, queryParams, ds);
                }
                else
                {
                    Tool.Trace("Match Cache", "cmdName", cmdName, "queryParams", queryParams);
                    ds = cache as DataSet;
                    if (args != null)
                        args["__MatchCatch"] = queryParams;
                }
                return ds;
            }
            return _dbHelper.Query(tranID, cmdName, args);
        }

        public override object QueryObject(string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (args != null && args.ContainsKey("__MatchCatch"))
                args.Remove("__MatchCatch");
            if (tranID == null)     //事物處理不緩存
            {
                object ret = null;
                string queryParams = composeParams(args);
                object cache = getCache(cmdName, queryParams);
                if (cache != null && cache.ToString() == CACHENOTFOUND)
                {
                    ret = _dbHelper.QueryObject(tranID, cmdName, args);
                    saveCache(cmdName, queryParams, ret);
                }
                else
                {
                    Tool.Trace("Match Cache", "cmdName", cmdName, "queryParams", queryParams);
                    ret = cache;
                    if (args != null)
                        args["__MatchCatch"] = queryParams;

                }
                return ret;
            }
            return _dbHelper.QueryObject(tranID, cmdName, args);

        }

        public override IDataReader QueryReader(string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (args != null && args.ContainsKey("__MatchCatch"))
                args.Remove("__MatchCatch");
            if (tranID == null)     //事物處理不緩存
            {
                IDataReader ret = null;
                string queryParams = composeParams(args);
                object cache = getCache(cmdName, queryParams);
                if (cache != null && cache.ToString() == CACHENOTFOUND)
                {
                    ret = _dbHelper.QueryReader(tranID, cmdName, args);
                    saveCache(cmdName, queryParams, ret);
                }
                else
                {
                    Tool.Trace("Match Cache", "cmdName", cmdName, "queryParams", queryParams);
                    ret = cache as IDataReader;
                    if (args != null)
                        args["__MatchCatch"] = queryParams;

                }
                return ret;
            }
            return _dbHelper.QueryReader(tranID, cmdName, args);

        }
                
        public override T Execute<T>(string tranID, string cmdName, Dictionary<string, object> args)
        {
        //public override int Execute(string tranID, string cmdName, Dictionary<string, object> args)
        //{
            clearCache(cmdName);
            return _dbHelper.Execute<T>(tranID, cmdName, args);
        }

        #endregion

    }

    //沒有再用decorator模式(用不著目前,不需要這么大的靈活性,直接繼承,不要裝飾了)
    public class DeveloperDBHelper : CacheDBHelper
    {
        const string DBACCESS_RIGHTKIND = "DBAccessDevelop";      //開發人員訪問權限(以包和DB,PROCEDURE來控制?)

        public override DataSet QueryPage(string tranID,string cmdName, Dictionary<string, object> args, string order, int pagesize, int page, out int count)
        {
            if (RightsProvider.Instance.HasDataRight(DBACCESS_RIGHTKIND,cmdName))
            {
                return base.QueryPage(tranID, cmdName, args, order, pagesize, page, out count);
            }
            count = 0;
            return null;
        }

        public override DataSet Query(string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (RightsProvider.Instance.HasDataRight(DBACCESS_RIGHTKIND, cmdName))
            {
                return base.Query(tranID, cmdName, args);
            }
            return null;
        }

        public override object QueryObject(string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (RightsProvider.Instance.HasDataRight(DBACCESS_RIGHTKIND, cmdName))
            {
                return base.Query(tranID, cmdName, args);
            }
            return null;
        }

        public override IDataReader QueryReader(string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (RightsProvider.Instance.HasDataRight(DBACCESS_RIGHTKIND, cmdName))
            {
                return base.QueryReader(tranID, cmdName, args);
            }
            return null;
        }

        public override T Execute<T>(string tranID, string cmdName, Dictionary<string, object> args)
        {
            if (RightsProvider.Instance.HasDataRight(DBACCESS_RIGHTKIND, cmdName))
            {
                return base.Execute<T>(tranID, cmdName, args);
            }
            return default(T);
        }
    }

    */
}