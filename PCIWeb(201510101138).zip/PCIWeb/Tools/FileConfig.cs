﻿using System;
using System.IO;
using System.Web;
using System.Web.Caching;
using System.Collections.Generic;

namespace PCIWeb.Tools
{
    public delegate void ConfigRefreshCallback(string name);

    public interface IConfig
    {

        event ConfigRefreshCallback OnConfigRefresh;

        T Parse<T>(string name) where T : class;

        bool HasConfig(string name);
    }

    public abstract class AConfig : IConfig
    {

        HttpCache _cache;
        protected string _subDir;

        public string SubDir
        {
            get
            {
                return _subDir;
            }
        }

        public AConfig(string subDir)
        {
            _subDir = subDir;

            _cache = new HttpCache("Config." + subDir);
            _cache.OnCacheRemove += new CacheItemRemovedCallback(_cache_OnCacheRemove);

        }

        public void ClearCache(string name)
        {
            _cache.Clear(name);
        }


        void _cache_OnCacheRemove(string key, object value, CacheItemRemovedReason reason)
        {
            if (this.OnConfigRefresh != null)
                this.OnConfigRefresh(key);
        }

        public event ConfigRefreshCallback OnConfigRefresh;

        object _lockGetLockObjId = new object();
        Dictionary<string, object> _lockID = new Dictionary<string, object>();

        object getLockObj(string objectID)
        {
            lock (_lockGetLockObjId)
            {
                if (!_lockID.ContainsKey(objectID))
                {
                    _lockID.Add(objectID, new object());
                }
                return _lockID[objectID];
            }
        }


        public virtual T Parse<T>(string name) where T : class
        {
            string cacheKey = name;
            string configName = AppEventHanlder.Instance.ServiceVarContent();//"Config");
            if (this._subDir!="Dll" && configName != null && configName.Length > 0)
            {
                cacheKey = name + "$" + configName;
            }

            lock (getLockObj(cacheKey))
            {
                T ret = _cache.Get<T>(cacheKey);
                if (ret == null)
                {
                    string path;
                    ret = Parse<T>(name, out path);
                    if (path != null && path != "")
                        _cache.Set(cacheKey, ret, path);
                    else
                        _cache.Set(cacheKey, ret);

                }
                return ret;
            }
        }

        public string GetKey(object o)
        {
            return _cache.CacheKey(o);
        }

        public List<T> Parse<T>() where T : class
        {
            List<string> names = Items();
            if (names != null)
            {
                List<T> ret = new List<T>();
                foreach (string name in names)
                    ret.Add(Parse<T>(name));
                return ret;
            }
            return null;
        }

        public T ParseNoCache<T>(string name) where T : class
        {
            string path;
            return Parse<T>(name, out path);
        }

        public abstract bool HasConfig(string name);

        public abstract List<string> Items();

        public abstract T Parse<T>(string name, out string path) where T : class;

    }

    public interface IParser
    {
        T Read<T>(string text) where T : class;
        //以後應該還有將dic轉成string的method(這個應該是存儲所用)

        string Kind {get;}            //1:用path的內容去解析，2:用path路徑名去解析
    }

    public class SystemConfig
    {
        public static readonly SystemConfig Instance = new SystemConfig();

        FileConfig _config;

        private SystemConfig()
        {
            _config = new FileConfig("", new JsonParser());
        }

        /// <summary>
        /// 用于事件綁定
        /// </summary>
        public FileConfig Config
        {
            get
            {
                return _config;
            }
        }

        public T Get<T>(string key)
        {
            return Get<T>("Config.js",key);
        }

        public T Get<T>(string configFile,string key)
        {
            return Get<T>(configFile,key, '.');
        }

        public T Get<T>(string configFile, string key, char splitKey)
        {
            T ret = default(T);
            Dictionary<string, object> dic = _config.Parse<Dictionary<string, object>>(configFile);
            string[] keys = key.Split(new char[] { splitKey });
            for (int i = 0; i < keys.Length; i++)
            {
                string itemKey = keys[i];
                if (dic == null || !dic.ContainsKey(itemKey))
                    break;
                if (i != keys.Length - 1)       //不是最後一個
                    dic = dic[itemKey] as Dictionary<string, object>;
                else
                    ret = (T)dic[itemKey];
            }
            return ret;
        }
    }

    public class FileConfig : AConfig
    {
        string _path;
        static string CFGDIR = "App_Data\\";
        static string configDir = "";

        protected IParser _parser;

        //public FileConfig(string subDir)
        //    : this(subDir, ObjectFactory.Default.Get<IParser>("Parser_" + subDir))
        //{

        //}

        static FileConfig()
        {
            string dir = "Config";
                
            //獲取當前的IP
            string hostname = System.Net.Dns.GetHostName();
            Tool.Info("讀出當前主機","hostname",hostname);
            System.Net.IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(hostname);
            string ip = null;
            foreach(System.Net.IPAddress strIp in ipEntry.AddressList)
            {
                ip = strIp.ToString();
                Tool.Info("讀出當前主機的IP","ip", ip);
                string config = System.Configuration.ConfigurationManager.AppSettings["Config_" + ip];
                if (config != null && config.Length != 0)
                {
                    dir = config;
                    Tool.Info("當前IP有config路徑設置", "dir", dir);
                    break;
                }
            }
            configDir = CFGDIR + dir;
            Tool.Info("設定當前應用程式配置的根目錄", "configDir", configDir);
        }
        public FileConfig(string subDir, IParser parser)
            :this(subDir,null,parser)
        {

        }
        public FileConfig(string subDir, string searchPatten, IParser parser)
            : base(subDir)
        {

            this.searchPatten = searchPatten;

            _path = System.AppDomain.CurrentDomain.BaseDirectory// HttpContext.Current.Server.MapPath(HttpContext.Current.Request.ApplicationPath)
                //+ "\\" + configDir + (subDir.Length > 0 ? "\\" + subDir : "");
                + configDir + (subDir.Length > 0 ? "\\" + subDir : "");
            //if (!Directory.Exists(_path))
            //    Directory.CreateDirectory(_path);

            _parser = parser;
        }

        public override bool HasConfig(string name)
        {
            throw new ApplicationException("暫時未用此方法，因此已用SystemConfig先抓一次(ajax injector)kevin.zou 2010.1.23注");
            //string path = _path + "\\" + name;
            //return !File.Exists(path);
        }

        public override T Parse<T>(string name, out string path)
        {
            //檢查是否有針對此項進行配置以便轉換
            //配置字串ClientTool.Query?Config=WFORACLE,PGD
            List<string> searchConfigPaths = new List<string>();
            string[] configKeys = null;
            //.dll也可以直接放在舊的里面了哦
            //.dll和.dll.service不能config變化，不同的配置需要使用相同的代碼
            bool noExt = this._subDir == "ObjectFactory" || this._subDir == "Valid";
            if (!name.EndsWith(".dll.service") && !name.EndsWith(".dll"))     //dll不能config變化,因為沒辦法動態卸載,而且
            {
                //舊服務書寫方式繼續兼容,ObjectFactory沒有后綴,文件名有.,而SqlHelper,MailTemplate等則是用/斜杠訪問子文件夾
                string ext = "";
                string subFileNoExt = name;
                if (!noExt)     //如Insert_CTS_FORM@CTS這種
                {
                    int extIndex = name.LastIndexOf(".");
                    ext = name.Substring(extIndex);
                    subFileNoExt = name.Substring(0, extIndex);
                }
                string configName = AppEventHanlder.Instance.ServiceVarContent();// ("Config");
                if (configName != null && configName.Length > 0)
                {
                    configKeys = configName.Split(new char[] { ',' });
                    foreach (string configKey in configKeys)
                    {
                        if(configKey.IndexOf("-")<0)
                            searchConfigPaths.Add(_path + "\\" + subFileNoExt + "$" + configKey + ext);
                    }
                }
            }
            searchConfigPaths.Add(_path + "\\" + name);
            string[] allPaths = new string[searchConfigPaths.Count];
            searchConfigPaths.CopyTo(allPaths);
            path = String.Join(";", allPaths);
            foreach (string configPath in searchConfigPaths)
            {
                Tool.Trace("search config", "name", name, "config", configPath);
                if (File.Exists(configPath))
                    return getResultFromFile<T>(configPath);
            }

            //新的在Apps中的config,不支援/斜杠
            //DyDll直接配置成xxx.service這樣,而不是之前的xxx.dll.service
            if (name.IndexOf("/") < 0 && !name.EndsWith(".dll.service") && name!="Install.js")        //.dll.service不搜尋app,新的后綴直接為.service
            {
                //嘗試在Apps中搜尋config
                //先找Apps中的config
                //ObjectFactory中的配置會加.js后綴了,在IDE中好看(ObjectFactory中不傳,但是這里主動加)

                //TODO:如果是$xxx@db的sql和valid,則直接轉成db前一個的service來加總
                //TODO:調用db command,也可以改成調用一個service

                //置換appID，將代碼中的appID動態替換成新的appID
                //而下面的Install.js則是將appID映射到物理安裝目錄中去
                name = AppEventHanlder.Instance.GetInstallNameByHardCode(name);
                string[] names = (name + (noExt ? ".json" : name.EndsWith(".js")?"on":"")).Split(new char[] { '.' });      //最后一個是后綴名可能(但service卻不是?)
                //找尋APP Folder位置
                string appFolder = null;
                int appFolderIndex = 0;
                for (int i = 2; i < names.Length; i++)
                {
                    //有安裝目錄變化
                    string installPath = SystemConfig.Instance.Get<string>("Install.js", String.Join(".", names, 0, names.Length - i),'$');
                    if (installPath != null)
                    {
                        names = (installPath + "/" + String.Join("/",names,names.Length-i,i)).Split(new char[] { '/' });
                        appFolder = System.AppDomain.CurrentDomain.BaseDirectory + "Apps\\" +
                            installPath.Replace(".","\\") + "\\_service";
                        appFolderIndex = installPath.Split(new char[] { '.' }).Length;
                        break;
                    }

                    appFolder = System.AppDomain.CurrentDomain.BaseDirectory + "Apps\\" +
                        String.Join("\\", names, 0, names.Length - i) + "\\_service";
                    Tool.Trace("search App", "name", name, "appFolder", appFolder);
                    if (Directory.Exists(appFolder))
                    {
                        appFolderIndex = names.Length - i;
                        break;
                    }
                }
                //找到App了
                if (appFolderIndex > 0)
                {
                    string fileName = String.Join("\\", names, appFolderIndex, names.Length - appFolderIndex -1);
                    string fileExt = names[names.Length - 1];

                    searchConfigPaths = new List<string>();
                    if (fileExt!="dll")
                    {
                        if (configKeys != null)
                        {
                            foreach (string configKey in configKeys)
                                if (configKey.IndexOf("-") < 0)
                                    searchConfigPaths.Add(appFolder + "\\" + this._subDir + "\\" + fileName + "$" + configKey + "." + fileExt);
                        }
                    }
                    searchConfigPaths.Add(appFolder + "\\" + this._subDir + "\\" + fileName + "." + fileExt);
                    foreach (string configPath in searchConfigPaths)
                    {
                        Tool.Trace("search config(Apps)", "name", name, "config", configPath);
                        if (File.Exists(configPath))
                        {
                            allPaths = new string[searchConfigPaths.Count];
                            searchConfigPaths.CopyTo(allPaths);
                            path = String.Join(";", allPaths);

                            return getResultFromFile<T>(configPath);
                        }
                    }

                }

            }
            return null;

        }

        T getResultFromFile<T>(string path) where T : class
        {
            T ret = null;
            if (_parser.Kind == "2")
            {
                ret = _parser.Read<T>(path);
            }
            else
            {
                string cfgStr = File.ReadAllText(path, System.Text.Encoding.Default);
                if (cfgStr.Trim().Length > 0)
                    ret = _parser.Read<T>(cfgStr);
                else
                    Tool.Trace("No Content", "path", path);
            }
            return ret;
        }

        string searchPatten = null;

        public override List<string> Items()
        {
            List<string> ret = new List<string>();
            if (Directory.Exists(_path))
            {
                DirectoryInfo dir = new DirectoryInfo(_path);
                FileInfo[] files = this.searchPatten == null ? dir.GetFiles() : dir.GetFiles(this.searchPatten);
                foreach (FileInfo file in files)
                    ret.Add(file.Name);
            }
            return ret;
        }

        public List<string> FolderItems(string subDir)
        {
            List<string> ret = new List<string>();
            if (Directory.Exists(_path))
            {
                DirectoryInfo dir = new DirectoryInfo(_path + "\\" + subDir);
                FileInfo[] files = this.searchPatten == null ? dir.GetFiles() : dir.GetFiles(this.searchPatten);
                foreach (FileInfo file in files)
                    ret.Add(file.Name);
            }
            return ret;
        }

        public List<string> Folders()
        {
            List<string> ret = new List<string>();
            if (Directory.Exists(_path))
            {

                DirectoryInfo dir = new DirectoryInfo(_path);
                DirectoryInfo[] folders = this.searchPatten == null ? dir.GetDirectories() : dir.GetDirectories(this.searchPatten);
                foreach (DirectoryInfo folder in folders)
                    ret.Add(folder.Name);
            }
            return ret;
        }

        public void DeleteConfig(string path)
        {
            Tool.Info("Delete Config", "path", path);
            File.Delete(_path + "\\" + path);
        }

        public void SaveConfig(string path, string config)
        {
            Tool.Info("Save Config", "path", path,"config",config);
            File.WriteAllText(_path + "\\" + path, config, System.Text.Encoding.UTF8);
        }

        public string ConfigPath(string path)
        {
            return _path + "\\" + path;
        }

        public bool ConfigExist(string path)
        {
            return File.Exists(_path + "\\" + path);
        }

        public static T Get<T>(Dictionary<string, object> dic,string key)
        {
            return Get<T>(dic,key, '.');
        }

        public static T Get<T>(Dictionary<string, object> dic, string key, char splitKey)
        {
            T ret = default(T);
            string[] keys = key.Split(new char[] { splitKey });
            for (int i = 0; i < keys.Length; i++)
            {
                string itemKey = keys[i];
                if (dic == null || !dic.ContainsKey(itemKey))
                    break;
                if (i != keys.Length - 1)       //不是最後一個
                    dic = dic[itemKey] as Dictionary<string, object>;
                else
                    ret = (T)dic[itemKey];
            }
            return ret;
        }
    }

    public class ConfigReader
    {
        FileConfig config;

        public ConfigReader(string dir)
        {
            config = new FileConfig(dir, new JsonParser());
        }

        public Dictionary<string, object> GetContent(string file)
        {
            return config.Parse<Dictionary<string, object>>(file);
        }
    }

    public class ConfigHelper
    {

        public Dictionary<string, object> GetConfig(string file)
        {
            string userId = AuthenticateHelper.Instance.UserID;
            string userIP = AppEventHanlder.Instance.UserHost;
            string objKind = "ConfigSet";      //限定FlowAction權限才不會讓TASK從這里鉆進來
            string objId = file;
            if (!RightsProvider.Instance.HasServiceRight(objKind, objId, userIP, userId))
            {
                if (userId == null)
                    throw new PCINeedLoginException(objKind + "." + objId);
                else
                    throw new PCINoPermissionException(userId + ":" + objKind + "." + objId);
            }
            return SystemConfig.Instance.Config.Parse<Dictionary<string, object>>(file);
        }

        //configFile:"TestGit.ObjectFactory.CTS.Flow.Application.json"
        public void SaveAppConfig(string file, string config)
        {
            string userId = AuthenticateHelper.Instance.UserID;
            string userIP = AppEventHanlder.Instance.UserHost;
            string objKind = "ConfigSet";      //限定FlowAction權限才不會讓TASK從這里鉆進來
            string objId = file;
            if (!RightsProvider.Instance.HasServiceRight(objKind, objId, userIP, userId))
            {
                if (userId == null)
                    throw new PCINeedLoginException(objKind + "." + objId);
                else
                    throw new PCINoPermissionException(userId + ":" + objKind + "." + objId);
            }

            int extDotIndex = file.LastIndexOf(".");
            string path = System.AppDomain.CurrentDomain.BaseDirectory + "Apps/" + (file.Substring(0, extDotIndex).Replace(".ObjectFactory", "/_service/ObjectFactory").Replace(".", "/") + "." + file.Substring(extDotIndex + 1));
            Tool.Info("Save App Config", "path", path, "config", config);
            File.WriteAllText(path, config, System.Text.Encoding.UTF8);
        }

        public void SaveConfig(string file, Dictionary<string, object> config)
        {
            string userId = AuthenticateHelper.Instance.UserID;
            string userIP = AppEventHanlder.Instance.UserHost;
            string objKind = "ConfigSet";      //限定FlowAction權限才不會讓TASK從這里鉆進來
            string objId = file;
            if (!RightsProvider.Instance.HasServiceRight(objKind, objId, userIP, userId))
            {
                if (userId == null)
                    throw new PCINeedLoginException(objKind + "." + objId);
                else
                    throw new PCINoPermissionException(userId + ":" + objKind + "." + objId);
            }
            SystemConfig.Instance.Config.SaveConfig(file, Tool.ToJson(config));
        }
    }
}