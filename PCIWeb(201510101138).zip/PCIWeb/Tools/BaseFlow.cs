﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PCIWeb.Tools
{
    public class BaseFlow : BaseForm
    {
        Dictionary<string, object> cfg;

        public BaseFlow(string flowNo,Dictionary<string, object> cfg)
            :base(flowNo)
        {
            this.cfg = cfg;
            this.initCfgParams();
        }

        protected virtual void initCfgParams()
        {
            initParams();
            WFDataBase = Database = cfg["Database"].ToString();              //flow和form在同一資料庫中，事務，數據分離等原因
            Table = cfg["Table"].ToString();                                 // 流程TABLE："HCD_FORM_FLOW";
            FormTable = cfg["FormTable"].ToString();                         // 主TABLE(用于流程表達式計算等) HCD_FORM";
            WFTable = cfg["StepTable"].ToString();
            KeyField = cfg["KeyField"].ToString();                           // 主table和流程table共用一個主KEY "FORM_NO";
            StatusField = cfg["StatusField"].ToString();                     // 主狀態欄位名"STATUS";
            FlowFields = new string[] { DealerField };
        }

        #region override方法

        protected override string DealerField
        {
            get
            {
                return cfg["Dealer"].ToString();
            }
        }

        protected override string StatusMarkField
        {
            get
            {
                return cfg.ContainsKey("StatusMark")?cfg["StatusMark"].ToString():"";
            }
        }

        protected override string ApplyUserIDField
        {
            get
            {
                return cfg["ApplyUserIDField"].ToString();
            }
        }

        #endregion

    }
}
