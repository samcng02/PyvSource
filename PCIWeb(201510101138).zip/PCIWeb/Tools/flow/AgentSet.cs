using System;
using System.Collections.Generic;
using System.Data;

namespace PCIWeb.Tools
{

    /// <summary>
    /// �N�z�]�w
    /// </summary>
    public class AgentSet
    {

        #region �c�ؾ��M��ƪ��]�w

        public AgentSet()
            : this("Flow", "Base_Agent", "AgentID")
        {

        }

        public AgentSet(string db, string tbl, string key)
        {
            _db = db;
            _tbl = tbl;
            _key = key;
        }

        string _db;
        string _tbl;
        string _key;

        protected EntityBase agentEB
        {
            get
            {
                return new EntityBase(_db, _tbl, _key);
            }
        }

        #endregion

        /// <summary>
        /// ���ouser�N�z�F���ǤH
        /// </summary>
        /// <param name="kind">���O</param>
        /// <param name="agentingID">�N�z�H</param>
        /// <returns></returns>
        public Dictionary<string,string> GetAgented(string kind, string agentingID)
        {
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "Today",DateTime.Today.ToString("yyyyMMdd")
                ,"Kind",kind
                ,"UserID",agentingID
            });
            DataSet ds = DBHelper.Instance.Query("Agent/GetAgented",args);
            if(ds!=null && ds.Tables.Count>0 && ds.Tables[0].Rows.Count>0){
                Dictionary<string, string> ret = new Dictionary<string, string>();
                foreach(DataRow dr in ds.Tables[0].Rows)
                {
                    string agentedUserId = dr["AgentedID"].ToString();
                    if (!ret.ContainsKey(agentedUserId))
                        ret.Add(agentedUserId, dr["Agented"].ToString());
                }
                return ret;
            }
            return null;
        }

        /// <summary>
        /// ���ouser�Q���ǤH�N�z�F
        /// </summary>
        /// <param name="kind">���O</param>
        /// <param name="userID">�Q�N�z�H</param>
        /// <returns></returns>
        public Dictionary<string, string> GetAgenting(string kind, string userID)
        {
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "Today",DateTime.Today.ToString("yyyyMMdd")
                ,"Kind",kind
                ,"UserID",userID
            });
            DataSet ds = DBHelper.Instance.Query("Agent/GetAgenting", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                Dictionary<string, string> ret = new Dictionary<string, string>();
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string agentedUserId = dr["AgentingID"].ToString();
                    if (!ret.ContainsKey(agentedUserId))
                        ret.Add(agentedUserId, dr["Agenting"].ToString());
                }
                return ret;
            }
            return null;
        }


        public bool IsAgent(string kind, string agentingID, string agentedID)
        {
            Dictionary<string,string> agents = GetAgented(kind,agentingID);
            return agents!=null && agents.ContainsKey(agentedID);
        }

        #region �N�z�]�w

        void checkAgentValid(Dictionary<string, object> agentArgs)
        {
            string agentedID = agentArgs["AgentedID"].ToString().Trim();
            if (agentedID == "0" || agentedID == "")
            {
                PCIBusException ex = new PCIBusException("�Q�N�z�H���ର��");
                ex.Data["ClientInfo"] = Tool.ToDic(new object[]{
                   "AgentedID","�Q�N�z�H���ର��" 
                });
                throw ex;
            }
            string agentingID = agentArgs["AgentingID"].ToString().Trim();
            if (agentingID == "0" || agentingID == "")
            {
                PCIBusException ex = new PCIBusException("�N�z�H���ର��");
                ex.Data["ClientInfo"] = Tool.ToDic(new object[]{
                   "AgentingID","�N�z�H���ର��" 
                });
                throw ex;
            }

            if(agentedID == agentingID)
            {
                PCIBusException ex = new PCIBusException("�N�z�H�M�Q�N�z�H����ۦP");
                ex.Data["ClientInfo"] = Tool.ToDic(new object[]{
                   "AgentedID","�N�z�H�M�Q�N�z�H����ۦP" 
                   ,"AgentingID","�N�z�H�M�Q�N�z�H����ۦP" 
                });
                throw ex;
            }

            string beginDate = agentArgs["BeginDate"].ToString().Trim();
            string endDate = agentArgs["EndDate"].ToString().Trim();
            if (beginDate == "")
            {
                beginDate = DateTime.Today.ToString("yyyyMMdd");
                agentArgs["BeginDate"] = beginDate;
            }
            if (endDate == "")
            {
                endDate = "99999999";
                agentArgs["EndDate"] = endDate;
            }
            if (beginDate.CompareTo(endDate) > 0)
            {
                PCIBusException ex = new PCIBusException("������������j�_�}�l���");
                ex.Data["ClientInfo"] = Tool.ToDic(new object[]{
                   "BeginDate","������������j�_�}�l���" 
                   ,"EndDate","������������j�_�}�l���" 
                });
                throw ex;
            }


            //�@�ӤH�N�z�t�@�ӤH�A�b�@�Ӥ�����A�u�঳�@�����(�Y��Ӥ�����୫�|)
            DataSet ds = DBHelper.Instance.Query("Agent/IsSet", agentArgs);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string agented = ds.Tables[0].Rows[0]["Agented"].ToString();
                string agenting = ds.Tables[0].Rows[0]["Agenting"].ToString();
                beginDate = ds.Tables[0].Rows[0]["BeginDate"].ToString();
                endDate = ds.Tables[0].Rows[0]["EndDate"].ToString();
                throw new PCIBusException("�w�g��" + agenting + "�N�z" + agented + "�]�w�b:" + beginDate + "~" + endDate + "������A������୫�|");
            }
        }

        /// <summary>
        /// �s�W�@�ӥN�z�]�w
        /// </summary>
        /// <param name="agentArgs">�ѼƳ��w�b�Ȥ�ݩT�w�A���ݭn�A�P�_�A�������`�Y�i</param>
        public void AddAgent(Dictionary<string, object> agentArgs)
        {
            checkAgentValid(agentArgs);
            EntityBase eb = agentEB.Init();
            eb.Data = agentArgs;
            eb.Insert();

        }

        /// <summary>
        /// �ק�N�z�]�w
        /// </summary>
        /// <param name="agentArgs">�ѼƳ��w�b�Ȥ�ݩT�w�A���ݭn�A�P�_�A�������`�Y�i</param>
        public void ModifyAgent(Dictionary<string, object> agentArgs)
        {
            checkAgentValid(agentArgs);
            EntityBase eb = agentEB.Init();
            eb.Data = agentArgs;
            eb.Update();
        }

        /// <summary>
        /// �����N�z�]�w
        /// </summary>
        /// <param name="agentID"></param>
        public void CancelAgent(string agentID)
        {
            EntityBase eb = agentEB.Init();
            eb["AgentID"] = agentID;
            eb.Delete();
        }

        #endregion
    }
}