using System;
using System.Collections.Generic;
using System.Data;

namespace PCIWeb.Tools
{

    /// <summary>
    /// �H���]�w
    /// </summary>
    public class NoticeSet
    {
        #region �c�ؾ��M��ƪ��]�w

        public NoticeSet()
            : this("Flow", "Base_MsgNotice", "NoticeID")
        {

        }

        public NoticeSet(string db, string tbl, string key)
        {
            _db = db;
            _tbl = tbl;
            _key = key;
        }

        string _db;
        string _tbl;
        string _key;

        protected EntityBase noticeEB
        {
            get
            {
                return new EntityBase(_db, _tbl, _key);
            }
        }


        #region �q���]�m

        public List<Dictionary<string, object>> Get()
        {
            EntityBase eb = noticeEB;
            eb.Init();
            eb["UserID"] = (int)decimal.Parse(AuthenticateHelper.Instance.UserID);
            return eb.Query();
        }

        public Dictionary<string, object> Get(string noticeKind)
        {
            EntityBase eb = noticeEB;
            eb.Init();
            eb["Kind"] = noticeKind;
            eb["UserID"] = (int)decimal.Parse(AuthenticateHelper.Instance.UserID);
            List<Dictionary<string, object>> sets = eb.Query();
            if (sets != null && sets.Count > 0)
                return sets[0];
            return null;
        }

        public void Set(string noticeKind,Dictionary<string, object> set)
        {
            set["Kind"] = noticeKind;
            set["UserID"] = (int)decimal.Parse(AuthenticateHelper.Instance.UserID);
            EntityBase eb = noticeEB;
            eb.Read(set);
            if (Get(noticeKind) == null)
                eb.Insert();
            else
            {
                eb.Update(new string[]{
                        "Kind"
                        ,"UserID"
                    }, new string[]{
                        "PccMessenger"
                        ,"Mail"
                        ,"SiteMsg"
                        ,"SMS"
                        ,"Lang"
                });
            }
        }

        #endregion

        #endregion

    }
}