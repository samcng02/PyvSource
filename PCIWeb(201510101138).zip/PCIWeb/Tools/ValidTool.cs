﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace PCIWeb.Tools
{
    public class ValidTool
    {

        #region 基礎驗證API

        //可驗證ArrayList是否為空
        public string Required(object input)
        {
            if (input == null)
                return "can not be empty";
            if (input is IList ? (input as IList).Count == 0 : input.ToString().Trim().Length == 0)
                return "can not be empty";
            return null;
        }

        public string MaxLength(object input, int maxLength)
        {
            if (Required(input) == null)
                return input.ToString().Length > maxLength ? maxLength + " characters maximumly allowed" : null;
            return null;
        }

        public string IsYear(object input)
        {
            return IsDateTime(input, "yyyy", "is not a valid year(e.g. 2014)");
        }

        public string IsMonth(object input)
        {
            return IsDateTime(input, "yyyyMM", "is not a valid year-month(e.g. 201409)");
        }

        public string IsDate(object input)
        {
            return IsDateTime(input, "yyyyMMdd", "is not a valid date(e.g. 20140906)");
        }

        //4碼小時分鐘，其它格式請使用IsDateTime傳入format參數
        public string IsTime(object input)
        {
            return IsDateTime(input, "HHmm", "is not a valid hour-minute(e.g. 1530)");
        }

        public string IsDateTime(object input, string format, string msg)
        {
            if (Required(input) == null)      //如果存在
            {
                DateTime tmp;
                if (!DateTime.TryParseExact(input.ToString().Trim(), format, null, System.Globalization.DateTimeStyles.None, out tmp))
                    return msg ?? "is not a valid date time" + "(" + format + ")";
            }
            return null;
        }

        public string IsBoolean(object input)
        {
            if (Required(input) == null)
                return input is bool ? null : "must be true or false";
            return null;
        }

        public string IsInteger(object input)
        {
            if (Required(input) == null)
            {
                string tmp = input.ToString();
                int outTmp;
                if (!int.TryParse(tmp, out outTmp))
                    return "is not an integer";
            }
            return null;
        }

        public string IsNumber(object input, int maxDecimalCount)
        {
            if (Required(input) == null)
            {
                string tmp = input.ToString();
                decimal outTmp;
                if (!decimal.TryParse(tmp, out outTmp))
                    return "is not a number";

                if (tmp.IndexOf('.') > 0 && tmp.Split(new char[] { '.' })[1].Length > maxDecimalCount)
                    return maxDecimalCount.ToString() + " decimal digits maximumly allowed";
            }
            return null;
        }

        public string Less(object input, object max)
        {
            return inRange(input, null, max, true, false);
        }

        public string LessEqual(object input, object max)
        {
            return inRange(input, null, max, true, true);
        }

        public string Greater(object input, object min)
        {
            return inRange(input, min, null, false, true);
        }

        public string GreaterEqual(object input, object min)
        {
            return inRange(input, min, null, true, true);
        }
        public string Between(object input, object min, object max)
        {
            return inRange(input, min, max, true,true);
        }


        public string Range(object input, object min, object max, bool equalMin, bool equalMax)
        {
            return inRange(input, min, max, equalMin, equalMax);
        }

        //可驗證字串（含日期，時間），也可驗證數字（含整數和小數）
        string inRange(object input, object min, object max, bool equalMin, bool equalMax)
        {
            if (Required(input) == null)
            {
                bool valid = true;
                if (input is string)
                {
                    string tmp = input.ToString().Trim();
                    //equalMin = equalMin ?? true;        //默認可以等于最小
                    //equalMax = equalMax ?? true;
                    if (min != null && tmp.CompareTo(min.ToString()) <= (!equalMin ? 0 : -1)
                        || max != null && tmp.CompareTo(max.ToString()) >= (!equalMax ? 0 : 1))
                        valid = false;
                }
                else
                {
                    string tmp = decimal.Parse(input.ToString()).ToString();
                    //equalMin = equalMin ?? true;        //默認可以等于最小
                    //equalMax = equalMax ?? true;
                    if (min != null && tmp.CompareTo(min.ToString()) <= (!equalMin ? 0 : -1)
                        || max != null && tmp.CompareTo(max.ToString()) >= (!equalMax ? 0 : 1))
                        valid = false;
                }
                if (!valid)
                    return input.ToString() +  " must" + (min != null ? " greater" + (equalMin ? "(equal)" : "") + " " + min.ToString() : "")
                        + (min != null && max != null ? " and" : "")
                        + (max != null ? " less" + (equalMax ? "(equal)" : "") + " " + max.ToString() : "");
            }
            return null;
        }

        public string InItems(object input, string items)
        {
            return InItemsSplitter(input, items, null);
        }

        public string InItemsSplitter(object input, string items, string splitter)
        {
            if (Required(input) == null)
                return Array.IndexOf(items.Split(new char[] { splitter != null ? splitter[0] : ',' }), input) >= 0 ? null : "must be an item of " + items;
            return null;
        }

        public string Unique(object input, string fieldsNo)
        {
            return UniqueSplitter(input, fieldsNo, null);
        }

        public string UniqueSplitter(object input, string fieldsNo, string splitter)
        {
            if (Required(input) == null)
            {
                List<string> keys = new List<string>();
                string[] fields = fieldsNo.Split(new char[] { ',' });
                splitter = splitter ?? ",";
                int index = 1;
                if (input is IList)
                {
                    IList listInput = input as IList;
                    foreach (Dictionary<string, object> item in listInput)
                    {
                        StringBuilder key = new StringBuilder();
                        foreach (string fieldNo in fields)
                            key.AppendFormat("{0}{1}", key.Length > 0 ? splitter : "", item[fieldNo].ToString().Trim());
                        if (keys.Contains(key.ToString()))
                            return "item " + index + " repeat(" + key.ToString() + ")";
                        keys.Add(key.ToString());
                        index++;
                    }
                }
                else
                    return "not a List";
            }
            return null;
        }

        #endregion

        //TODO:如果是兩個或多個欄位驗證，則將第一個參數改成ArrayList好了

        //nameOrError:如果末尾以!結尾，則表示是自定義的error message，否則就只是一個欄位名稱+預設的錯誤訊息
        public T Valid<T>(Dictionary<string, object> args, string fieldNo, string nameOrError, string rule, params object[] setting)
        {
            string errMsg = ValidField(args, fieldNo, rule, setting);
            if (errMsg != null)
                throw new PCIBusException((nameOrError.EndsWith("!") ? nameOrError : nameOrError + " " + errMsg + "!"));// + fieldNo);      //client可抓后面的|的欄位名稱
            return args.ContainsKey(fieldNo) ?(typeof(T) != args[fieldNo].GetType()? (T)Convert.ChangeType(args[fieldNo],typeof(T)):(T)args[fieldNo]) : default(T);
        }

        public void Valid(Dictionary<string, object> args, string fieldNo, string nameOrError, string rule, params object[] setting)
        {
            Valid<object>(args, fieldNo, nameOrError, rule, setting);
        }

        public IList Valid(Dictionary<string, object> args, string fieldNo, object[] itemRules)
        {
            IList items = args[fieldNo] as IList;
            return Valid(items, itemRules);
        }

        public IList Valid(IList items, object[] itemRules)
        {
            if (items != null)
            {
                int index = 1;
                foreach (Dictionary<string, object> item in items)
                {
                    foreach (object[] itemRule in itemRules)
                    {
                        string itemFieldNo = itemRule[0].ToString();
                        string nameOrError = index + ":" + itemRule[1].ToString();
                        string rule = itemRule[2].ToString();
                        object[] itemArgs = new object[itemRule.Length - 3];
                        itemRule.CopyTo(itemArgs, 3);
                        Valid(item, itemFieldNo, nameOrError, rule, itemArgs);
                    }
                    index++;
                }
            }
            return items;
        }

        public string ValidField(Dictionary<string, object> args, string fieldNo, string rule, object dicOrArray)
        {
            string[] rules = rule.Split(new char[] { ',' });
            int ruleIndex = 0;
            if (dicOrArray is object[])
                dicOrArray = new List<object>(dicOrArray as object[]);
            foreach (string subRule in rules)
            {
                string error;
                //if (ruleIndex == rules.Length - 1)       //最后一個可帶參數
                    error = validField(args, fieldNo, subRule, dicOrArray);
                //else
                //    error = validField(args, fieldNo, subRule, dicOrArray);
                if (error != null)
                    return error;
                ruleIndex++;
            }
            return null;
        }

        string validField(Dictionary<string, object> args, string fieldNo, string rule, object dicOrArray)
        {
            MethodInfo met = null;
            object validObject = null;
            if (rule.IndexOf(".") > 0)
            {
                int methodIndex = rule.LastIndexOf('.');
                validObject = ObjectFactory.Instance.Get(rule.Substring(0, methodIndex));
                if (validObject != null)
                    met = validObject.GetType().GetMethod(rule.Substring(methodIndex + 1));
            }
            else
            {
                met = this.GetType().GetMethod(rule);
                validObject = this;
            }
            if (met != null)
            {
                ParameterInfo[] ps = met.GetParameters();
                //第二個開始就是設定
                object[] validArgs = new object[ps.Length];
                validArgs[0] = args.ContainsKey(fieldNo) ? args[fieldNo] : null;
                if (dicOrArray != null)
                {
                    if (dicOrArray is Dictionary<string, object>)
                    {
                        Dictionary<string, object> settingArgs = dicOrArray as Dictionary<string, object>;
                        for (int i = 1; i < ps.Length; i++)
                        {
                            string pName = ps[i].Name;
                            validArgs[i] = settingArgs.ContainsKey(pName) ? settingArgs[pName] : null;
                        }
                    }
                    else if (dicOrArray is object[])
                    {
                        (dicOrArray as object[]).CopyTo(validArgs, 1);
                    }
                    else if (dicOrArray is List<object>)
                    {
                        List<object> givenArgs = dicOrArray as List<object>;
                        givenArgs.CopyTo(0, validArgs, 1, validArgs.Length - 1);
                        //多個rule的參數可以一起按順序傳
                        givenArgs.RemoveRange(0, validArgs.Length - 1);
                    }
                }
                //TODO:將參數動態調整.today,userid,other field等等

                try
                {
                    return (string)met.Invoke(validObject, validArgs);
                }
                catch (Exception ex)
                {
                    Tool.Error("Valid Function Error", "rule", rule, "validArgs", validArgs, "ex", ex);
                    throw new ApplicationException("Valid process exception:" + rule, ex);
                }
            }
            throw new ApplicationException("Valider can not be found:" + rule);
        }
    }
}
