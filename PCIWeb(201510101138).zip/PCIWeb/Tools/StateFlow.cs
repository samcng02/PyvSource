//RightsOwner:�y�{����Ҧ��A��ܮɤ���Ҧ��A�q���Ҧ�
using System;
using System.Collections.Generic;
using System.Data;
using System.Text.RegularExpressions;
using PCIWeb;

namespace PCIWeb.Tools
{

    public class StateFlow
    {
        class StateTran
        {
            public StateTran(string condtion, string newStatus)
            {
                Condition = condtion;
                NewStatus = newStatus;
            }

            public string Condition;
            public string NewStatus;
        }

        class replaceHelper
        {
            string _text;
            Dictionary<string, ConditonFunctionHandler> _conditionFunctions;

            public replaceHelper(string text,Dictionary<string, ConditonFunctionHandler> conditionFunctions)
            {
                _text = text;
                _conditionFunctions = conditionFunctions;
            }

            public string Calculate()
            {
                MatchEvaluator me = new MatchEvaluator(capFunction);
                //@HasRightsOwner(rightkind,{FlowUserID})       //���U�@��
                return Regex.Replace(_text, @"@.*?\)", me);   //start with @(, and end with )    
            }

            string capFunction(Match match)
            {
                string mStr = match.ToString();
                string functionText = mStr.Substring(1, mStr.Length - 1);        //-1,remove @
                string[] tmp = functionText.Trim().Split(new char[] { '(' });
                string name = tmp[0];
                if (tmp.Length == 2)
                {
                    string paramStr = tmp[1].Substring(0, tmp[1].Length - 1);   //-1,remove)
                    ConditonFunctionHandler fn = _conditionFunctions[name];
                    if(fn==null)
                        throw new ApplicationException("��������function:" + name);
                    string[] paramArgs = paramStr.Split(new char[] { ',' });
                    return fn(paramArgs);
                }
                else
                    throw new ApplicationException("Format is invalid:" + mStr);
            }
        }

        //���A�A�ʧ@�A�����Ǫ��y�����
        Dictionary<string, Dictionary<string, List<StateTran>>> stateMac;

        public Dictionary<string, List<string>> ActionStatus
        {
            get
            {
                Dictionary<string, List<string>> ret = new Dictionary<string, List<string>>();
                foreach (string status in stateMac.Keys)
                {
                    foreach (string action in stateMac[status].Keys)
                    {
                        if (!ret.ContainsKey(action))
                            ret.Add(action, new List<string>());
                        if (!ret[action].Contains(status))
                            ret[action].Add(status);
                    }
                }
                return ret;
            }
        }

        public Dictionary<string, List<string>> StatusAction
        {
            get
            {
                Dictionary<string, List<string>> ret = new Dictionary<string, List<string>>();
                foreach (string status in stateMac.Keys)
                {
                    string[] actions = new string[stateMac[status].Keys.Count];
                    stateMac[status].Keys.CopyTo(actions,0);
                    ret.Add(status, new List<string>(actions));
                }
                return ret;
            }
        }

        private Dictionary<string, Dictionary<string, List<StateTran>>> getStateMac(string flowNo)
        {
            Dictionary<string, Dictionary<string, List<StateTran>>> ret = new Dictionary<string, Dictionary<string, List<StateTran>>>();
            DataSet ds = DBHelper.Instance.Query("Flow/StateTran", Tool.ToDic(new object[]{
                "FlowNo",flowNo
            }));
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string status = dr["Status"].ToString();
                    if (!ret.ContainsKey(status))
                        ret.Add(status, new Dictionary<string, List<StateTran>>());

                    string action = dr["Action"].ToString();
                    if (!ret[status].ContainsKey(action))
                        ret[status].Add(action, new List<StateTran>());

                    string condition = dr["Condition"].ToString();
                    string newStatus = dr["NewStatus"].ToString();
                    StateTran tran = new StateTran(condition, newStatus);
                    ret[status][action].Add(tran);
                }
            }
            return ret;
        }

        public StateFlow(string flowNo)
            : this(flowNo, null)
        {

        }

        public StateFlow(string flowNo, Dictionary<string, ConditonFunctionHandler> fns)
        {
            stateMac = getStateMac(flowNo);
            if (fns == null)
                fns = new Dictionary<string, ConditonFunctionHandler>();
            _conditionFunctions = fns;
            addDefaultConditionFunctions();
        }

        public delegate string ConditonFunctionHandler(params string[] args);

        Dictionary<string, ConditonFunctionHandler> _conditionFunctions;

        void addDefaultConditionFunctions()
        {
            _conditionFunctions.Add("HasRightsOwner", HasRightsOwner);
            _conditionFunctions.Add("NextFlowUser", NextFlowUser);
        }

        string HasRightsOwner(params string[] args)
        {
            string rightKind = args[0];
            string rightData = args[1];
            List<string> rightOwerns = RightsProvider.Instance.RightsOwner(rightKind, rightData, true);
            return rightOwerns != null && rightOwerns.Count > 0 ? "1" : "0";
        }

        string NextFlowUser(params string[] args)
        {
            string ret = "";
            string[] flowUsers = args;
            string curUserID = flowUsers[flowUsers.Length - 1];     //�̦Z�@�ӬO���e��userID
            if (curUserID == "0.00")
            {
                ret = flowUsers[0];
            }
            else
            {
                int index = Array.IndexOf(flowUsers, curUserID);
                if (index >= 0 && index < flowUsers.Length - 2)
                {
                    ret = flowUsers[index + 1];
                }
                else
                {
                    ret = "-1";
                }
            }
            return "'" + ret + "'";
        }

        class CompStrLen : Comparer<string>
        {

            public override int Compare(string x, string y)
            {
                return x.Length > y.Length ? -1 : (x.Length == y.Length ? 0 : 1);
            }
        }

        string replaceText(string expression,Dictionary<string,object> args,string kindKey)
        {
            if (args != null)
            {
                //���r�Ŧ������u���i��ƧǡA�o�˴N���|�Q�N�~����
                //�p@f.ApplyUserID�o�˪���r�A�p�G�P�ɥX�{ApplyUser�MApplyUserID���A���\���ƧǡA�h�i��X��
                List<string> keys = new List<string>(args.Keys);
                keys.Sort(new CompStrLen());
                foreach (string key in keys)
                {
                    string repKey = "@" + (kindKey!=null && kindKey.Length>0?kindKey + ".":"") + key;
                    object repValue = args[key];
                    string realRepValue = "'" + (repValue ?? "") + "'";   //��@�n�[''�]
                    expression = expression.Replace(repKey, realRepValue);

                    string repKey2 = "#" + (kindKey != null && kindKey.Length > 0 ? kindKey + "." : "") + key;
                    string realRepValue2 = "" + (repValue ?? "") + "";      //��#���Υ[''
                    expression = expression.Replace(repKey2, realRepValue2);
                }
            }
            return expression;
        }

        public string CalculateExpression(string condition, Dictionary<string,object> firstArgs,Dictionary<string, object> form, Dictionary<string, object> args)
        {
            //@FlowUserID          //�y�{�H��ID
            //@f.���               //����form���
            //@a.���            //����args���
            //@HasRightsOwner(rightkind,@FlowUserID)       //���U�@��

            //@f.Build_No='H3'
            //@FlowUserID='78'
            //@HasRightsOwner(OddFlow,@FlowUserID)='1'

            try
            {
                //�Τ_����
                //if(condition=="@HasRightsOwner(OddFlow,@FlowUserID)='1'")
                //    condition = "@HasRightsOwner(OddFlow,#FlowUserID)='1'";

                Tool.Trace("���F��", "condition", condition);
                condition = replaceText(condition, firstArgs, "");

                //condition = condition.Replace("@FlowUserID", flowUserID);
                Tool.Trace("���F������1�Z", "condition", condition);
                condition = replaceText(condition, form, "f");
                Tool.Trace("���F������form�Z", "condition", condition);
                condition = replaceText(condition, args, "a");
                Tool.Trace("���F������args�Z", "condition", condition);
                replaceHelper rep = new replaceHelper(condition, _conditionFunctions);
                string expression = rep.Calculate();
                Tool.Trace("���F��������ƦZ", "expression", expression);
                DataTable dt = new DataTable();
                string result = dt.Compute(expression, null).ToString();
                Tool.Trace("���F���p�⵲�G��", "result", result);
                return result;
            }
            catch
            {
                Tool.Error("���F���p��X��", "condition", condition);
                throw;
            }
            /*
            Microsoft.JScript.Vsa.VsaEngine ve = Microsoft.JScript.Vsa.VsaEngine.CreateEngine();
            string result = Microsoft.JScript.Eval.JScriptEvaluate(expression, ve).ToString();
            return result == "true";
            */

        }

        bool calculateCondition(string condition,string action, string status, Dictionary<string, object> form, Dictionary<string, object> args,string flowUserID)
        {
            return CalculateExpression(condition, Tool.ToDic("FlowUserID", flowUserID, "Action", action, "Status", status), form, args) == "True";

        }

        public string NextStatus(string action, string status, Dictionary<string, object> form, Dictionary<string, object> args, string flowUserID)
        {
            //��F�A���ɭԫe�ݼg�o���������A���γ��o�\�j�����~��user
            if (!stateMac.ContainsKey(status))
                throw new PCIBusException("���A" + status  + "���w�q����ʧ@");
            if (!stateMac[status].ContainsKey(action))
            {
                //throw new PCIBusException("���A" + status + "�����\�ʧ@:" + action);
                throw new PCIBusException("����ڥi��w�Q�H�B�z�A�Ш�s����(someone has dealed this data,please refresh again)<br>�{�����H��:���A" + status + "�����\�ʧ@:" + action);
                //throw new ApplicationException("����v�����~(" + formNo + "," + flowUserID + "," + task + "," + action + ")");

            }
            List<StateTran> tranList = stateMac[status][action];
            string ret = null;
            if (tranList != null)
            {
                foreach (StateTran tran in tranList)
                {
                    if (tran.Condition == null || tran.Condition.Length == 0)
                    {
                        ret = tran.NewStatus;      //�o���i�H���ũΪ�null(���ܱҥ��ª��A)
                        break;
                    }
                    else
                    {
                        if (calculateCondition(tran.Condition, action, status, form, args, flowUserID))
                        {
                            ret = tran.NewStatus;
                            break;
                        }
                        else
                            continue;
                    }
                }
            }

            if (ret.IndexOf("@") >= 0 || ret.IndexOf("#") >= 0 || ret.IndexOf("(") >= 0)
            {
                ret = CalculateExpression(ret, Tool.ToDic("FlowUserID", flowUserID, "Action", action, "Status", status), form, args);
            }
            return ret;        //��^null�A�����ª��A
        }

    }
}