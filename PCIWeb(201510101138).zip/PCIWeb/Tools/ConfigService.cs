﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
namespace PCIWeb.Tools
{
    public class ConfigService
    {
        public ConfigService()
        {

        }

        public ConfigService(Dictionary<string, object> config)
        {
            foreach (string key in config.Keys)
            {
                FieldInfo field = this.GetType().GetField(key, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if(field!=null){
                    field.SetValue(this, Convert.ChangeType(config[key],field.FieldType));
                }
                else{
                    Tool.Warn("config field not found","name",key,"type",this.GetType().FullName);
                }
            }
        }
    }
}