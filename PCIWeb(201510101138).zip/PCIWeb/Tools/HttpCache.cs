﻿using System;
using System.IO;
using System.Web;
using System.Web.Caching;
using System.Collections;
using System.Collections.Generic;

namespace PCIWeb.Tools
{
    /// <summary>
    /// Cache對象提供
    /// </summary>
    public class HttpCache
    {
        public event CacheItemRemovedCallback OnCacheRemove;

        const string CACHEPREFIX = "HttpCache";
        
        public HttpCache()
            : this("Common")
        {

        }

        public HttpCache(string kind)
        {
            _kind = kind;
            _prefix = CACHEPREFIX + "." + kind + ".";
        }

        string _kind;
        string _prefix;

        Cache host
        {
            get
            {
                return HttpRuntime.Cache;
            }
        }

        public void Set(string key, object v)
        {
            this.Set(key, v, null);
        }

        object _lockObj = new object();     //不用static，是因為每個實例一個鎖定機制，因為他們的key不相同，所以一定不會碰到一起

        const string NULLCACHE = "HttpCache.NULLCACHE";

        public void Set(string key, object v, string depFile)
        {
            key = _prefix + key;
            string[] depPaths = null;
            if (depFile != null)
            {
                List<string> dirExistPaths = new List<string>();
                string[] paths = depFile.Split(new char[] { ';' });
                foreach (string path in paths)
                {
                    if (Directory.Exists(Path.GetDirectoryName(path)))
                        dirExistPaths.Add(path);
                }
                if (dirExistPaths.Count > 0)
                    depPaths = dirExistPaths.ToArray();
            }
            lock (_lockObj)
            {
                object cacheValue =  v ?? NULLCACHE;
                if (!contains(key) || host[key] != cacheValue)
                {
                    if (contains(key))
                        host.Remove(key);
                    host.Insert(key, cacheValue
                        , depPaths == null ? null : new System.Web.Caching.CacheDependency(depPaths)
                        , Cache.NoAbsoluteExpiration
                        //, key.EndsWith("PCIWeb.Rec.Job") ? new TimeSpan(0, 10, 0) : new TimeSpan(12, 0, 0)         //避免cache壓力大，1個小時後自動過期（如果不滿意，請使用Application等更牢固的方式存儲)
                        , new TimeSpan(12, 0, 0)         //避免cache壓力大，1個小時後自動過期（如果不滿意，請使用Application等更牢固的方式存儲)
                        , CacheItemPriority.Default
                        , this.reportRemovedCallback
                    );

                }
            }
        }

        /*
        Removed：移除原因为用Insert方添加项到缓存时指定键与移除项键相同或者用Remove方法移除缓存项。
        Expired：移除原因为缓存项过期。
        Underused：移除原因为系统需通过移除该项释放内存。
        DependencyChanged：移除原因为该缓存的依赖项发生改变。   
        */
        void reportRemovedCallback(String key, object value, CacheItemRemovedReason removedReason)
        {
            Tool.Info("Remove Cache", "key", key, "removedReason", removedReason);
            if (key.StartsWith(_prefix) && this.OnCacheRemove != null)
                this.OnCacheRemove(key.Substring(_prefix.Length), value, removedReason);
        }

        public bool Contains(string id)
        {
            string key = _prefix + id;
            return contains(key);
        }

        bool contains(string key)
        {
            return host[key] != null;
        }

        public T Get<T>(string key) where T:class
        {
            key = _prefix + key;
            object ret = null;
            lock (_lockObj)
            {
                ret = host[key];
            }
            if (ret==null || ret.ToString().Equals(NULLCACHE))
                return null;
            return (T)ret;
        }

        public void Clear()
        {
            this.clear(_prefix,1);
        }

        public void Clear(string key)
        {
            this.clear(_prefix + key,2);
        }

        void clear(string key,int kind)
        {
            List<string> keys = new List<string>();
            lock (_lockObj)
            {
                IDictionaryEnumerator CacheEnum = host.GetEnumerator();
                while (CacheEnum.MoveNext())
                {
                    string cacheKey = CacheEnum.Key.ToString();
                    if ((kind == 1 && cacheKey.StartsWith(key)) || (kind == 2 && cacheKey == key))
                        keys.Add(cacheKey);
                }
                foreach (string removeKey in keys)
                    host.Remove(removeKey);
            }
        }

        public string CacheKey(object o)
        {
            List<string> keys = new List<string>();
            lock (_lockObj)
            {
                IDictionaryEnumerator CacheEnum = host.GetEnumerator();
                while (CacheEnum.MoveNext())
                {
                    string cacheKey = CacheEnum.Key.ToString();
                    if (cacheKey.StartsWith(_prefix))
                        keys.Add(cacheKey);
                }
                foreach (string removeKey in keys)
                {
                    if (host[removeKey] == o)
                    {
                        return removeKey.Substring(_prefix.Length);
                    }
                }
            }
            return null;
        }
    }
}