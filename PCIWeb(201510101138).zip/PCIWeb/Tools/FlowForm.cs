///Code Auto Generate,Please do not modify here,use partial class or override instead
using System;
using System.Collections.Generic;
using System.Data;

namespace PCIWeb.Tools
{

    public abstract class FlowForm
    {
        public FlowForm()
        {
            //initParams();
        }

        //protected abstract void initParams();

        protected string Database = "";
        protected string Table = "";
        protected string FormTable = "";
        protected string KeyField = "";
        protected string StatusField = "";

        protected EntityBase formEB
        {       //����Table���]�w
            get
            {
                return new EntityBase(Database, FormTable, KeyField);
            }
        }
        protected EntityBase flowEB
        {
            //�y�{Table���]�w
            get
            {
                return new EntityBase(Database, Table, KeyField);
            }
        }

        #region �ª��y�{���A�ܤƳB�z

        protected Dictionary<string, object[]> _actions;

        public delegate string ConditionStatus(string formNo, string action, List<string> whereFields, List<object> values);

        protected virtual int validAction(string formno, string action)
        {
            string[] beforeStatus = _actions[action][0].ToString().Split(new char[] { ',' });
            string nowStatus = getStatus(formno);
            int ret = Array.IndexOf<string>(beforeStatus, nowStatus);
            if (ret < 0)
                throw new ApplicationException(action + " At" + formno + " is invalid(status:" + nowStatus + " allowedStatus:" + _actions[action][0].ToString() + ")");
            return ret;
        }

        protected string getStatus(string formNo)
        {
            EntityBase _flowEB = flowEB;

            return _flowEB.Read(new object[] { formNo })[StatusField].ToString();
        }

        protected virtual void setStatus(string formno, string action)
        {
            setStatusInner(formno, action, null, null);
        }

        protected virtual void setStatus(string formno, string action, string[] whereFields, object[] values)
        {
            setStatusInner(formno, action, new List<string>(whereFields), new List<object>(values));
        }

        protected virtual void onFlowStatusSet(string formNo, string newStatus, List<string> whereFields, List<object> values)
        {

        }

        protected virtual void afterFlowStatusSet(string formNo, string newStatus, List<string> whereFields, List<object> values)
        {

        }

        protected virtual void afterFlowStatusSet2(string formNo, string action, string status, string newStatus, List<string> whereFields, List<object> values)
        {

        }

        protected virtual void setStatusInner(string formno, string action, List<string> whereFields, List<object> values)
        {
            int index = validAction(formno, action);
            object status = _actions[action][1];
            string newstatus = null;
            if (status != null)
            {
                if (status is ConditionStatus)
                    newstatus = (status as ConditionStatus)(formno, action, whereFields, values);
                else
                    newstatus = status.ToString();
            }

            if (newstatus != null && newstatus.Trim().Length > 0
                || whereFields != null && values != null && whereFields.Count == values.Count)
            {
                EntityBase _flowEB = flowEB;

                _flowEB.Read(new object[] { formno });
                if (newstatus != null && newstatus.Trim().Length > 0)
                    _flowEB[StatusField] = newstatus;
                if (whereFields == null)
                    whereFields = new List<string>();
                if (values == null)
                    values = new List<object>();
                onFlowStatusSet(formno, newstatus, whereFields, values);
                if (whereFields != null && values != null && whereFields.Count == values.Count && whereFields.Count > 0)
                {
                    for (int i = 0; i < whereFields.Count; i++)
                        _flowEB[whereFields[i]] = values[i];
                }
                _flowEB.Update();
                afterFlowStatusSet(formno, newstatus, whereFields, values);
                afterFlowStatusSet2(formno, action, _actions[action][0].ToString(), newstatus, whereFields, values);
            }
        }

        #endregion

        #region �ηs�����A���ӧ����y��

        protected StateFlow _stateFlow;

        protected virtual void doAction(string formno, string action)
        {
            doAction(formno, action, null, null, null);
        }

        protected virtual void doAction(string formno, string action, string flowUserID, Dictionary<string, object> args, Dictionary<string, object> updateArgs)
        {
            string oldStatus;
            string newStatus;
            doAction(formno, action, flowUserID, args, updateArgs, out oldStatus, out newStatus);
        }

        protected virtual void doAction(string formno, string action, string flowUserID, Dictionary<string, object> args, Dictionary<string, object> updateArgs, out string oldStatus, out string newStatus)
        {
            if (flowUserID == null || flowUserID.Length == 0)
                flowUserID = AuthenticateHelper.Instance.UserID;
            if (updateArgs == null)
                updateArgs = new Dictionary<string, object>();

            Dictionary<string, object> form = Tool.ToDic(getFormByNo(formno));
            oldStatus = getStatus(formno);
            string realNewStatus = newStatus = _stateFlow.NextStatus(action, oldStatus, form, args, flowUserID);
            bool hasNewStatus = true;       //�O�_���s�����A
            if (realNewStatus == null || realNewStatus == "")
            {
                realNewStatus = oldStatus;
                newStatus = "";
                hasNewStatus = false;
            }
            beforeActionUpdate(form, oldStatus, realNewStatus, formno, action, flowUserID, args, updateArgs, hasNewStatus);
            EntityBase _flowEB = flowEB;
            bool doUpdate = false;
            if (updateArgs.Count > 0)
            {
                doUpdate = true;
                _flowEB.Read(updateArgs);
            }
            else
                _flowEB.Init();
            _flowEB[KeyField] = formno;
            if (oldStatus != realNewStatus)
            {
                doUpdate = true;
                _flowEB[StatusField] = realNewStatus;
            }
            if (doUpdate)
            {
                _flowEB.Update();
                form = Tool.ToDic(getFormByNo(formno));
                afterActionUpdate(form, oldStatus, realNewStatus, formno, action, flowUserID, args, updateArgs, hasNewStatus);
            }
        }

        protected virtual void beforeActionUpdate(Dictionary<string, object> form, string oldStatus, string newStatus
            , string formno, string action, string flowUserID, Dictionary<string, object> args
            , Dictionary<string, object> updateArgs, bool hasNewStatus)
        {

        }

        protected virtual void afterActionUpdate(Dictionary<string, object> form, string oldStatus, string newStatus
            , string formno, string action, string flowUserID, Dictionary<string, object> args
            , Dictionary<string, object> updateArgs, bool hasNewStatus)
        {

        }

        #endregion

        #region �Dtable,�y�{table���W�A�R�A���k

        protected virtual void onInsertFlow(EntityBase _flowEB)
        {

        }

        protected string _initStatus;

        protected virtual void insertFlow(string formNo)
        {
            EntityBase _flowEB = flowEB;

            _flowEB.Init();
            _flowEB[KeyField] = formNo;
            _flowEB[StatusField] = _initStatus;      //�p�G�O�D�ޡA�h�����T�{�F
            onInsertFlow(_flowEB);
            _flowEB.Insert();
        }

        protected string NoPrefix = "";

        protected string insertNoAddStep(Dictionary<string, object> args,string formNo)
        {
            //�n���n���ҧ������M�_�l���ʧ@
            //�p�s��Z�����ҡA�ҥHInsert��k���ѳ̰򥻪����J�ʧ@
            //ValidateHelper.Instance.Valid(args, _formEB.InsertCmd);
            EntityBase _formEB = formEB;

            _formEB.Read(args);
            _formEB[KeyField] = formNo;
            _formEB.Insert();

            insertFlow(formNo);
            return formNo;
        }

        protected string insertNoAddStep(Dictionary<string, object> args)
        {
            //�n���n���ҧ������M�_�l���ʧ@
            //�p�s��Z�����ҡA�ҥHInsert��k���ѳ̰򥻪����J�ʧ@
            //ValidateHelper.Instance.Valid(args, _formEB.InsertCmd);
            string formNo = IdGenerator.Instance.NextNo(NoPrefix, FormTable);
            insertNoAddStep(args, formNo);
            return formNo;
        }

        protected string insert(Dictionary<string, object> args, string memo, string actorID, string actorNm, string time)
        {
            string formNo = insertNoAddStep(args);
            /*
            if (actorID != null)
                addStep(formNo, "Insert", memo, actorID, actorNm, time);
            else
                addStep(formNo, "Insert", memo);
            */
            return formNo;
        }

        protected string insert(Dictionary<string, object> args, string memo)
        {
            return insert(args, memo, null, null, null);
        }

        //�ƾ��v���٭n���
        //�p�ק�O�H���A�R���O�H���A�e�f�O�H���A�T�{�O�H����
        //�e�T���ݧO���Τߤ��H�b�e�ݭק�js�Ҭ�(�]����Ƨ���ɤw�L�y)�A�i�q�L��ӥH��Step�O���o�{
        //��̫h�O�����v���ޱ���\��
        //�ӹ�ñ�֥\��A�h�O�ݭn�b���޿��k���W�[�v������A�]����b�����Ʈɤ]�O
        //�ݭn�ھڤ��P���Τ�ӧ���U�۪���Ʀ^�hñ��,�p�Gñ�O�H����]�O�O���Τߪ��A�q�L��Ӥ�Step�i�l��

        protected string updateNoAddStep(Dictionary<string, object> args)
        {
            //ValidateHelper.Instance.Valid(args, _formEB.UpdateCmd);
            string formNo = args[KeyField].ToString();
            //string status = getStatus(formNo);
            //���WaitForConfirm���A����ګh���κ�,�]���w�g�g�L�\���v���ޱ�
            //if ((status == "New" || status == "Back") && !isOwner(formNo))
            //    throw new ApplicationException("No Permission");
            //validAction(formNo, "Update");
            EntityBase _formEB = formEB;
            _formEB.Read(args);
            _formEB.Update();
            return formNo;
        }

        protected void update(Dictionary<string, object> args, string memo)
        {
            string formNo = updateNoAddStep(args);
            addStep(formNo, "Update", memo);
        }

        protected void deleteNoAddStep(string formNo)
        {
            EntityBase _flowEB = flowEB;

            //�ƾ��v�����
            //if (!isOwner(formNo))
            //    throw new ApplicationException("No Permission(only delete form yourself)");
            //validAction(formNo, "Delete");
            EntityBase _formEB = formEB;
            _formEB.Read(new object[] { formNo });
            _flowEB.Read(new object[] { formNo });
            _flowEB.Delete();
            _formEB.Delete();
        }

        protected void delete(string formNo, string memo)
        {
            deleteNoAddStep(formNo);
            addStep(formNo, "Delete", memo);
        }

        public void ManagerDelete(string formNo,string memo)
        {
            this.delete(formNo, "�޲z���R��:" + memo);
        }

        #endregion

        #region ���{WF_Step�W�A�R�A��A�d

        protected virtual string wfStepFormKind
        {
            get
            {
                return this.FormTable;
            }
        }

        protected string WFTable = "WF_Step";
        protected string WFKey = "StepID";
        protected string WFDataBase = "Flow";

        protected EntityBase wfEB
        {
            get
            {
                return new EntityBase(WFDataBase, WFTable, WFKey);
            }
        }

        protected void addStep(string formno, string action, string memo, string actorID, string actorNm, string time)
        {
            EntityBase _wfEB = wfEB;

            _wfEB.Init();
            _wfEB["FormKind"] = wfStepFormKind;
            _wfEB["FormNo"] = formno;
            _wfEB["Action"] = action;
            _wfEB["Memo"] = memo;
            _wfEB["ActTime"] = time;
            _wfEB["ActorID"] = actorID;
            _wfEB["Actor"] = actorNm;
            _wfEB.Insert();

        }

        protected void addStep(string formno, string action, string memo)//,string info)
        {
            string actorID = AuthenticateHelper.Instance.UserID;
            string actorNm = "";
            if (actorID != null)
                actorNm = AuthenticateHelper.Instance.User["Name"].ToString();

            addStep(formno, action, memo, actorID, actorNm, DateTime.Now.ToString("yyyyMMddHHmmss"));
        }

        protected List<Dictionary<string, object>> getSteps(string formno)
        {

            EntityBase _wfEB = wfEB;

            //�������{�H���Φ��v�����H���~���(�H��A�[)
            _wfEB.Init();
            _wfEB["FormKind"] = wfStepFormKind;
            _wfEB["FormNo"] = formno;
            return _wfEB.Query();
        }
        protected void addActionStep(string formno, string action)
        {
            addActionStep(formno, action, "");
        }

        protected void addActionStep(string formno, string action, string memo)
        {
            addActionStep(formno, action, memo, null);
        }

        protected void addActionStep(string formno, string action, string memo, string agentedID)
        {
            addActionStep(formno, action, memo, agentedID, "", "");
        }

        protected void addActionStep(string formno, string action, string memo, string agentedID, string oldStatus, string newStatus)
        {
            this.addActionStep(formno, action, memo, agentedID, oldStatus, newStatus, "");
        }

        protected void addActionStep(string formno, string action, string memo, string agentedID, string oldStatus, string newStatus,string info)
        {
            EntityBase _wfEB = wfEB;
            string actorID = AuthenticateHelper.Instance.UserID;
            string actorNm = "";
            if (agentedID == "0")
            {
                actorID = agentedID;
                actorNm = "[System]";
            }
            else if (actorID != null)
                actorNm = AuthenticateHelper.Instance.User["Name"].ToString();

            _wfEB.Init();
            _wfEB["FormKind"] = wfStepFormKind;
            _wfEB["FormNo"] = formno;
            _wfEB["Action"] = action;
            _wfEB["Memo"] = memo;
            _wfEB["ActTime"] = DateTime.Now.ToString("yyyyMMddHHmmss");
            _wfEB["Act_ActorID"] = actorID;
            _wfEB["Act_Actor"] = actorNm;
            _wfEB["OldStatus"] = oldStatus;
            _wfEB["NewStatus"] = newStatus;
            _wfEB["Info"] = info;
            //Info���ȥ��� kevin.zou 2011.9.20�`
            //�@�릳Memo�N�i�H�F�A�Y�i�H�O��������ܵ�user�ݪ��ƪ`�θ��
            //�]�i�O���䥦���H���A�q�Ljs�ഫ���Τ�i�ݪ��H���A�pPreMakeKind��ENG�h��ܤu�ȡAGA����`�ȵ�
            //Info�O���ݭn�O���ԲӪ��ܧ�L�{�A�i�����A�~�ݭn�O���U��
            if (agentedID != null && agentedID != actorID)
            {
                _wfEB["Act_Kind"] = "Agent";
                _wfEB["ActorID"] = agentedID;
                Dictionary<string, object> flowUserInfo = PCIWeb.AuthenticateHelper.Instance.GetUserInfo(agentedID);
                if (flowUserInfo != null)
                {
                    _wfEB["Actor"] = flowUserInfo["Name"].ToString();
                }
            }
            else
            {
                _wfEB["ActorID"] = actorID;
                _wfEB["Actor"] = actorNm;
            }
            insertWFStep(_wfEB);
            //_wfEB.Insert();
        }

        protected virtual void insertWFStep(EntityBase eb)
        {
            eb.Insert();
        }

        #endregion

        #region ��ڬd��

        protected Dictionary<string,object> getFlow(string formNo)
        {
            EntityBase _flowEB = flowEB;
            _flowEB.Read(formNo);
            return _flowEB.Data;
        }

        protected DataRow getFormByNo(string formNo)
        {
            Dictionary<string, object> args = new Dictionary<string, object>();
            args[KeyField] = formNo;
            Dictionary<string, object> forms = getForms(args, "", 0, 1);
            if (forms == null || forms["Count"].ToString() == "0")
                throw new ApplicationException("Data is null,formNo:" + formNo);
            return (forms["Rows"] as DataRowCollection)[0];
        }

        protected string refKeys = "";
        protected string refJoin = "";

        protected virtual Dictionary<string, object> getForms(Dictionary<string, object> args, string order, int pagesize, int page)
        {
            return getForms(args, order, pagesize, page, "");
        }

        protected string[] FlowFields;      //�y�{���

        protected virtual string querySql
        {
            get
            {
                return @"
                    SELECT *
                    FROM(
                        SELECT f.*,w.{0} {8}{9}{1}{2}
                        FROM {3} f 
                        JOIN {4} w ON f.{5} = w.{5}
                        {6}
                        WHERE 1=1
                        {7}
                    )tbl
                ";
            }
        }

        protected virtual string FlowFieldPrefix
        {
            get
            {
                return "Flow_";
            }
        }

        protected virtual Dictionary<string, object> getForms(Dictionary<string, object> args, string order, int pagesize, int page, string addWhere)
        {
            string flowFields = "";
            if (FlowFields != null && FlowFields.Length > 0)
            {
                foreach (string field in FlowFields)
                    flowFields += ",w." + field + " " + FlowFieldPrefix + field;
            }
            string cmd = "Select_" + FormTable + "," + Table + "@" + Database;
            string sql = string.Format(querySql
                , StatusField
                , flowFields
                , refKeys
                , FormTable
                , Table
                , KeyField
                , refJoin
                , addWhere
                , FlowFieldPrefix
                , StatusField
            );

            args["@CUSTOMSQL"] = sql;
            int count;
            DataSet ds = DBHelper.Instance.QueryPage(cmd, args, order + "," + KeyField + " desc", pagesize, page, out count);
            return Tool.ToDic(new object[]{
                "Count",count
                ,"Rows",ds!=null && ds.Tables.Count>0?ds.Tables[0].Rows:null
            });
        }

        public DataRowCollection GetStatusCount()
        {
            string cmd = "Select_" + Table + ",STATUS_COUNT@" + Database;
            string sql = string.Format(@"Select {0},count(*) STATUS_COUNT from {1} group by {0}"
                , StatusField
                , Table
            );
            DataSet ds = DBHelper.Instance.Query(cmd, Tool.ToDic(
                "@CUSTOMSQL",sql
                ));
            if (ds != null && ds.Tables.Count > 0)
            {
                return ds.Tables[0].Rows;
            }
            return null;
        }

        protected virtual string ApplyUserIDField
        {
            get
            {
                return "ApplyUserID";
            }
        }

        //���o�ڼg������(�q�{�D�ɦ��@��ApplyUserID���,���ּܽg��)
        public virtual Dictionary<string, object> GetMyForm(Dictionary<string, object> args, string order, int pagesize, int page)
        {
            args[ApplyUserIDField] = AuthenticateHelper.Instance.UserID;
            return getForms(args, order, pagesize, page);
        }

        protected string dealActions = "";

        //���o�ڳB�z�L������(�q�{��dealActions�H�ΩMWF_Step�@�Ӹ�Ʈw)
        public virtual Dictionary<string, object> GetMyDealForm(Dictionary<string, object> args, string order, int pagesize, int page)
        {
            string userID = AuthenticateHelper.Instance.UserID;
            string actions = this.dealActions;
            if (args.ContainsKey("DealStatus"))
            {
                actions = args["DealStatus"].ToString();
                args.Remove("DealStatus");
            }
            if (actions != null && actions.Length > 0)
            {
                string addwhere = string.Format(@" AND exists(
                SELECT * from {4} WF_Step with(nolock)
                where WF_Step.FormNo = f.{3} 
                and WF_Step.FormKind='{0}'
                and (WF_Step.ActorID ='{1}' or WF_Step.Act_ActorID='{1}')
                and WF_Step.Action in('{2}')
            )", wfStepFormKind
                  , userID
                  , actions.Replace(",", "','")
                  , KeyField
                  , WFTable
                  );
                return getForms(args, order, pagesize, page, addwhere);
            }
            return null;
        }

        #endregion

    }

}
