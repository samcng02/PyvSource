﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Data;
using PCIWeb.Tools;

namespace PCIWeb
{

    public class Context
    {
        public static readonly ValidTool ValidTool = new ValidTool();
        public static readonly UploadTool UploadTool = new UploadTool();
        public static readonly DBHelper DBTool = new DBHelper();
    }

    /*

    /// <summary>
    /// 程式人員統一訪問入口點
    /// </summary>
    public class Context
    {
        public static string UserID
        {
            get
            {
                return AuthenticateHelper.Instance.UserID;      //暫時這樣，更好的模式是new AuthenticateHelper()，這樣可以在AuthenticateHelper類中少一個Instance變量的定義
            }
        }

        public static Dictionary<string,object> User
        {
            get
            {
                return AuthenticateHelper.Instance.User;
            }
        }

        public static string AppID
        {
            get
            {
                return "";
            }
        }

        public static T Request<T>(string key)
        {
            return default(T);
        }

        public static FileConfig Config
        {
            get
            {
                return null;
            }
        }

        #region Config捷徑方法

        public static T Parse<T>(string file, string key)
        {
            return default(T);
        }

        #endregion

        public static DBHelper DBHelper
        {
            get
            {
                return DBHelper.Instance;
            }
        }

        #region DB操作捷徑方法

        public static void Execute(string cmd, Dictionary<string, object> args)
        {

        }

        public static Dictionary<string, object> QueryPage(string cmd, Dictionary<string, object> args)
        {
            return null;
        }

        public static DataRowCollection QueryRows(string cmd, Dictionary<string, object> args)
        {
            return null;
        }

        public static DataRow QueryRow(string cmd, Dictionary<string, object> args)
        {
            return null;
        }

        public static T Query<T>(string cmd, Dictionary<string, object> args)
        {
            return default(T);
        }

        #endregion

        public static ObjectFactory Factory
        {
            get
            {
                return ObjectFactory.Instance;
            }
        }

        #region Object工廠捷徑方法

        public static object Get(string objId)
        {
            return null;
        }

        public static T Get<T>()
        {
            return default(T);
        }

        public static T Get<T>(string objId)
        {
            return default(T);
        }

        #endregion

        public static LogHelper Log
        {
            get
            {
                return LogHelper.Instance;
            }
        }

        #region Log捷徑方法

        public static void Trace(string msg, params object[] args)
        {
            Log.Trace(msg, args);
        }

        public static void Info(string msg, params object[] args)
        {
            Log.Info(msg, args);
        }

        public static void Warn(string msg, params object[] args)
        {
            Log.Warn(msg, args);
        }

        public static void Error(string msg, params object[] args)
        {
            Log.Error(msg, args);
        }

        #endregion

        #region 通用cache

        public void Cache(string kind, string key, object o, string[] filePaths)
        {

        }

        public void Cache(string kind, string key, object o, string filePaths)
        {

        }

        public void Cache(string kind, string key, object o)
        {

        }

        public T Cache<T>(string kind,string key)
        {
            return default(T);
        }

        #endregion

        //權限管控
    }

    */

    /*
    public class DBUtil
    {
        //直接在開發的時候就分好了，哪些table放在一個db里面
        //還是可后期動態變化?涉及到事務處理和join查詢

        //tbl格式：WF_Step@Flow        //資料庫和table名都是hardcode在代碼中的，后期可動態配置和替換
        public virtual void Insert(string db, string table, Dictionary<string, object> args)
        {
            DBHelper.Instance.Execute("Insert_" + table + "@" + db, args);
        }

        public virtual void Update(string db, string table, Dictionary<string, object> argsWhere)
        {
            DBHelper.Instance.Execute("Update_" + table + "@" + db, argsWhere);       //where條件以__W代替
        }

        public virtual void Delete(string db, string table, Dictionary<string, object> where)
        {
            DBHelper.Instance.Execute("Delete_" + table + "@" + db, where);
        }

        public virtual void Select(string db, string table, Dictionary<string, object> where)
        {

        }
    }

    public class DyDBUtil : DBUtil
    {
        public override void Insert(string db, string table, Dictionary<string, object> args)
        {
            ObjectFactory.Instance.Get<DBUtil>(table).Insert(db, table, args);
        }
        public override void Update(string db, string table, Dictionary<string, object> args)
        {
            ObjectFactory.Instance.Get<DBUtil>(table).Update(db, table, args);
        }
        public override void Delete(string db, string table, Dictionary<string, object> args)
        {
            ObjectFactory.Instance.Get<DBUtil>(table).Delete(db, table, args);
        }
        public override void Select(string db, string table, Dictionary<string, object> args)
        {
            ObjectFactory.Instance.Get<DBUtil>(table).Select(db, table, args);
        }
    }

    public class PrefixTable : DBUtil
    {
        string prefix;
        public PrefixTable(string prefix)
        {
            this.prefix = prefix;
        }

        public override void Insert(string db, string table, Dictionary<string, object> args)
        {
            table = this.prefix + table;
            base.Insert(db, table, args);
        }

        public override void Update(string db, string table, Dictionary<string, object> args)
        {
            table = this.prefix + table;
            base.Insert(db, table, args);
        }

        public override void Delete(string db, string table, Dictionary<string, object> args)
        {
            table = this.prefix + table;
            base.Insert(db, table, args);
        }

        public override void Select(string db, string table, Dictionary<string, object> args)
        {
            table = this.prefix + table;
            base.Insert(db, table, args);
        }
    }

    public class CombineDBUtil : DBUtil
    {
        Dictionary<string, object> fields;
        public CombineDBUtil(string field,string value)
            : this(Tool.ToDic(field,value))
        {

        }

        public CombineDBUtil(Dictionary<string, object> fields)
        {
            this.fields = fields;
        }

        public override void Insert(string db, string table, Dictionary<string, object> args)
        {
            foreach (string key in fields.Keys)
                args[key] = fields[key];
            base.Insert(db, table, args);
        }

        public override void Update(string db, string table, Dictionary<string, object> args)
        {
            foreach (string key in fields.Keys)
                args[key + "__W"] = fields[key];
            base.Insert(db, table, args);
        }

        public override void Delete(string db, string table, Dictionary<string, object> args)
        {
            foreach (string key in fields.Keys)
                args[key] = fields[key];
            base.Insert(db, table, args);
        }

        public override void Select(string db, string table, Dictionary<string, object> args)
        {
            foreach (string key in fields.Keys)
                args[key] = fields[key];
            base.Insert(db, table, args);
        }
    }

    //水平分割table
    public class UnionTable : DBUtil
    {
        ArrayList fields;
        public UnionTable(string field,int valueLength,bool targetExist)        //>=0才會截取前幾碼
        {
            fields = new ArrayList();
            fields.Add(new ArrayList(new object[] { field, valueLength, targetExist }));
        }

        public UnionTable(ArrayList fields)
        {
            this.fields = fields;
        }

        string getTargetTable(string table, Dictionary<string, object> args)
        {
            string targetTableSuffix = "";
            foreach (ArrayList fieldSetting in fields)
            {
                string field = fieldSetting[0].ToString();
                string fieldValue = args[field].ToString();
                int valueLength = (int)fieldSetting[1];
                if(valueLength>0)
                    fieldValue = fieldValue.Substring(0,valueLength);
                targetTableSuffix += "_" + fieldValue;          //寫死用_下劃線連接
                bool targetExists = (bool)fieldSetting[2];
                if (!targetExists)
                    args.Remove(field);
            }
            return table + targetTableSuffix;
        }

        public override void Insert(string db, string table, Dictionary<string, object> args)
        {
            table = getTargetTable(table, args);
            //TODO:table不存在，可以用job每天新增，還是這里自動創建新增?
            base.Insert(db, table, args);
        }

        //update好像有些問題，要select出來的條件在哪里才進行update?或全部update?只有單筆update才靠譜？或者只有帶上分區條件才行
        //明細table呢？
        public override void Update(string db, string table, Dictionary<string, object> args)
        {
            table = getTargetTable(table, args);
            base.Update(db, table, args);
        }

        public override void Delete(string db, string table, Dictionary<string, object> args)
        {
            table = getTargetTable(table, args);
            base.Delete(db, table, args);
        }
    }

    //垂直分割table
    public class JoinTable : DBUtil
    {

    }

    */

    /*
    public enum RelationKind
    {
        One2One     //1對1關聯(key在這里，關聯到另一個table,且
        ,One2Many   //1對多關聯
        
        ,Detail
        ,Ref
    }

    public class Relation
    {

    }

    public class EntityRelation
    {
        public string Name;             //relation的名字
        public string KeyName;             //主table所在欄位
        public string[] KeyFields;
        public string RefName;
        public string[] RefFields;      //可以逗號分隔，如果為空，則就是refName的主key欄位
        public string Conditions;    //條件關聯(可選),trim,uppercase等關聯
    }

    public class EntitySet
    {
        //table是下一層存儲的table名(可能是虛擬的，如果有變化的話)
        //每一個table的設定都放到參數下，然後進行table的真正物理db存儲設定
        //Detail:"@ref=OT_Detail"       //@ref=開頭表示是關聯欄位
        //每一個field，有名稱（中英文多版本），是否關聯欄位
        //驗證以后再說？
        //自動加1的key?
        //存儲方式?
        
        public EntitySet(ArrayList fields)
        {

        }

    }

    public class Repository
    {
        public Repository()
        {

        }

        //table,db,fields可設定
        public Repository(string database, Dictionary<string, object> fields)
        {
            this.database = database;
            this.fields = fields;
        }
        string database;
        string table;
        Dictionary<string, object> fields;

        //默認entityName是這樣的格式 table@db，實際存儲人員可替換
        //如果有設定，則table和db名稱從設定
        //insert or udpate
        //entity可以統一增加時間戳，以統一處理并發性

        //entity的配置不會關注每一個欄位，只有在實體table存儲時，可能指定不要存儲某些欄位吧

        //groupby,sort,distinct,page,filter,treeLevel==group?group多個欄位吧?

        //entityName直接到db端存儲的時候就是這樣子,insert(entityName)
        //entityID:table名,db在EntityDBStore中有設定好了，直接用就好了。所以一個db所有entity可以放在一起
        //一個Repository中的name要唯一
        //直接就是entity要怎么存?entity默認就是物理table，要怎么存再封裝一層
        public void Save(string entityName,Dictionary<string, object> entity)
        {
            //讀取EntitySet
            //根據entity的設定，新增明細，添加主key，去除相關的外鍵table的name欄位，事務處理，驗證實體？
            //根據不同的參數，驗證不同的值就好了，這樣可以增加entity的設定屬性

            //entity中的field名稱，需要與fields中對應嗎?存儲時不需要吧，欄位不存儲啊
            //實際table的設定
        }

        //不指定db
        public void Insert(string db,string tbl,Dictionary<string,object> fields)
        {
            db = this.database ?? db;

        }

        public void Update()
        {

        }

        public void UpdateByFields(Dictionary<string, object> args)
        {

        }

        public void Delete(string key)
        {

        }

        public void Delete(string key, object value)
        {

        }

        public DataRow Find(string key,string extEntity)
        {
            return null;
        }

        public DataRowCollection Find(string field, object value)
        {
            return null;
        }

        public DataRowCollection Query(Dictionary<string,object> args)
        {
            return null;
        }

    }

    //上層調用代碼示例:ObjectFactory.Get<DBStore>.Insert("","",args);
    public class DBStore
    {
        public virtual void Insert(string db, string table, Dictionary<string, object> args)
        {
            DBHelper.Instance.Execute("Insert_" + table + "@" + db, args);
        }

        public virtual void Update(string db, string table, Dictionary<string, object> argsWhere)
        {
            DBHelper.Instance.Execute("Update_" + table + "@" + db, argsWhere);       //where條件以__W代替
        }

        public virtual void Delete(string db, string table, Dictionary<string, object> where)
        {
            DBHelper.Instance.Execute("Delete_" + table + "@" + db, where);
        }

        //querySets:設定page,order,group,distinct等
        public virtual DataRowCollection Select(string database, string table, Dictionary<string, object> args, Dictionary<string, object> querySetting)
        {
            return null;
        }

        //order by 
        //group
        //join
        //page
        //distinct等
        //面向實體table存儲
    }

    public class FactoryDBStore : DBStore
    {

        public override void Insert(string db, string table, Dictionary<string, object> args)
        {
            ObjectFactory.Instance.Get<DBStore>(table +"@" + db).Insert(db, table, args);
        }
        public override void Update(string db, string table, Dictionary<string, object> args)
        {
            ObjectFactory.Instance.Get<DBStore>(table +"@" + db).Update(db, table, args);
        }
        public override void Delete(string db, string table, Dictionary<string, object> args)
        {
            ObjectFactory.Instance.Get<DBStore>(table +"@" + db).Delete(db, table, args);
        }
        public override DataRowCollection Select(string db, string table, Dictionary<string, object> args,Dictionary<string,object> querySetting)
        {
            return ObjectFactory.Instance.Get<DBStore>(table +"@" + db).Select(db, table, args,querySetting);
        }
    }

    public class CombineTable : DBStore
    {

        Dictionary<string, object> fields;
        public CombineTable(string field,string value)
            : this(Tool.ToDic(field,value))
        {

        }

        public CombineTable(Dictionary<string, object> fields)
        {
            this.fields = fields;
        }

        public override void Insert(string database, string table, Dictionary<string, object> args)
        {
            foreach (string key in fields.Keys)
                args[key] = fields[key];
            base.Insert(database, table, args);
        }
    }

    public enum BaseConfigFileKind
    {
        String
        , Binary
    }

    //基本的config策略
    //模板：config接口key值(基本是path)，key可變，key->path(s)，緩存
    public class BaseConfig
    {
        string configFolder;
        BaseConfigFileKind fileKind;        //0:文本,1:二進制

        public BaseConfig()
            //默認config搜尋位置
            : this(System.AppDomain.CurrentDomain.BaseDirectory + "App_Data\\Config\\")
        {

        }

        public BaseConfig(string folder)
            :this(folder,BaseConfigFileKind.String)
        {
        }

        public BaseConfig(string folder, BaseConfigFileKind kind)
        {
            configFolder = folder;
            this.fileKind = kind;
        }

        //key的轉換，如依當前的request，決定key是否加.pgd等
        //因為緩存需要唯一key
        //其實就是決定使用哪個config對象（一個系統中可同時存在多個config對象，但對外是相同的，只是內部有區別）
        protected virtual string getKey(string key)
        {
            //有時候直接key + ".pgd"或轉掉就好
            //可能分兩種情況，有時候直接就是強制加.pgd，如果找不到，則config為null
            //有時候設定config為先找是否存在.pgd文件，如果沒有，則還是找默認的config，這時候的key值也需要if來決定
            //但是緩存可能就需要設定為兩個路徑
            return key;
        }

        protected virtual string[] getPaths(string key)
        {
            key = key.Replace(".", "\\");     //和舊的兼容，也可以直接用路徑(斜杠)
            return new string[] { configFolder + key };
        }

        //不緩存
        public string read(string key)
        {
            //搜尋
            key = key.Replace(".", "\\");     //和舊的兼容，也可以直接用路徑(斜杠)
            return null;
        }

        public byte[] readBytes(string key)
        {
            return null;
        }

        //file文件內容本身不需要緩存，因為內容最終都會轉換成對象緩存
        //只是需要路徑作為緩存的key
        //如ObjectFactory也是同樣的道理
        public object parseObject(string key)
        {
            return null;
        }
    }
    */
}