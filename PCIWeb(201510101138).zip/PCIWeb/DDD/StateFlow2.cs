//RightsOwner:�y�{����Ҧ��A��ܮɤ���Ҧ��A�q���Ҧ�
using System;
using System.Collections.Generic;
using System.Data;
using System.Text.RegularExpressions;
//using System.Linq;
using PCIWeb;
using PCIWeb.Tools;

namespace PCIWeb.DDD
{
    public class StateFlow2
    {
        public class Action
        {
            public string Name;
            //Other Info�A�@�γ]�w�A�p�h�f���n��J��]

            public bool AddStep;
            public string StepField;
        }

        public class Status
        {
            public string Name;
            public string SubStatusExp;         //�l���A����l�ƪ��F��

            public List<Action> Actions;

            public class Action
            {
                public string Name;             //�۷��_ActionID
                public string Condition;        //�O�_�i�H�i��o�Ӱʧ@������
                public List<Transition> Transitions;
                public class Transition
                {
                    public int Seq;
                    public string Condition;
                    public string NewStatus;
                }
            }

        }

        List<Status> statusList;
        List<Action> actionList;
        string flowNo;

        public string FlowNo
        {
            get
            {
                return flowNo;
            }
        }

        public List<Status> StatusList
        {
            get
            {
                return statusList;
            }
        }

        public string SubStatus(string statusName, Dictionary<string, object> form, Dictionary<string, object> args)
        {
            return null;/*
            Status status = this.statusList.First(i => i.Name == statusName);
            if (status.SubStatusExp != null && status.SubStatusExp.Length > 0)
            {
                ExpressionHelper expHelper = ObjectFactory.Instance.Get<ExpressionHelper>();
                return expHelper.CalculateExpression(status.SubStatusExp, form, args);
            }
            return null;*/
        }

        public string NextStatus(string statusName, string actionName, Dictionary<string, object> form, Dictionary<string, object> args)
        {
            return null;
            /*
            Status status = this.statusList.First(i => i.Name == statusName);
            if (status == null)
                throw new PCIBusException("STATUS_NOT_EXIST_" + statusName);
            Status.Action action = status.Actions.First(i => i.Name == actionName);
            if(action == null)
                throw new PCIBusException("ACTION_NOT_EXIST_" + actionName);
            ExpressionHelper expHelper = ObjectFactory.Instance.Get<ExpressionHelper>();
            if (action.Condition != null && action.Condition.Length > 0)
            {
                if (expHelper.CalculateExpression(action.Condition, form, args) != "True")
                    throw new PCIBusException("ACTION_CONDITION_NOT_MATCH_" + actionName);
            }

            List<Status.Action.Transition> tranList = action.Transitions;// this.StatusList.OrderBy(t => t.Seq).Where(t => t.Status == status && t.Action == action).ToList();
            if (tranList != null)
            {
                foreach (Status.Action.Transition tran in tranList)
                {
                    if (tran.Condition == null || tran.Condition.Length == 0)
                        return tran.NewStatus;      //�o���i�H���ũΪ�null(���ܱҥ��ª��A)
                    else
                    {
                        if (expHelper.CalculateExpression(tran.Condition, form, args) == "True")
                            return tran.NewStatus;
                        else
                            continue;
                    }
                }
            }
            return null;        //��^null�A�����ª��A*/
        }
    }
}