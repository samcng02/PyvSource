﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data;
using System.Data.Common;
using System.Reflection;
using System.Runtime.Serialization;
using System.Web;
using PCIWeb;
using PCIWeb.Tools;

namespace PCIWeb
{
    public class ContextTool
    {
        public static T Get<T>(Dictionary<string, object> args, string key)
        {
            return Get<T>(args, key, default(T));
        }

        public static T Get<T>(Dictionary<string, object> args, string key, T def)
        {
            if (args.ContainsKey(key))
            {
                T ret = (T)Convert.ChangeType(args[key], typeof(T));// (T)args[key];
                //args.Remove(key);
                return ret;
            }
            return def;
        }

        public string GetJsonString(object o)
        {
            return Tool.ToJson(o);
        }
    }

}
