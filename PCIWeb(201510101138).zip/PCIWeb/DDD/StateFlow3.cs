//RightsOwner:�y�{����Ҧ��A��ܮɤ���Ҧ��A�q���Ҧ�
using System;
using System.Collections.Generic;
using System.Data;
using System.Text.RegularExpressions;
//using System.Linq;
using PCIWeb;
using PCIWeb.Tools;

namespace PCIWeb.DDD
{
    public class StateFlow3
    {
        public class Action
        {
            public string Name;
            //Other Info�A�@�γ]�w�A�p�h�f���n��J��]

            public bool AddStep;
            public string StepField;
        }

        public class Status
        {
            public string Name;
            public string SubStatusExp;
        }

        public class Transition
        {
            public string Status;
            public string Action;
            public string ActionCondition;
            public int Seq;
            public string Condition;
            public string NewStatus;
        }

        List<Status> statusList;
        List<Action> actionList;
        List<Transition> transitions;
        string flowNo;

        public string FlowNo
        {
            get
            {
                return flowNo;
            }
        }

        public List<Transition> Transitions
        {
            get
            {
                return transitions;
            }
        }

        public string SubStatus(string statusName, Dictionary<string, object> form, Dictionary<string, object> args)
        {
            return null;/*
            Status status = this.statusList.First(i => i.Name == statusName);
            if (status.SubStatusExp != null && status.SubStatusExp.Length > 0)
            {
                ExpressionHelper expHelper = ObjectFactory.Instance.Get<ExpressionHelper>();
                return expHelper.CalculateExpression(status.SubStatusExp, form, args);
            }
            return null;*/
        }

        public string NextStatus(string statusName, string actionName, Dictionary<string, object> form, Dictionary<string, object> args)
        {
            return null;/*
            List<Transition> transitions = this.transitions.Where(i => i.Status == statusName && i.Action == actionName).OrderBy(i => i.Seq).ToList();
            if (transitions.Count ==0)
                throw new PCIBusException("STATUS_ACTION_NOT_EXIST:" + statusName + "," + actionName);
            //action����i�H�K�g�b����
            //�n��������
            ExpressionHelper expHelper = ObjectFactory.Instance.Get<ExpressionHelper>();
            foreach (Transition tran in transitions)
            {
                if (tran.Condition != null && tran.Condition.Length > 0)
                {
                    if (expHelper.CalculateExpression(tran.Condition, form, args) != "True")
                        throw new PCIBusException("ACTION_CONDITION_NOT_MATCH_" + actionName);
                }
            }

            foreach (Transition tran in transitions)
            {
                if (tran.Condition == null || tran.Condition.Length == 0)
                    return tran.NewStatus;      //�o���i�H���ũΪ�null(���ܱҥ��ª��A)
                else
                {
                    if (expHelper.CalculateExpression(tran.Condition, form, args) == "True")
                        return tran.NewStatus;
                    else
                        continue;
                }
            }

            return null;        //��^null�A�����ª��A*/
        }
    }
}