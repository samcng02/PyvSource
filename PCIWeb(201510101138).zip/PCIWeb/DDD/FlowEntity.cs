﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Text;
//using System.Linq;
using System.Reflection;
using PCIWeb;
using PCIWeb.Tools;

namespace PCIWeb.DDD
{
    public abstract class FlowEntity : Entity
    {

        public FlowEntity(string id)
            : base(id)
        {
            status = "New";
            steps = new List<Step>();
            dynamicInfo = new Dictionary<string, object>();
        }

        protected abstract string flowNo { get; }

        string status;

        public string Status
        {
            get
            {
                return status;
            }
        }

        string subStatus;

        public string SubStatus
        {
            get
            {
                return subStatus;
            }
        }

        //流程中要用到的變數必須從這里提供
        public virtual Dictionary<string, object> FlowInfo
        {
            get
            {
                Dictionary<string,object> ret = new Dictionary<string,object>();
                FieldInfo[] fields = this.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                foreach (FieldInfo field in fields)
                    ret[field.Name] = field.GetValue(this);
                return ret;
            }
        }

        //string statusTimeStamp;               //17碼的時間戳？還是版本號好了
        int instanceVersion;                    //某些動作可能不改變version，例如修改動作

        public int InstanceVersion
        {
            get
            {
                return instanceVersion;
            }
        }

        //任務驗證等放到哪去呢?
        public virtual void ToStatus(string status, string subStatus)
        {
            this.status = status;
            this.subStatus = subStatus;
            this.instanceVersion++;
        }

        Dictionary<string, object> dynamicInfo;

        //提供一個與核心業務邏輯無關的flow變量群，用于設定某些非核心數據(流程相關)
        public virtual void SetDynamicInfo(Dictionary<string, object> args)
        {
            foreach (string key in args.Keys)
                dynamicInfo[key] = args[key];
        }

        #region 外部方法

        StateFlow2 flow
        {
            get
            {
                int lastIndex = flowNo.LastIndexOf('.');
                string objectID = flowNo.Substring(0, lastIndex) + ".Flow." + flowNo.Substring(lastIndex + 1);
                return ObjectFactory.Instance.Get<StateFlow2>(objectID);
            }
        }

        protected virtual void doAction(string action, Dictionary<string, object> args)
        {
            //DBContext context = ObjectFactory.Instance.Get<DBContext>();
            //Application application = context.Get<Application>(applicationID);
            //流程到了
            StateFlow2 flow = ObjectFactory.Instance.Get<StateFlow2>(this.flowNo);
            //get for read
            //NewTools.StateFlow flow2 = context.Get<NewTools.StateFlow>(this.flowNo);

            //application.Action("PreOrderConfirm");

            //根據現有status和action找到下一個status
            //根據新的status，初始化它的子status欄位，如0.00,Fact_234,56.00等
            //增加歷程資料，可根據Action來設定
            //修改其它欄位，或者調用子動作 AssignCompany
            string nextStatus = flow.NextStatus(status, action, FlowInfo, args);
            string nextSubStatus = flow.SubStatus(nextStatus, FlowInfo, args);
            ToStatus(nextStatus, nextSubStatus);
            steps.Add(new Step{
                Seq = InstanceVersion
                ,
                ActTime = DateTime.Now.ToString("yyyyMMddHHmmss")
                ,
                ActorID = SubStatus
            });
        }

        List<Step> steps;

        class Step
        {
            public int Seq;
            public string ActTime;
            public string ActorID;
            public string Actor;
            public string Memo;             //show給用戶看的備注欄位
            public string ActActorID;
            public string ActActor;
            public string ActActorKind;     //代理 or 上司 or 授權等

            public string Action;
            public string NewStatus;
            public string NewSubStatus;
        }

        #endregion
    }
}