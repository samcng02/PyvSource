﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data;
using System.Data.Common;
using System.Reflection;
using System.Runtime.Serialization;
using System.Web;
using PCIWeb;
using PCIWeb.Tools;

namespace PCIWeb.DDD
{
    public class RDBEntityRepository : ConfigService, IEntityRepository
    {
        //const string MAIN_TABLE_NAME = "ENTITY_TABLE";
        public string LockTable;
        public readonly string Database;  
        //其它明細Table  
        public readonly ArrayList Tables;   
        public readonly string MainTable;
        public readonly string IdField = "ENTITY_ID";
        //不能說整個對象都只讀不寫，這樣在判斷是否存在時可能有問題
        //如先刪除，再新增，而因為只讀
        //不對，因為DomainContext會去判斷，所以不用擔心
        public readonly bool Readonly = false;

        Dictionary<string, object> getTable(string tableName)
        {
            foreach (Dictionary<string, object> table in Tables)
            {
                if (table["Table"].ToString().Equals(tableName))
                    return table;
            }
            return null;
        }

        Dictionary<string, object> getField(string tableName, string key, object value)
        {
            Dictionary<string, object> table = getTable(tableName);
            if (table != null)
            {
                ArrayList fields = table["Fields"] as ArrayList;
                foreach (Dictionary<string, object> field in fields)
                {
                    if (field.ContainsKey(key) && field[key].ToString().Equals(value))
                        return field;
                }
            }
            return null;
        }

        Dictionary<String, DbDataAdapter> adapters = new Dictionary<string, DbDataAdapter>();
        public RDBEntityRepository(Dictionary<string, object> config)
            : base(config)
        {

        }

        //要不要緩存?
        //如果緩存，遇到多個web server連一個db server時，何時清緩存？
        DataSet get(string id)
        {
            DataSet ds = new DataSet();
            foreach (Dictionary<string, object> table in Tables)
            {
                string tableName = table["Table"].ToString();
                string sql = "Select_" + tableName + "@" + Database;
                if (table.ContainsKey("SelectCommand"))
                    sql = table["SelectCommand"].ToString();
                //TODO:用動態sql可一下抓多個，而且DataSet自己就有了
                DataTable dt = DBHelper.Instance.Query(sql, Tool.ToDic(IdField, id)).Tables[0];
                dt.TableName = tableName;// table.ContainsKey("Name") ? table["Name"].ToString() : MAIN_TABLE_NAME;
                ArrayList keys = table.ContainsKey("Keys") ? table["Keys"] as ArrayList : new ArrayList();
                
                DataColumn[] keyColumns = new DataColumn[keys.Count+1];
                keyColumns[0] = dt.Columns[IdField];
                for (int i = 0; i < keys.Count; i++)
                    keyColumns[i + 1] = dt.Columns[keys[i].ToString()];
                dt.PrimaryKey = keyColumns;
                dt.DataSet.Tables.Remove(dt);
                ds.Tables.Add(dt);
            }
            return ds;
        }

        public T Get<T>(string id) where T : Entity//, new()
        {
            return dataSetToEntity<T>(get(id));
        }
        /*
        public Dictionary<string, object> Get(string id)
        {
            return dataSetToEntity(get(id));
        }
        */
        /*
        DataRow getRow(string id)
        {
            return Tool.ToRow(DBHelper.Instance.Query("Select_" + MainTable + "@" + Database, Tool.ToDic(IdField, id)));
        }
        */
        public void Insert(Entity entity)
        {
            if (!this.Readonly)
                saveEntity(entity.ID, entity);
            else
                Tool.Info("Entity Readonly(No need to write back db)", "table", MainTable, "entity", entity.GetType().FullName,"id",entity.ID);

        }

        public void Update(Entity entity)
        {
            if (!this.Readonly)
                saveEntity(entity.ID, entity);
            else
                Tool.Info("Entity Readonly(No need to write back db)", "table", MainTable, "entity", entity.GetType().FullName,"id",entity.ID);
        }

        public bool Exists(string type, string id)
        {
            Dictionary<string,object> table = getTable(MainTable);
            string tableName = table["Table"].ToString();
            string sql = "Select_" + tableName + "@" + Database;
            if (table.ContainsKey("SelectCommand"))
                sql = table["SelectCommand"].ToString();
            return Tool.ToRow(DBHelper.Instance.Query(sql, Tool.ToDic(IdField, id))) != null;
        }

        void saveEntity(string id,object entity)
        {
            DataSet ds = get(id);
            writeEntityToDataSet(ds,id,entity);
            save(ds,id);
        }

        static object lockObj = new object();

        void save(DataSet ds,string id)
        {
            bool isChange = false;
            foreach (DataTable dt in ds.Tables)
            {
                if (dt.GetChanges() != null)
                {
                    isChange = true;
                    break;
                }
            }
            if (isChange)
            {
                lock (lockObj)
                {
                    foreach (DataTable dt in ds.Tables)
                    {
                        //TODO:事務處理，VERSION驗證
                        //可用lock語句設定transaction，排斥其它執行緒使用
                        DataTable changeTable = dt.GetChanges();
                        string sourceTable = dt.TableName;
                        //if (sourceTable == "MRB_ROOM_INFO")
                        //    throw new PCIBusException("Test Throw Exception(Tran)");
                        if (changeTable != null && changeTable.Rows.Count > 0)
                        {
                            DbDataAdapter da = getDataAdapter(dt.TableName, id);
                            dt.TableName = "Table";
                            DataTableMapping dm = new DataTableMapping(sourceTable, "Table");
                            da.TableMappings.Add(dm);
                            da.TableMappings.Remove(dm);
                            Database db = ObjectFactory.Instance.Get<Database>(this.Database);
                            da.UpdateCommand.Transaction = da.DeleteCommand.Transaction = da.InsertCommand.Transaction = DBHelper.Instance.GetDefaultTran(db);
                            da.UpdateCommand.Connection = da.DeleteCommand.Connection = da.InsertCommand.Connection = da.InsertCommand.Transaction.Connection;
                            Tool.Info("Update DataTable", "DataTable", sourceTable, "Total", changeTable.Rows.Count);
                            DataTable tmpDt = dt.GetChanges(DataRowState.Added);
                            if(tmpDt!=null)
                                Tool.Info("Insert Rows","Rows",tmpDt,"Count",tmpDt.Rows.Count);
                            tmpDt = dt.GetChanges(DataRowState.Modified);
                            if(tmpDt!=null)
                                Tool.Info("Update Rows", "Rows", tmpDt, "Count", tmpDt.Rows.Count);
                            tmpDt = dt.GetChanges(DataRowState.Deleted);
                            if(tmpDt!=null)
                                Tool.Info("Delete Rows", "Rows", tmpDt, "Count", tmpDt.Rows.Count);
                            da.Update(ds);
                            dt.TableName = sourceTable;
                            da.UpdateCommand.Transaction = da.DeleteCommand.Transaction = da.InsertCommand.Transaction = null;
                            da.UpdateCommand.Connection = da.DeleteCommand.Connection = da.InsertCommand.Connection = null;
                        }
                        else
                        {
                            Tool.Info("DataTable no need update", "DataTable", sourceTable);
                        }
                    }
                }
            }
            else
            {
                Tool.Info("DataSet no need update(no table change)", "id", id);
            }
        }

        //有時候領域邏輯不需要取，直接刪除，這種也不比較version了?
        public void Delete(string type,string id)
        {
            if (!this.Readonly)
            {
                foreach (Dictionary<string, object> table in Tables)
                {
                    if (!table.ContainsKey("SelectCommand"))
                    {
                        string tableName = table["Table"].ToString();
                        Dictionary<string, object> args = Tool.ToDic(IdField, id);
                        DBHelper.Instance.Execute("Delete_" + tableName + "@" + Database, args);
                    }
                }
            }
            else
                Tool.Info("Entity Readonly(No need to write back db)", "table", MainTable, "entity", type, "id", id);

        }

        const string ORIGIN_VER_PARAM_SUFFIX = "_ORIGINAL_VER";

        //const string WRITE_ONLY_NOT_MODIFY = "WRITE_ONLY_NOT_MODIFY";       //用于一些資訊欄位，只寫不讀(多行怎辦?)

        void getSqlString(string tableName, List<string> insertParams,List<string> updateParams,List<string> deleteParams,out string whereList, out string insertList, out string valuesList, out string updateList)
        {
            Database db = ObjectFactory.Instance.Get<Database>(this.Database);
            StringBuilder whereSb = new StringBuilder();
            StringBuilder insertSb = new StringBuilder();
            StringBuilder valuesSb = new StringBuilder();
            StringBuilder updateSb = new StringBuilder();
            //if(modalDs==null)
            //    modalDs = get("");                  //使用一個dataset模板
            //DataTable dt = modalDs.Tables[table];
            Dictionary<string,object> table = getTable(tableName);
            string paramPrefix = db.DBType.Equals(DatabaseType.Oracle) ? ":" : "@";
            insertSb.AppendFormat(IdField);
            valuesSb.AppendFormat("{0}{1}", paramPrefix, IdField);
            updateSb.AppendFormat("{0}={1}{0}", IdField, paramPrefix);
            whereSb.AppendFormat("{0}={1}{0}{2}", IdField, paramPrefix,ORIGIN_VER_PARAM_SUFFIX);

            insertParams.Add(paramPrefix + IdField);
            updateParams.Add(paramPrefix + IdField);
            updateParams.Add(paramPrefix + IdField + ORIGIN_VER_PARAM_SUFFIX);
            deleteParams.Add(paramPrefix + IdField + ORIGIN_VER_PARAM_SUFFIX);

            ArrayList keys = new ArrayList();
            if (table.ContainsKey("Keys"))
                keys = table["Keys"] as ArrayList;

            ArrayList fields = table["Fields"] as ArrayList;
            foreach (Dictionary<string,object> field in fields)
            {
                if (field.ContainsKey("Column"))
                {
                    string fieldName = field["Column"].ToString();
                    if (fieldName != IdField)
                    {
                        insertSb.AppendFormat(",{0}", fieldName);
                        valuesSb.AppendFormat(",{0}{1}", paramPrefix, fieldName);
                        updateSb.AppendFormat("{2}{0}={1}{0}", fieldName, paramPrefix, updateSb.Length > 0 ? "," : "");
                        if (keys.Contains(fieldName))
                            whereSb.AppendFormat(" and {0}={1}{0}{2}", fieldName, paramPrefix, ORIGIN_VER_PARAM_SUFFIX);

                        insertParams.Add(paramPrefix + fieldName);
                        updateParams.Add(paramPrefix + fieldName);
                        if (keys.Contains(fieldName))
                        {
                            updateParams.Add(paramPrefix + fieldName + ORIGIN_VER_PARAM_SUFFIX);
                            deleteParams.Add(paramPrefix + fieldName + ORIGIN_VER_PARAM_SUFFIX);
                        }
                    }
                }
            }

            insertList = insertSb.ToString();
            valuesList = valuesSb.ToString();
            updateList = updateSb.ToString();
            whereList = whereSb.ToString();
        }

        void addParams(Database db, DbCommand command, List<string> insertParams)
        {
            foreach (string param in insertParams)
            {
                DbParameter p = db.CreateParameter(param, null);
                if (param.EndsWith(ORIGIN_VER_PARAM_SUFFIX))
                {
                    p.SourceColumn = param.Substring(1).Replace(ORIGIN_VER_PARAM_SUFFIX,"");
                    p.SourceVersion = DataRowVersion.Original;
                }
                else
                {
                    p.SourceColumn = param.Substring(1);
                }
                command.Parameters.Add(p);
            }

        }

        /*
        DbType: AnsiString
    Direction: Input
    IsNullable: false
    ParameterName: "@p1"
    Size: 0
    SourceColumn: "ENTITY_ID"
    SourceColumnNullMapping: false
    SourceVersion: Current
    Value: null
        */
        DbDataAdapter getDataAdapter(string table,string id)
        {
            if (!adapters.ContainsKey(table))
            {
                Database db = ObjectFactory.Instance.Get<Database>(this.Database);
                DbDataAdapter da = db.GetDataAdapter();
                string whereList;
                string insertList;
                string valuesList;
                string updateList;
                List<string> insertParams = new List<string>();
                List<string> updateParams = new List<string>();
                List<string> deleteParams = new List<string>();
                getSqlString(table, insertParams, updateParams, deleteParams, out whereList, out insertList, out valuesList, out updateList);
                
                //da.SelectCommand = db.GetSqlStringCommand(string.Format("Select * FROM {0} WHERE {1} = '{2}'",table,IdField,id));
                //da.SelectCommand.Transaction = DBHelper.Instance.GetDefaultTran(db);
                //da.SelectCommand.Connection = da.SelectCommand.Transaction.Connection;
                //DbCommandBuilder commandBuilder = db.CreateCommandBuilder();
                //commandBuilder.DataAdapter = da;

                da.InsertCommand = db.GetSqlStringCommand(string.Format("INSERT INTO {0}({1}) VALUES({2})", table, insertList, valuesList));
                addParams(db, da.InsertCommand, insertParams);
                da.UpdateCommand = db.GetSqlStringCommand(string.Format("UPDATE {0} SET {1} WHERE {2}", table, updateList, whereList));
                addParams(db, da.UpdateCommand, updateParams);
                da.DeleteCommand = db.GetSqlStringCommand(string.Format("DELETE FROM {0} WHERE {1}", table, whereList));
                addParams(db, da.DeleteCommand, deleteParams);
                adapters[table] = da;
            }
            return adapters[table];
        }

        //將entity寫回DataSet，然后DataSet進行查詢
        void writeEntityToDataSet(DataSet ds, string id, object entity)
        {
            DataTable dt = ds.Tables[MainTable];
            DataRow[] drs = dt.Select(string.Format("{0}='{1}'", IdField, id));
            if (drs.Length > 0)
            {
                DataRow dr = drs[0];
                //dr[VerionField] = version;
                writeObjectToDataRow(entity, dr);
            }
            else   //完全新增
            {
                DataRow dr = dt.NewRow();
                //新增一定驗證
                //修改時，有修改ID才驗證
                validColumn(MainTable, IdField, id);
                dr[IdField] = id;
                writeObjectToDataRow(entity, dr);
                dt.Rows.Add(dr);
            }
        }

        void writeListFieldToDataRow(DataRow dr, string subTableName, IList list)
        {
            Dictionary<string, object> tableSet = getTable(subTableName);
            if (tableSet.ContainsKey("SelectCommand"))
            {
                Tool.Info("Table SelectCommand(No need to write back db)", "table", subTableName);
                return;
            }


            DataSet ds = dr.Table.DataSet;
            DataTable subDt = ds.Tables[subTableName];
            List<DataRow> subExistsRows = new List<DataRow>();      //不在這里面的都刪除掉
            if (list != null)       //null表示刪除
            {
                List<string> keys = new List<string>();
                foreach (DataColumn key in dr.Table.PrimaryKey)
                    keys.Add(key.ColumnName);
                foreach (object item in list)
                {
                    StringBuilder sb = new StringBuilder();
                    DataColumn[] SubKeys = subDt.PrimaryKey;
                    foreach (DataColumn subKey in SubKeys)
                    {
                        string fieldName=null;
                        if(!keys.Contains(subKey.ColumnName))
                            fieldName = getField(subTableName, "Column", subKey.ColumnName)["Name"].ToString();
                        sb.AppendFormat("{0}{1}='{2}'", sb.Length > 0 ? " and " : "", subKey.ColumnName
                            , keys.Contains(subKey.ColumnName) ?
                                dr[subKey.ColumnName]
                                :fieldName=="this"?item: item.GetType().GetField(fieldName).GetValue(item));
                    }
                    DataRow[] subDrs = subDt.Select(sb.ToString());
                    if (subDrs.Length > 0)
                    {
                        DataRow subDr = subDrs[0];
                        writeObjectToDataRow(item, subDr);
                        subExistsRows.Add(subDr);
                    }
                    else            //新增
                    {
                        DataRow subDr = subDt.NewRow();
                        foreach (DataColumn key in dr.Table.PrimaryKey)
                            subDr[key.ColumnName] = dr[key];
                        writeObjectToDataRow(item, subDr);
                        subDt.Rows.Add(subDr);
                        subExistsRows.Add(subDr);
                    }
                }
            }
            for (int i = subDt.Rows.Count - 1; i >= 0; i--)
            {
                if (!subExistsRows.Contains(subDt.Rows[i]))
                    subDt.Rows[i].Delete();
            }
        }

        void writeItemFieldToDataRow(DataRow dr, string subTableName, object item)
        {
            Dictionary<string, object> tableSet = getTable(subTableName);
            if (tableSet.ContainsKey("SelectCommand"))
            {
                Tool.Info("Table SelectCommand(No need to write back db)", "table", subTableName);
                return;
            }

            DataSet ds = dr.Table.DataSet;
            DataTable subDt = ds.Tables[subTableName];
            //1對1
            StringBuilder sb = new StringBuilder();
            DataColumn[] keys = dr.Table.PrimaryKey;
            foreach (DataColumn key in keys)
                sb.AppendFormat("{0}{1}='{2}'", sb.Length > 0 ? " and " : "", key.ColumnName, dr[key]);
            DataRow[] subRows = subDt.Select(sb.ToString());

            if (subRows.Length > 0)
            {
                DataRow subDr = subRows[0];
                if (item != null)
                    writeObjectToDataRow(item, subDr);
                else
                    subDr.Delete();
            }
            else if (item != null)
            {
                DataRow subDr = subDt.NewRow();
                foreach (DataColumn key in dr.Table.PrimaryKey)
                    subDr[key.ColumnName] = dr[key];
                writeObjectToDataRow(item, subDr);
                subDt.Rows.Add(subDr);
            }
        }

        void validColumn(string tableName, string column, object value)
        {
            Dictionary<string, object> field = this.getField(tableName,"Column",column);
            if (field!=null && field.ContainsKey("Valid"))
            {
                Dictionary<string,object> args = Tool.ToDic(column,value);
                Dictionary<string, object> valids = field["Valid"] as Dictionary<string, object>;
                foreach (string rule in valids.Keys)
                {
                    string error = Context.ValidTool.ValidField(args, column, rule, valids[rule]);
                    if (error != null)
                    {
                        Dictionary<string, object> validSetting = valids[rule] as Dictionary<string, object>;
                        throw new PCIBusException(validSetting.ContainsKey("@Info") ? validSetting["@Info"].ToString() : "[" + column + "]" + error);
                    }
                }
            }
        }

        void writeObjectToDataRow(object obj, DataRow dr)
        {
            //DataSet ds = dr.Table.DataSet;
            Dictionary<string, object> tableSet = getTable(dr.Table.TableName);
            ArrayList fields = tableSet["Fields"] as ArrayList;
            foreach (Dictionary<string, object> field in fields)
            {
                /*
                if (tableSet.ContainsKey("SelectCommand"))
                {
                    Tool.Info("Field Readonly(No need to write back db)", "table", dr.Table.TableName, "Field", field["Name"]);
                    continue;
                }
                */
                string fName = field["Name"].ToString();
                object fValue = null;
                //bool setValue = true;
                if (fName == "this")
                {
                    fValue = obj;
                }
                else
                {
                    if (obj is Dictionary<string, object>)
                    {
                        Dictionary<string, object> dic = obj as Dictionary<string, object>;
                        if (dic.ContainsKey(fName))
                            fValue = dic[fName];
                        //else
                        //    setValue = false;
                    }
                    else
                    {

                        Type type = obj.GetType();
                        FieldInfo fieldInfo = null;
                        while (true)
                        {
                            fieldInfo = type.GetField(fName, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
                            if (fieldInfo != null)
                                break;
                            //如果是Entity內部的嵌套類型，可能會到object，不過應該也可以對這個方法多加一個參數來設定（但現在沒必要）
                            //Entity的東西還是在這里統一設定，配置檔要設定id屬性了
                            if (type.BaseType == null || type.BaseType == typeof(object) || type == typeof(PCIWeb.DDD.Entity))
                                break;
                            type = type.BaseType;
                        }



                        //FieldInfo fieldInfo = obj.GetType().GetField(fName, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
                        if (fieldInfo == null)
                            throw new ApplicationException("FIELD_NOT_FOUND:" + obj.GetType().FullName + "." + fName);

                        fValue = fieldInfo.GetValue(obj);
                        //枚舉類型一律存在int方式
                        if (fieldInfo.FieldType.IsEnum)
                            fValue = (int)fValue;
                    }
                }
                //if (setValue)
                //{
                    //簡單類型
                    if (field.ContainsKey("Column"))
                    {
                        string column = field["Column"].ToString();
                        //本來是沒有修改，就不用再驗證了
                        //但是新增時，是NewRow過來，所有值為null，如果這時有Required驗證，可能就會驗證不到
                        /*
                        if (fValue == null && field.ContainsKey("IfNull"))
                        {
                            object nullValue = field["IfNull"];
                            if (nullValue.ToString() == "@GUID")
                                fValue = Guid.NewGuid().ToString();
                        }
                        //一般是用作主key的不能為null,但這樣到DB的就是null了，在select使用時，要注意
                        else if (fValue == null && field.ContainsKey("NullSaveAs"))
                        {
                            fValue = field["NullSaveAs"];
                        }
                        */
                        //如果是新增的，則在外面驗證。修改則在里面難證
                        if(dr.RowState == DataRowState.Added)
                            validColumn(dr.Table.TableName, column, fValue);
                        if (!dr[column].Equals(fValue??DBNull.Value))
                        {
                            if (dr.RowState != DataRowState.Added)
                                validColumn(dr.Table.TableName, column, fValue);
                            dr[column] = fValue;
                        }
                    }
                    //明細Table(1對多)
                    else if (field.ContainsKey("List"))
                    {
                        IList list = fValue as IList;
                        writeListFieldToDataRow(dr, field["List"].ToString(), list);
                    }
                    //明細Table(1對1)
                    else if (field.ContainsKey("Item"))
                    {
                        writeItemFieldToDataRow(dr, field["Item"].ToString(), fValue);
                    }
                //}
            }
        }

        Dictionary<string, object> dataSetToEntity(DataSet ds)
        {
            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[MainTable].Rows[0];
                Dictionary<string, object> entity = new Dictionary<string, object>();
                entity[IdField] = dr[IdField];
                fillObjectByDataRow(entity, dr);
                return entity;
            }
            return null;
        }

        T dataSetToEntity<T>(DataSet ds) where T : Entity//, new()
        {
            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[MainTable].Rows[0];
                T t = (T)FormatterServices.GetUninitializedObject(typeof(T));
                //T t = Activator.CreateInstance<T>();// new T();// (T)Activator.CreateInstance(typeof(T));
                Entity entity = t as Entity;
                //OK!TODO:如果Entity有繼承，則父類的私有字段是設置不到的?
                //typeof(Entity).GetField("id", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).SetValue(entity, dr[IdField].ToString());
                //entity.ID = dr[IdField].ToString();
                t = (T)fillObjectByDataRow(t, dr);
                return t;
            }
            return default(T);
        }

        FieldInfo getEntityField(Type type, string name)
        {
            while (true)
            {
                FieldInfo ret = type.GetField(name, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
                if (ret != null)
                    return ret;
                //如果是Entity內部的嵌套類型，可能會到object，不過應該也可以對這個方法多加一個參數來設定（但現在沒必要）
                //Entity的東西還是在這里統一設定，配置檔要設定id屬性了
                if (type.BaseType == null || type.BaseType == typeof(object) || type == typeof(PCIWeb.DDD.Entity))
                    break;
                type = type.BaseType;
            }
            throw new PCIBusException("field:" + name + " not exist in " + type.FullName);
        }

        object fillObjectByDataRow(object obj, DataRow dr)
        {
            DataSet ds = dr.Table.DataSet;
            Dictionary<string, object> tableSet = getTable(dr.Table.TableName);

            ArrayList fields = tableSet["Fields"] as ArrayList;
            foreach (Dictionary<string, object> field in fields)
            {
                string fName = field["Name"].ToString();
                object fValue = null;

                if (field.ContainsKey("Column"))
                {
                    string column = field["Column"].ToString();
                    fValue = dr[column];

                    if (fValue.Equals(DBNull.Value))
                        fValue = null;

                    if (fName == "this")
                        return fValue;

                    //如果資料庫中的數據是NullSaveAs，說明這個值在Domain中是以null來使用的
                    //因為資料庫的主key不能為null
                    //if (field.ContainsKey("NullSaveAs") && field["NullSaveAs"] == fValue)
                    //    fValue = null;
                        
                }
                //明細Table(1對多)
                else if (field.ContainsKey("List"))
                {
                    string subTable = field["List"].ToString();
                    DataColumn[] keys = dr.Table.PrimaryKey;
                    StringBuilder sb = new StringBuilder();
                    foreach (DataColumn key in keys)
                        sb.AppendFormat("{0}{1}='{2}'", sb.Length > 0 ? " and " : "", key.ColumnName, dr[key]);
                    DataRow[] subRows = ds.Tables[subTable].Select(sb.ToString());
                    if (obj is Dictionary<string, object>)
                    {
                        ArrayList list = new ArrayList();
                        foreach (DataRow subDr in subRows)
                        {
                            Dictionary<string, object> item = new Dictionary<string, object>();
                            object newItem = fillObjectByDataRow(item, subDr);
                            list.Add(newItem);
                        }
                        fValue = list;
                    }
                    else
                    {
                        Type listType = getEntityField(obj.GetType(),fName).FieldType;//.GetField(fName, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public).FieldType;
                        IList list = (IList)Activator.CreateInstance(listType);
                        Type itemType = listType.GetGenericArguments()[0];
                        foreach (DataRow subDr in subRows)
                        {
                            object item = Activator.CreateInstance(itemType);     //子類型也必須支援new
                            object newItem = fillObjectByDataRow(item, subDr);
                            list.Add(newItem);
                        }
                        fValue = list;
                    }
                }
                else if (field.ContainsKey("Item"))
                {
                    //1對1
                    string subTable = field["Item"].ToString();
                    DataColumn[] keys = dr.Table.PrimaryKey;
                    StringBuilder sb = new StringBuilder();
                    foreach (DataColumn key in keys)
                        sb.AppendFormat("{0}{1}='{2}'", sb.Length > 0 ? " and " : "", key.ColumnName, dr[key]);
                    DataRow[] subRows = ds.Tables[subTable].Select(sb.ToString());
                    if (subRows.Length > 0)
                    {
                        if (obj is Dictionary<string, object>)
                        {
                            Dictionary<string, object> item = new Dictionary<string, object>();
                            item = (Dictionary<string, object>)fillObjectByDataRow(item, subRows[0]);
                            fValue = item;
                        }
                        else
                        {
                            Type itemType = getEntityField(obj.GetType(), fName).FieldType;// obj.GetType().GetField(fName, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public).FieldType;
                            object item = Activator.CreateInstance(itemType);     //子類型也必須支援new
                            item = fillObjectByDataRow(item, subRows[0]);
                            fValue = item;
                        }
                    }
                }

                //用不著mapping，只要將值返回即可
                if (obj is Dictionary<string, object>)
                    (obj as Dictionary<string, object>)[fName] = fValue;
                else
                {
                    Type type = obj.GetType();
                    bool isSetField = false;
                    while (true)
                    {
                        //Entity的屬性在外面直接hardcode反射，目前只有id（fields不會配置Entity的屬性，如id）
                        //if()
                        //    break;
                        FieldInfo setField = type.GetField(fName, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
                        if (setField != null)
                        {
                            setField.SetValue(obj, field.ContainsKey("ChangeType")?Convert.ChangeType(fValue,setField.FieldType):fValue);
                            isSetField = true;
                            break;
                        }
                        //如果是Entity內部的嵌套類型，可能會到object，不過應該也可以對這個方法多加一個參數來設定（但現在沒必要）
                        //Entity的東西還是在這里統一設定，配置檔要設定id屬性了
                        if (type.BaseType == null || type.BaseType == typeof(object) || type == typeof(PCIWeb.DDD.Entity))
                            break;
                        type = type.BaseType;
                    }
                    if (!isSetField)
                        Tool.Warn("Can not find field", "field", fName);
                }
            }
            return obj;
        }

        public void Lock(string type, string id)
        {
            DBHelper.Instance.Execute("Insert_" + LockTable + "@" + Database, Tool.ToDic("TYPE", type, "ID", id, "LOCK_USER_ID", AuthenticateHelper.Instance.UserID, "LOCK_TIME", DateTime.Now.ToString("yyyyMMddHHmmss")));
        }

        public void UnLock(string type, string id)
        {
            DBHelper.Instance.Execute("Delete_" + LockTable + "@" + Database, Tool.ToDic("TYPE", type, "ID", id));
        }
    }
}