﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.Serialization;
using PCIWeb.Tools;

namespace PCIWeb.DDD
{
    //既可用于測試DDD邏輯，無關存儲邏輯
    //也可用于一臺web對一臺server時的緩存（不過目前eip.pci.co.id和www.pci.co.id兩臺web同時訪問一臺db）
    //所以目前生產性的server則用RDBEntityRepository好了(每個主table加一個lock欄位，只有鎖住了才可以進行)

    //db在Get時for update可能會死鎖。get時拿住version,保存時檢查version，update version先，然后select回來看有沒有ok，再報錯rollback
    //要不直接鎖?
    //一起鎖?不行?
    //單獨鎖，可以?udpate/delete一個鎖一個，ok后再還一個
    public class MemoryEntityRepository:IEntityRepository
    {
        static Dictionary<string, string> _store;
        static List<string> _lockIds;

        static MemoryEntityRepository()
        {
            _store = new Dictionary<string, string>();
            _lockIds = new List<string>();
        }

        public T Get<T>(string id) where T:Entity
        {
            string key = typeof(T).FullName + "-" + id;
            if (_store.ContainsKey(key))
            {
                JsonObjectHelper jHelper = new JsonObjectHelper();
                return jHelper.DicToObject<T>(Tool.ToDic(_store[key]));
            }
            else
                return null;
        }

        public void Insert(Entity entity)
        {
            //不鎖，直接新增，用主key出錯來保證
            _store.Add(entity.GetType().FullName + "-" + entity.ID, Tool.ToJson(entity));
            Tool.Info("Insert", "type", entity.GetType().FullName, "id", entity.ID);
        }

        public void Update(Entity entity)
        {
            _store[entity.GetType().FullName + "-" + entity.ID] = Tool.ToJson(entity);
            Tool.Info("Update", "type", entity.GetType().FullName, "id", entity.ID);
        }

        public void Delete(string type,string id)
        {
            _store.Remove(type + "-" + id);
            Tool.Info("Delete", "type", type, "id", id);
        }

        public bool Exists(string type, string id)
        {
            string key = type + "-" + id;
            return _store.ContainsKey(key);
        }

        static object _lockIdsObj = new object();

        public void Lock(string type,string id)
        {
            lock (_lockIdsObj)
            {
                string key = type + "-" + id;
                if (_lockIds.Contains(key))
                    throw new PCIBusException("ENTITY_LOCKED_" + key);

                _lockIds.Add(key);
                Tool.Info("Lock", "type", type, "id", id,"locks",_lockIds);
            }
        }

        public void UnLock(string type, string id)
        {
            lock (_lockIdsObj)
            {
                string key = type + "-" + id;
                _lockIds.Remove(key);
                Tool.Info("Unlock", "type", type, "id", id, "locks", _lockIds);
            }
        }
    }
}