﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data;
using System.Data.Common;
using System.Reflection;
using System.Runtime.Serialization;
using System.Web;
using PCIWeb;
using PCIWeb.Tools;

namespace PCIWeb.DDD
{
    public class JsonDBEntityRepository :  IEntityRepository
    {
        //const string MAIN_TABLE_NAME = "ENTITY_TABLE";

        public string Database;  
        //其它明細Table  
        public string Table;
        public string LockTable;

        public JsonDBEntityRepository(string db,string table,string lockTable)
        {
            this.Database = db;
            this.Table = table;
            this.LockTable = lockTable;
        }

        public T Get<T>(string id) where T : Entity//, new()
        {
            DataRow dr = Tool.ToRow(DBHelper.Instance.Query("Select_" + Table + "@" + Database, Tool.ToDic("ID", id,"TYPE",typeof(T).FullName)));
            if (dr != null)
            {
                string jsonStr = dr["JSON"].ToString();
                Dictionary<string,object> jsonDic = Tool.ToDic(jsonStr);                
                return dicToEntity<T>(jsonDic);
               // typeof(Entity).GetField("id", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).SetValue(ret, id);
               // return ret;
            }
            return null;
        }

        public void Insert(Entity entity)
        {
            DBHelper.Instance.Execute("Insert_" + Table + "@" + Database, Tool.ToDic("ID", entity.ID, "TYPE", entity.GetType().FullName, "JSON", Tool.ToJson(entity), "ADD_TIME", DateTime.Now.ToString("yyyyMMddHHmmss"), "ADD_USER_ID", AuthenticateHelper.Instance.UserID, "UPD_TIME", DateTime.Now.ToString("yyyyMMddHHmmss"), "UPD_USER_ID", AuthenticateHelper.Instance.UserID));
        }

        public void Update(Entity entity)
        {
            DBHelper.Instance.Execute("Update_" + Table + "@" + Database, Tool.ToDic("ID__W", entity.ID, "TYPE__W", entity.GetType().FullName, "JSON", Tool.ToJson(entity), "UPD_TIME", DateTime.Now.ToString("yyyyMMddHHmmss"), "UPD_USER_ID", AuthenticateHelper.Instance.UserID));
        }

        public bool Exists(string type, string id)
        {
            return Tool.ToRow(DBHelper.Instance.Query("Select_" + Table + "@" + Database, Tool.ToDic("ID", id, "TYPE", type))) != null;
        }

        //有時候領域邏輯不需要取，直接刪除，這種也不比較version了?
        public void Delete(string type,string id)
        {
            DBHelper.Instance.Execute("Delete_" + Table + "@" + Database, Tool.ToDic("ID", id,"TYPE",type));
        }

        T dicToEntity<T>(Dictionary<string,object> dic) where T : Entity//, new()
        {
            JsonObjectHelper jHelper = new JsonObjectHelper();
            return jHelper.DicToObject<T>(dic);
        }

        public void Lock(string type, string id)
        {
            DBHelper.Instance.Execute("Insert_" + LockTable + "@" + Database, Tool.ToDic("TYPE", type, "ID", id, "LOCK_USER_ID", AuthenticateHelper.Instance.UserID, "LOCK_TIME", DateTime.Now.ToString("yyyyMMddHHmmss")));
        }

        public void UnLock(string type, string id)
        {
            DBHelper.Instance.Execute("Delete_" + LockTable + "@" + Database, Tool.ToDic("TYPE", type, "ID", id));
        }
    }
}