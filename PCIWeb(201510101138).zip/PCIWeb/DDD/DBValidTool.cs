﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Text;
using PCIWeb;
using PCIWeb.Tools;

namespace PCIWeb
{
    class DBValidTool
    {
        public string Unique(object o,string db,string table,string field)
        {
            bool exists = Tool.ToRow(DBHelper.Instance.Query("Select_" + table + "@" + db, Tool.ToDic(field, o))) != null;
            if (exists)
                return o + " exists!";//(" + db + "." + table + "." + field + ")";
            return null;
        }

        public string Exists(object o, string db, string table, string field)
        {
            bool exists = Tool.ToRow(DBHelper.Instance.Query("Select_" + table + "@" + db, Tool.ToDic(field, o))) != null;
            if (!exists)
                return o + " not exists!";//(" + db + "." + table + "." + field + ")";
            return null;
        }
    }
    
    /*
    class Size : Entity
    {
        public string SizeNo;
        public string SizeName;

        public Size(string sizeNo, string sizeName)
        {
            this.ID = sizeNo;
            this.SizeNo = sizeNo;
            this.SizeName = sizeName;
        }
    }

    class Company : Entity
    {
        public string CompanyNo;
        public string CompanyName;
        public string Email;
        public string Address;
    }

    class Brand : Entity
    {
        public string BrandNo;
        public string BrandName;
    }
    */
}