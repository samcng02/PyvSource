using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Text;

//Bonding Test
namespace PCIWeb.Tools
{

    public class TableHtmlHelper
    {
        protected Dictionary<string, object>[] _fields;                           //0:fieldNo 1:prompt

        protected Dictionary<string, string> _attrs;            //�@�ǳ]�w class:table���˦�

        public TableHtmlHelper(Dictionary<string, object>[] fields)
            : this(fields, null)
        {

        }

        public TableHtmlHelper(Dictionary<string, object>[] fields, Dictionary<string, string> attrs)
        {
            _fields = fields;
            _attrs = attrs;
        }

        protected string getAttr(string key)
        {
            if (_attrs != null && _attrs.ContainsKey(key))
                return _attrs[key];
            return "";
        }

        protected void tagBegin(StringBuilder sb, string tag)
        {
            this.tagBegin(sb, tag, true);
        }

        protected void tagBegin(StringBuilder sb, string tag, bool isEnd)
        {
            sb.AppendFormat("<{0}", tag);
            if (isEnd)
                tagBeginEnd(sb);
        }

        protected void tagBeginEnd(StringBuilder sb)
        {
            sb.Append(">");
        }

        protected void tagEnd(StringBuilder sb, string tag)
        {
            sb.AppendFormat("</{0}>", tag);
        }

        protected StringBuilder html;           //�C��call GetHtml�ɭ��s��l��

        public virtual string GetHtml(DataRow[] drs)
        {
            if (drs != null && drs.Length > 0)
            {
                html = new StringBuilder();
                tableHtml(drs);
                return html.ToString();
            }
            return null;
        }
        public virtual string GetHtml(List<DataRow> drList)
        {
            if (drList != null && drList.Count > 0)
            {
                DataRow[] drs = new DataRow[drList.Count];
                drList.CopyTo(drs);
                return GetHtml(drs);
            }
            return null;

        }

        public virtual string GetHtml(DataTable dt)
        {
            if (dt!=null && dt.Rows.Count>0)
            {
                DataRow[] drs = new DataRow[dt.Rows.Count];
                dt.Rows.CopyTo(drs, 0);
                return GetHtml(drs);
            }
            return null;
        }

        public virtual string GetHtml(DataSet ds)
        {
            return GetHtml(ds, 0);
        }

        public virtual string GetHtml(DataSet ds, int index)
        {
            if (ds != null && ds.Tables.Count > index)
            {
                return GetHtml(ds.Tables[index]);
            }
            return null;
        }

        public virtual string GetHtml(DataSet ds, string tableName)
        {
            if (ds != null && ds.Tables.Contains(tableName))
            {
                return GetHtml(ds.Tables[tableName]);
            } 
            return null;
        }

        protected virtual void tableHtml(DataRow[] drs)
        {
            tagBegin(html, "table", false);
            tableAttrsHtml();
            tagBeginEnd(html);
            headHtml();
            bodyHtml(drs);
            tagEnd(html, "table");
        }

        protected virtual void tableAttrsHtml()
        {
            html.AppendFormat(" cellpadding='0' cellspacing='0' class='{0}'", getAttr("class"));
        }

        protected virtual void headHtml()
        {
            tagBegin(html, "thead");
            headRowHtml();
            tagEnd(html, "thead");

        }

        protected virtual void headRowHtml()
        {
            tagBegin(html, "tr");
            int fieldIndex = 0;
            foreach (Dictionary<string, object> field in _fields)
            {
                headCellHtml(field, fieldIndex++);
            }
            tagEnd(html, "tr");
        }

        protected virtual void headCellHtml(Dictionary<string, object> field, int fieldIndex)
        {
            html.AppendFormat("<th class='field-{0}'>{1}</th>", field["fieldNo"], field["prompt"]);   //0:fieldNo 1:prompt
        }

        protected virtual void bodyHtml(DataRow[] drs)
        {
            tagBegin(html, "tbody");
            int rowIndex = 0;
            foreach (DataRow dr in drs)
            {
                bodyRowHtml(dr, rowIndex);
                rowIndex++;
            }
            tagEnd(html, "tbody");
        }

        protected virtual void bodyRowHtml(DataRow dr, int rowIndex)
        {
            //�ˬd�O�_�s������
            tagBegin(html, "tr", false);
            bodyRowAttrsHtml(dr, rowIndex);
            tagBeginEnd(html);
            int fieldIndex = 0;
            foreach (Dictionary<string, object> field in _fields)
            {
                bodyCellHtml(dr, field, rowIndex, fieldIndex);
            }
            tagEnd(html, "tr");
        }

        protected virtual void bodyRowAttrsHtml(DataRow dr, int rowIndex)
        {
            html.AppendFormat(" class='{0}'", rowIndex % 2 == 1 ? "odd" : "");
        }

        protected virtual void bodyCellHtml(DataRow dr, Dictionary<string, object> field, int rowIndex, int fieldIndex)
        {
            html.AppendFormat("<td {0}>{1}</td>", bodyCellAttrs(dr, field, rowIndex, fieldIndex), bodyCellContent(dr, field, rowIndex, fieldIndex));
        }

        protected virtual string bodyCellAttrs(DataRow dr, Dictionary<string, object> field, int rowIndex, int fieldIndex)
        {
            return " class='" + bodyCellClass(dr, field, rowIndex, fieldIndex) + "'";
        }

        protected virtual string bodyCellClass(DataRow dr, Dictionary<string, object> field, int rowIndex, int fieldIndex)
        {
            string className = "field-" + field["fieldNo"].ToString();
            if (field.ContainsKey("class"))
            {
                className += " " + field["class"].ToString();
            }
            if (field.ContainsKey("getClass"))
            {
                GetClassDel getClass = field["getClass"] as GetClassDel;
                className += " " + getClass(dr, field, rowIndex, fieldIndex);
            }
            return className;
        }

        protected virtual string bodyCellContent(DataRow dr, Dictionary<string, object> field, int rowIndex, int fieldIndex)
        {
            string fieldText = dr[field["fieldNo"].ToString()].ToString();
            if (field.ContainsKey("format"))
            {
                FormatCellDel format = field["format"] as FormatCellDel;
                fieldText = format(fieldText);
            }
            return fieldText;
        }

        public delegate string FormatCellDel(string fieldText);

        public delegate string GetClassDel(DataRow dr, Dictionary<string, object> field, int rowIndex, int fieldIndex);
    }

    public class FieldFormat
    {
        public static string FormatShortDateTime(string timeStr)
        {
            if (timeStr != null && timeStr.Length >= 12)
            {
                return timeStr.Substring(4, 2) + "/" + timeStr.Substring(6, 2)
                    + " " + timeStr.Substring(8, 2) + ":" + timeStr.Substring(10, 2);
            }
            return timeStr ?? "";
        }

        public static string FormatShortDate(string timeStr)
        {
            if (timeStr != null && timeStr.Length >= 8)
            {
                return timeStr.Substring(4, 2) + "/" + timeStr.Substring(6, 2);
            }
            return timeStr ?? "";
        }
    }


}