﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Reflection;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using PCIWeb.Tools;

namespace PCIWeb
{
    //認証模組
    public interface IAuthenticateModule
    {
        string GetUserID();

        void SetUserID(string userID, string loginInfo);

        void ClearUserID();

    }

    public class SessionAuthenticateModule : IAuthenticateModule
    {
        public string GetUserID()
        {
            if(HttpContext.Current.Session!=null)
                return HttpContext.Current.Session["UserID"] as string;
            return null;
        }

        public void SetUserID(string userID, string loginInfo)
        {
            if (HttpContext.Current.Session != null)
                HttpContext.Current.Session["UserID"] = userID;
        }

        public void ClearUserID()
        {
            //HttpContext.Current.Session.Remove("UserID");
            if (HttpContext.Current.Session != null)
            {
                HttpContext.Current.Session.Clear();
                HttpContext.Current.Session.Abandon();
            }
        }
    }

    public class CookieAuthenticateModule : IAuthenticateModule
    {

        #region cookie加解密

        const string _KEY_64 = "a4G-8=Jk"; //必須是8個字符（64Bit)
        const string _IV_64 = "JKbN=5[?";  //必須是8個字符（64Bit)

        public static string Encrypt(string PlainText, string KEY_64, string IV_64)
        {
            byte[] byKey = System.Text.ASCIIEncoding.ASCII.GetBytes(KEY_64);
            byte[] byIV = System.Text.ASCIIEncoding.ASCII.GetBytes(IV_64);

            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            int i = cryptoProvider.KeySize;
            MemoryStream ms = new MemoryStream();
            CryptoStream cst = new CryptoStream(ms, cryptoProvider.CreateEncryptor(byKey, byIV), CryptoStreamMode.Write);

            StreamWriter sw = new StreamWriter(cst);
            sw.Write(PlainText);
            sw.Flush();
            cst.FlushFinalBlock();
            sw.Flush();
            return Convert.ToBase64String(ms.GetBuffer(), 0, (int)ms.Length);

        }

        public static string Decrypt(string CypherText, string KEY_64, string IV_64)
        {
            byte[] byKey = System.Text.ASCIIEncoding.ASCII.GetBytes(KEY_64);
            byte[] byIV = System.Text.ASCIIEncoding.ASCII.GetBytes(IV_64);

            byte[] byEnc;
            try
            {
                byEnc = Convert.FromBase64String(CypherText);
            }
            catch
            {
                return null;
            }

            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            MemoryStream ms = new MemoryStream(byEnc);
            CryptoStream cst = new CryptoStream(ms, cryptoProvider.CreateDecryptor(byKey, byIV), CryptoStreamMode.Read);
            StreamReader sr = new StreamReader(cst);
            return sr.ReadToEnd();
        }

        #endregion

        public const string LOGINCOOKIEKEY = "PCINewWebUserID";

        public string GetUserID()
        {
            //記得還要加密哦
            HttpCookie cookie = HttpContext.Current.Request.Cookies[LOGINCOOKIEKEY];
            if (cookie != null && cookie.Value != null)
            {
                try
                {
                    string ret = Decrypt(cookie.Value, _KEY_64, _IV_64);
                    return ret;
                }
                catch(Exception ex)
                {
                    Tool.Trace("解密User Cookie失敗","ex", ex);
                    return null;
                }
            }
            else
                Tool.Trace("No User Cookie Found");

            return null;
        }

        public void SetUserID(string userID, string loginInfo)
        {
            try
            {
                userID = Encrypt(userID, _KEY_64, _IV_64);
            }
            catch
            {
                userID = null;
            }
            HttpCookie loginCookie = new HttpCookie(LOGINCOOKIEKEY, userID);
            loginCookie.HttpOnly = true;
            loginCookie.Path = "/";
            if (loginInfo != null && loginInfo.Trim().Length > 0)
            {
                string[] tmp = loginInfo.Split(new char[] { '|' });
                if (tmp.Length > 0 && tmp[0] == "Forever")
                    loginCookie.Expires = DateTime.Now.AddYears(50);
            }
            HttpContext.Current.Response.AddHeader("P3P", "CP=CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR");
            HttpContext.Current.Response.Cookies.Add(loginCookie);
            //loginInfo(可設定是否永久登錄或暫時或幾十分鐘等)
        }

        public void ClearUserID()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[LOGINCOOKIEKEY];
            if (cookie != null)
            {
                cookie.Expires = DateTime.Now.AddDays(-1);
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
        }

    }


    public class AuthenticateHelper
    {
        public static readonly AuthenticateHelper _instance = new AuthenticateHelper();

        static AuthenticateHelper()
        {
            //其實如果是隻有方法，沒有內部數據時，可以不注冊
            //ObjectFactory.Default.Register(_instance);
        }

        public static AuthenticateHelper Instance
        {
            get
            {
                return _instance;
            }
        }

        List<IAuthenticateModule> _authModules;

        public AuthenticateHelper()
        {
            _authModules = new List<IAuthenticateModule>();
            //因現在不用Session服務了
            //_authModules.Add(new SessionAuthenticateModule());     //用這個可以提高效率(避免每次cookie解密)
            _authModules.Add(new CookieAuthenticateModule());      //用這個可以避免Session過期
        }

        public const string UserIDKey = "_AuthenticateHelper_UserID";
        public const string UserKey = "_AuthenticateHelper_User";
        public const string UserInfoMethod = "UserInfo";

        public string UserID
        {
            get
            {
                return HttpContext.Current.Items[UserIDKey] as string;
            }
        }

        public Dictionary<string, object> GetUserInfo(string userID)
        {
            Dictionary<string, object> ret = null;
            if (userID != null)
            {
                int lastIndex = userID.LastIndexOf('@');
                if (lastIndex > 0)
                {
                    object service = ObjectFactory.Default.Get(userID.Substring(lastIndex + 1));
                    if (service != null)
                    {
                        System.Reflection.MethodInfo met = service.GetType().GetMethod(UserInfoMethod);
                        if (met != null)
                            ret = met.Invoke(service, new object[] { userID.Substring(0, lastIndex) }) as Dictionary<string, object>;
                        else
                            throw new ApplicationException("Service Must Have a UserInfo(string userID) Method(" + UserInfoMethod + ")");
                    }
                    Tool.Trace("service獲取User信息","userID", userID);

                }
                else
                {
                    ret = LoginValider.Instance.UserInfo(userID);
                    Tool.Trace("默認獲取User信息");

                }
            }
            return ret;
        }

        public Dictionary<string, object> User
        {
            get
            {
                 Dictionary<string, object> ret = null;
                //因為登出時會清空Session，所以UserID會重新刷新
                //以后可考慮換成Cache存儲
                 if (HttpContext.Current.Items[UserKey] != null)
                {
                    Tool.Trace("獲取User信息命中緩存");
                    ret = HttpContext.Current.Items[UserKey] as Dictionary<string, object>;
                }
                else
                {
                    ret = GetUserInfo(UserID);

                    if (ret != null)
                        HttpContext.Current.Items[UserKey] = ret;
                }
                Tool.Trace("User名稱", "Name",ret == null || !ret.ContainsKey("Name") ? "null" :ret["Name"]);
                return ret;
            }
        }

        void setUserID(string userID)
        {
            HttpContext.Current.Items[UserIDKey] = userID;
        }

        //臨時設定UserID(如代理)
        public void SetUserID(string userID)
        {
            setUserID(userID);
        }
        /// <summary>
        /// 登錄成功後寫UserID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public void Login(string userID, string loginInfo)
        {
            //Tool.Info("Login Successfully", "userID", userID, "loginInfo", loginInfo ?? "");

            foreach (IAuthenticateModule authModule in _authModules)
                authModule.SetUserID(userID, loginInfo);
            setUserID(userID);
            //緩存有當前User的其它訊息
            //HttpContext.Current.Session.Remove(UserIDKey);
        }

        public void Logout()
        {
            //Tool.Info("User Logout");
            foreach (IAuthenticateModule authModule in _authModules)
                authModule.ClearUserID();
            setUserID(null);
            //HttpContext.Current.Session.Remove(UserIDKey);
        }

        public string Authenticate()
        {
            string userID = null;
            foreach (IAuthenticateModule authModule in _authModules)
            {
                userID = authModule.GetUserID();
                if (userID != null)
                {
                    Tool.Trace("認証User", "authModule.GetType().FullName", authModule.GetType().FullName);
                    break;
                }
            }
            Tool.Trace("認証UserID","UserID", userID == null ? "null" : userID);
            //為null時寫不寫都無所謂，因為HttpContext.Items本來就是for一次Request時才有的
            setUserID(userID);
            return userID;
        }
    }
}