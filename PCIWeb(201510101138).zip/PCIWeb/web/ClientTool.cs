﻿using System;
using System.Data;
using System.Text;
using System.Web;
using System.Collections;
using System.Collections.Generic;
using PCIWeb;
using PCIWeb.Tools;

//不需要權限
public class ClientTool
{
    public ClientTool()
    {

    }

    #region 命令調用

    void checkPermession(ref string cmdName, Dictionary<string, object> args)
    {
        /*
        string objKind = "DBCommand";
        if (RightsProvider.Instance.NoNeedRight(objKind, cmdName))
            return;
        string userID = AuthenticateHelper.Instance.UserID;
        if (!RightsProvider.Instance.HasRight(userID, objKind, cmdName))
        {
            //throw new PCIBusException(userID == null ? "Need Login" : "No Permission");
            if (userID == null)
                throw new PCINeedLoginException(objKind + "." + cmdName);
            else
                throw new PCINoPermissionException(userID + ":" + objKind + "." + cmdName);
        }
        */

        /*
        //WebTest資料庫的procedure暫時不需要權限驗證
        if (cmdName.ToUpper().EndsWith("WEBTEST"))
        {
            return;
        }
        */
        //TODO:數據權限
        string objKind = "DBCommand";
        string objId = cmdName;

        //$pro_web_dept_time_prod@ERP(FEE_FACT)
        //表示帶參數的FEE_FACT,要驗證service權限是$pro_web_dept_time_prod@ERP(FEE_FACT=20A)
        //但是真正還是使用$pro_web_dept_time_prod@ERP查詢
        if (cmdName.IndexOf("(") > 0)
        {
            int argStartIndex = cmdName.IndexOf("(");
            int argEndIndex = cmdName.IndexOf(")");
            string[] cmdDefineArgs = cmdName.Substring(argStartIndex + 1, argEndIndex - argStartIndex - 1).Split(new char[] { ',' });
            StringBuilder cmdWithArgSb = new StringBuilder();
            foreach (string cmdDefineArg in cmdDefineArgs)
                cmdWithArgSb.AppendFormat("{0}{1}={2}", cmdWithArgSb.Length > 0 ? "," : "", cmdDefineArg, args[cmdDefineArg]);
            cmdName = cmdName.Substring(0, cmdName.IndexOf("("));
            objId = cmdName + "(" + cmdWithArgSb.ToString() + ")";
        }
        string userId = AuthenticateHelper.Instance.UserID;
        string userIP = AppEventHanlder.Instance.UserHost;
        bool hasPackagePermission = false;
        if (cmdName.IndexOf("/") > 0 || cmdName.IndexOf(".") > 0)
        {
            //任何一層的dbpackage就算有權限
            string[] packages = cmdName.Replace("/",".").Split(new char[] { '.' });
            string package = "";
            for (int i = 0; i < packages.Length-1; i++)
            {
                package += (i == 0 ? "" : ".") + packages[i];
                if (RightsProvider.Instance.HasServiceRight("DBPackage", package, userIP, userId))
                {
                    hasPackagePermission = true;
                    break;
                }
            }
        }
        if (!hasPackagePermission
            && !RightsProvider.Instance.HasServiceRight(objKind, objId, userIP, userId))
        {
            if (userId == null)
                throw new PCINeedLoginException(objKind + "." + objId);
            else
                throw new PCINoPermissionException(userId + ":" + objKind + "." + objId);
        }

        //暫時寫死MPL報表權限管控，以后如果這種情況有更多，則使用注入模式，動態配置權限規則
        if (objId.ToLower().StartsWith("$pro_mpl"))
        {
            string feeFact = args["P_FEE_FACT"].ToString().Trim();
            if (feeFact == "%" && Current_Fact_No()=="0228")      //PYD暫時只有一個費用廠別，不需要
            {
                bool has20A = false;
                bool has26A = false;
                if (hasFeeFactRights("20A"))
                {
                    has20A = true;
                }
                if (hasFeeFactRights("26A"))
                {
                    has26A = true;
                }
                if(!has20A && !has26A)
                {
                    throw new PCINoPermissionException(userId + ":" + REPORT_RIGHT_KIND + ".20A or 26A");
                }
                if(has20A && has26A)
                {
                    return;
                }
                args["P_FEE_FACT"] = has26A ? "26A" : "20A";
            }
            else
            {
                if (!hasFeeFactRights(feeFact))
                {
                    throw new PCINoPermissionException(userId + ":" + REPORT_RIGHT_KIND + "." + feeFact);
                }
            }
        }


        Tool.Trace("Right_DBCommand", cmdName);
        /*
        string userID = AuthenticateHelper.Instance.UserID;
        if (!RightsProvider.Instance.HasRight(userID, "DBCommand", cmdName))
            throw new ApplicationException(userID == null ? "Need Login" : "No Permission");
        */
    }

    public Dictionary<string, object> QueryPage(string cmdName, Dictionary<string, object> args, string order, int pagesize, int page)
    {
        checkPermession(ref cmdName, args);
        int count;
        DataSet ds = DBHelper.Instance.QueryPage(cmdName, args, order, pagesize, page, out count);
        return Tool.ToDic(new object[] { 
                "Count", count, 
                "Rows", count == 0 ? null : ds.Tables[0].Rows 
            });

    }
    
    public Dictionary<string, object> Query(string cmdName, Dictionary<string, object> args, string order, int pagesize, int page)
    {
        return QueryPage(cmdName, args, order, pagesize, page);
    }

    public Dictionary<string, object> Query(string cmdName, Dictionary<string, object> args)
    {
        checkPermession(ref cmdName, args);
        int count = 0;
        DataSet ds = DBHelper.Instance.Query(cmdName, args);
        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            count = ds.Tables[0].Rows.Count;
        return Tool.ToDic(new object[] { 
                "Count", count, 
                "Rows", count == 0 ? null : ds.Tables[0].Rows 
            });

    }

    public DataSet QueryDataSet(string cmdName, Dictionary<string, object> args)
    {
        checkPermession(ref cmdName, args);
        return DBHelper.Instance.Query(cmdName, args);
    }

    public DataRowCollection QueryRows(string cmdName, Dictionary<string, object> args)
    {
        checkPermession(ref cmdName, args);
        return Tool.ToRows(DBHelper.Instance.Query(cmdName, args));
    }

    public DataRow QueryRow(string cmdName, Dictionary<string, object> args)
    {
        checkPermession(ref cmdName, args);
        return Tool.ToRow(DBHelper.Instance.Query(cmdName, args));
    }

    public object QueryObject(string cmdName, Dictionary<string, object> args)
    {
        checkPermession(ref cmdName, args);
        return DBHelper.Instance.QueryObject(cmdName, args);
    }

    public object ExecuteObject(string cmdName, Dictionary<string, object> args)
    {
        checkPermession(ref cmdName, args);
        return DBHelper.Instance.ExecuteObject(cmdName, args);
    }

    public DataSet ExecuteDataSet(string cmdName, Dictionary<string, object> args)
    {
        checkPermession(ref cmdName, args);
        return DBHelper.Instance.ExecuteDataSet(cmdName, args);
    }

    public int Execute(string cmdName, Dictionary<string, object> args)
    {
        checkPermession(ref cmdName, args);
        ValidateHelper.Instance.Valid(args, cmdName.Replace("/","_"));

        //demo測試
        if(cmdName == "Flow/UpdateStateStatus" && args["FlowNo"].ToString() == "EamMacOut")
        {
            ObjectFactory.Instance.RefreshObject("EamMacOutFlowService");
        }

        //B2B供應商新增,同時設定供應商用戶類型和加入群組
        if (cmdName == "Insert_B2B_USER_VEND@ERP" && args["USER_KIND"].ToString()=="1")
        {
            return addSupplierMember(args);
        }
        else if (cmdName == "Delete_B2B_USER_VEND@ERP" && args["USER_KIND"].ToString() == "1")
        {
            return removeSupplierMember(args);
        }

        //暫時不注入(Kevin 2009.12.30注)
        //ClientToolInjector inj = ObjectFactory.Default.Get<ClientToolInjector>("Inject_" + cmdName);
        //inj.BeforeExecute(cmdName, args);
        int ret= DBHelper.Instance.Execute(cmdName, args);
        //inj.AfterExecute(ret,cmdName, args);


        if (cmdName == "Insert_Base_DataRightRoleMember@Flow")
        {
            int roleID = int.Parse(args["RoleID"].ToString());      //如果是供應商群組,不能在這里新增,因為要設定供應商
            if (roleID == SystemConfig.Instance.Get<int>("PCI_SUPPLIER_ROLE_ID"))
            {
                throw new ApplicationException("請到[用戶查詢]中設定供應商用戶");
            }
            else if (roleID == SystemConfig.Instance.Get<int>("PCI_CUSTOMER_ROLE_ID"))
            {
                string userID = args["UserID"].ToString();
                ServiceCaller.Instance.AddOtherDeal(new string[] { "ClientTool.setAccountKind", "SET_ACCOUNT_KIND_" + userID }, userID, "C");
            }
        }
        else if (cmdName == "Delete_Base_DataRightRoleMember@Flow")
        {
            int roleID = int.Parse(args["RoleID"].ToString());
            if (roleID == SystemConfig.Instance.Get<int>("PCI_SUPPLIER_ROLE_ID"))
            {
                throw new ApplicationException("請到[用戶查詢]中設定供應商用戶");
            }
            if (roleID == SystemConfig.Instance.Get<int>("PCI_CUSTOMER_ROLE_ID"))
            {
                string userID = args["UserID"].ToString();
                ServiceCaller.Instance.AddOtherDeal(new string[] { "ClientTool.setAccountKind", "SET_ACCOUNT_KIND_" + userID }, userID, "E");
            }
        }
        return ret;
    }

    #region 供應商/客戶的account角色設定
    public void setAccountKind(string userID,string kind)
    {
        DBHelper.Instance.Execute("Update_shr_usermail@WebPubP", Tool.ToDic(
            "user_id__W",userID
            ,"kind",kind
            ));
    }

    int addSupplierMember(Dictionary<string, object> b2bUser)
    {
        string userID = b2bUser["USER_NO"].ToString();
        int roleID = SystemConfig.Instance.Get<int>("PCI_SUPPLIER_ROLE_ID");
        int ret = 0;
        try
        {
            ret = DBHelper.Instance.Execute("Insert_Base_DataRightRoleMember@Flow", Tool.ToDic(
                "RoleID", roleID
                , "UserID", userID));
        }
        catch (Exception ex)
        {
            //因為采購可以對應多個品牌，所以這里忽略這個pk重複的異常
            if (ex.Message.IndexOf("constraint 'PK_BASE_DATARIGHTROLEMEMBER'") < 0)
                throw;

        }
        ServiceCaller.Instance.AddOtherDeal(new string[] { "ClientTool.setAccountKind", "SET_ACCOUNT_KIND_" + userID }, userID, "S");
        ServiceCaller.Instance.AddOtherDeal(new string[] { "ClientTool.setB2BSupplierUser", "SET_ACCOUNT_KIND_" + userID }, b2bUser);
        return ret;
    }

    int removeSupplierMember(Dictionary<string, object> b2bUser)
    {
        string userID = b2bUser["USER_NO"].ToString();
        int roleID = SystemConfig.Instance.Get<int>("PCI_SUPPLIER_ROLE_ID");
        int ret = DBHelper.Instance.Execute("Delete_Base_DataRightRoleMember@Flow", Tool.ToDic(
            "RoleID", roleID
            , "UserID", userID));
        ServiceCaller.Instance.AddOtherDeal(new string[] { "ClientTool.setAccountKind", "SET_ACCOUNT_KIND_" + userID }, userID, "E");
        ServiceCaller.Instance.AddOtherDeal(new string[] { "ClientTool.deleteB2BSupplierUser", "SET_ACCOUNT_KIND_" + userID }, b2bUser);
        return ret;
    }

    public void setB2BSupplierUser(Dictionary<string, object> b2bUser)
    {
        DBHelper.Instance.Execute("Insert_B2B_USER_VEND@ERP", b2bUser);
    }

    public void deleteB2BSupplierUser(Dictionary<string, object> b2bUser)
    {
        DBHelper.Instance.Execute("Delete_B2B_USER_VEND@ERP", b2bUser);
    }

    #endregion

    public object ExecuteOutput(string cmdName, string name, Dictionary<string, object> args)
    {
        checkPermession(ref cmdName, args);
        ValidateHelper.Instance.Valid(args, cmdName.Replace("/", "_"));
        //args.Add("__OutputParams", "");
        DBHelper.Instance.SetOutputParams(args);
        //ClientToolInjector inj = ObjectFactory.Default.Get<ClientToolInjector>("Inject_" + cmdName);
        //inj.BeforeExecute(cmdName, args);
        int ret = DBHelper.Instance.Execute(cmdName, args);
        //inj.AfterExecute(ret, cmdName, args);
        //object o = (args["__OutputParams"] as Dictionary<string, object>)[name];
        object o = (DBHelper.Instance.GetOutputParams(args))[name];

        return o;
    }

    #endregion

    #region 登錄，用戶，權限相關

    public string Login(string account, string password, string loginInfo)
    {
        string ret = LoginHelper.Instance.Login(account, password, loginInfo);
        //因為要和EFP，舊的.net1.1（pusat簽核系統）作sso,那些地方只支持賬號密碼sso登錄，所以要將賬號密碼加密成cookie保存到用戶端，方便下次sso登錄
        if (ret != null && ret.Substring(0, 1) == "1")
        {
            recordLogin(account, password, loginInfo);
        }
        return ret;
    }

    //1.放在這里要考慮SSOLoginHelper登錄的，不能再次sso登錄?kevin.zou 2013.2.6注(可以改到到LoginHelper里去實現)
    //2.用SSO直接登錄，即沒有賬號密碼那種，對于有些如efp，舊的簽核都不能支持sso登錄
    #region 為SSO準備的賬號記錄

    /// <summary>
    /// 簡單UTF8編碼
    /// </summary>
    /// <param name="src"></param>
    /// <returns></returns>
    public static string ByteEncode(string src)
    {
        byte[] bytes = System.Text.Encoding.UTF8.GetBytes(src);
        return BitConverter.ToString(bytes);
    }


    /// <summary>
    /// 簡單UTF8解碼
    /// </summary>
    /// <param name="src"></param>
    /// <returns></returns>
    public static string ByteDecode(string src)
    {
        try
        {
            byte[] bytes = getBytesFromString(src);
            return System.Text.Encoding.UTF8.GetString(bytes);
        }
        catch
        {
            return "";
        }
    }

    /// <summary>
    /// 將字符串形式的byte,轉成真正的byte類型
    /// </summary>
    /// <param name="bytes"></param>
    /// <returns></returns>
    static byte[] getBytesFromString(string bytes)
    {
        string[] strBytes = bytes.Split(new char[] { '-' });
        byte[] ret = new byte[strBytes.Length];
        int i = 0;
        foreach (string b in strBytes)
            ret[i++] = Convert.ToByte(b, 16);
        return ret;
    }


    const string SSOLOGINCOOKIEKEY = "PCINewWebUser";
    const string _KEY_64 = "a5G-8=Jk"; //必須是8個字符（64Bit)
    const string _IV_64 = "JKbN=6[?";  //必須是8個字符（64Bit)

    void recordLogin(string account, string password, string loginInfo)
    {
        string fromStr = ByteEncode(account) + "@" + ByteEncode(password);
        string toStr = PCIWeb.CookieAuthenticateModule.Encrypt(fromStr, _KEY_64, _IV_64);
        HttpCookie loginCookie = new HttpCookie(SSOLOGINCOOKIEKEY, toStr);
        loginCookie.HttpOnly = true;
        loginCookie.Path = "/";
        if (loginInfo != null && loginInfo.Trim().Length > 0)
        {
            string[] tmp = loginInfo.Split(new char[] { '|' });
            if (tmp.Length > 0 && tmp[0] == "Forever")
                loginCookie.Expires = DateTime.Now.AddYears(50);
        }
        HttpContext.Current.Response.AddHeader("P3P", "CP=CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR");
        HttpContext.Current.Response.Cookies.Add(loginCookie);
        //loginInfo(可設定是否永久登錄或暫時或幾十分鐘等)
    }

    public string[] GetRecordLogin()
    {
        Dictionary<string, object> user = AuthenticateHelper.Instance.User;
        if(user["SSO_PWD"].ToString().Length>0)
            return new string[]{user["Account"].ToString(),"-SSO-" + user["SSO_PWD"].ToString()};
        //記得還要加密哦
        HttpCookie cookie = HttpContext.Current.Request.Cookies[SSOLOGINCOOKIEKEY];
        if (cookie != null && cookie.Value != null)
        {
            try
            {
                string str = PCIWeb.CookieAuthenticateModule.Decrypt(cookie.Value, _KEY_64, _IV_64);
                string[] ret = str.Split(new char[] { '@' }, 2);
                return new string[]{
                    ByteDecode(ret[0])
                    ,ByteDecode(ret[1])
                };
            }
            catch (Exception ex)
            {
                Tool.Trace("解密Login Cookie失敗", "ex", ex);
                return null;
            }
        }
        else
            Tool.Trace("No Login Cookie Found");
        return null;
    }

    public void ClearRecordLogin()
    {
        HttpCookie cookie = HttpContext.Current.Request.Cookies[SSOLOGINCOOKIEKEY];
        if (cookie != null)
        {
            cookie.Expires = DateTime.Now.AddDays(-1);
            HttpContext.Current.Response.Cookies.Add(cookie);
        }
    }

    #endregion

    public void Logout()
    {
        LoginHelper.Instance.Logout();
        ClearRecordLogin();
    }

    public Dictionary<string, object> User()
    {
        //同步調用也是會引發Error事件的
        //throw new ApplicationException("Test Application Exception");
        return AuthenticateHelper.Instance.User;
    }

    public List<Dictionary<string, object>> Programs()
    {
        return ProgramsHelper.Instance.Programs();
    }

    public Dictionary<string, bool> HasMenuRight(ArrayList menus)
    {
        Dictionary<string, bool> ret = new Dictionary<string, bool>();
        foreach (int menuId in menus)
        {
            ret[menuId.ToString()] = RightsProvider.Instance.HasDataRight("Menu", menuId.ToString());
        }
        return ret;
    }

    public bool HasRight(string kind, string objectID)
    {
        return RightsProvider.Instance.HasRight(AuthenticateHelper.Instance.UserID, kind, objectID);
    }

    public bool HasServiceRight(string kind, string objectID)
    {
        return RightsProvider.Instance.HasServiceRight( kind, objectID,AppEventHanlder.Instance.UserHost,AuthenticateHelper.Instance.UserID);
    }

    /// <summary>
    /// 另一個RIAService(主服務)已登錄，現在這支程式用主服務的登錄UserID登錄當前的RIAService
    /// B2B的三區整合:統一在PCI登錄，然後再登錄到PYD,PGS的RIAService，以便client程式可同時使用這三個服務
    /// 1.首先主服務登錄成功(eip.pci.co.id/RIAService)
    /// 2.client程式調用主服務的ClientTool.LoginRemote，得到一個登錄令牌
    /// 3.client程式用這個登錄令牌調用遠程RIAService(eip.gsid.co.id/RIAService)的LoginByAnotherRIAService，并且告知是是哪個主登錄服務(objectID)登錄的
    /// 4.遠程RIAService根據objectID，識別主服務，調用主服務的webservice,LoginAsKey，驗證key的有效性，并得到UserID
    /// 5.使用這個UserID登錄當前服務
    /// </summary>
    /// <param name="key"></param>
    /// <param name="objectID"></param>
    /// <returns></returns>
    public void LoginByAnotherRIAService(string key,string objectID)
    {
        string errMsg = "";
        Dictionary<string, object> ret = PCIWeb.ServiceCaller.Instance.CallToDic(
                PCIWeb.ServiceCaller.CallType.BaseCall, objectID + ".LoginAsKey",key);
        if (ret["AjaxError"].ToString() == "0")
        {
            if (ret["Result"] == null || ret["Result"].ToString().Trim().Length==0)
            {
                errMsg = "[Login Fail]key is not found";
            }
            else
            {
                string userID = ret["Result"].ToString();
                AuthenticateHelper.Instance.Login(userID, "");      //遠程登錄成功
                Tool.Info("Remote RIAService Login Successfully", "objectID", objectID, "userID", userID);
            }
        }
        else
        {
            errMsg = "[Login Call Fail]" + ret["Message"].ToString().Trim();
        }
        if (errMsg.Length > 0)
        {
            throw new ApplicationException(errMsg);
            //Tool.Error("Remote RIAService Login Fail", "error", errMsg);
        }
    }

    public string LoginRemote()
    {
        if (PCIWeb.AuthenticateHelper.Instance.UserID != null)
        {
            Guid gd = Guid.NewGuid();
            HttpRuntime.Cache.Insert("LoginService" + gd.ToString(), PCIWeb.AuthenticateHelper.Instance.UserID);
            return gd.ToString();
        }
        return null;
    }

    public string RemoteAskLogin(string key)
    {
        string userKey = "LoginService" + key;
        object o = HttpRuntime.Cache[userKey];
        if (o != null)
        {
            HttpRuntime.Cache.Remove(userKey);
            return o.ToString();
        }
        return "";
    }

    public void RecordMenuAccess(int menuID)
    {
        DBHelper.Instance.ClearDefaultTran();
        HttpBrowserCapabilities bc = HttpContext.Current.Request.Browser;
        string refUrl = HttpContext.Current.Request.UrlReferrer == null ? "" : HttpContext.Current.Request.UrlReferrer.ToString();
        if (refUrl.Length > 500)
            refUrl = refUrl.Substring(0, 500);
        Dictionary<string,object> args =  Tool.ToDic(
                            "USER_ID", AuthenticateHelper.Instance.UserID
                            , "MENU_ID", menuID
                            , "RECORD_TIME", DateTime.Now.ToString("yyyyMMddHHmmss")
                            , "USER_IP", AppEventHanlder.Instance.UserHost
                            , "REF_URL", refUrl
                            , "BROWSER", bc.Browser
                            , "VERSION", bc.Version
                            , "PLATFORM", bc.Platform
                            , "AGENT",HttpContext.Current.Request.UserAgent
                            );
        DBHelper.Instance.NoLogResult(args);
        //DBHelper.Instance.NoUseDefaultTran(args);
        DBHelper.Instance.Execute("Insert_USER_MENU_RECORD@Flow",args);
    }

    //public Dictionary<string, object> Programs(string sys)
    //{
    //    return ProgramsHelper.Instance.Programs(sys + ".js");
    //}

    #endregion

    #region 驗證

    public void Valid(Dictionary<string, object> validObj, string validName)
    {
        ValidateHelper.Instance.Valid(validObj, validName);
    }

    #endregion

    #region 其它

    public string Day(int fromToday)
    {
        return DateTime.Now.AddDays(fromToday).ToString("yyyyMMdd");
    }

    public string Lang()
    {
        HttpCookie cookie = HttpContext.Current.Request.Cookies[LANGCOOKIEKEY];
        if (cookie != null && cookie.Value != null)
        {
            return cookie.Value;
        }
        return "";
        //TODO:未登錄,找cookie，可能沒有，則使用流覽器默認
        //if (AuthenticateHelper.Instance.UserID == null)
        //{

        //}
        //else
        //{

        //}
    }

    public void DynamicCall(string serviceId,string serviceType,object[] initArgs,string method, params object[] args)
    {
        //暫時不做這個
        //雖然動態service很方便,但無論初始化參數寫死,以及調用的復雜,都讓它不如直接新建service,畢竟面向對象本身就是這樣創建對象的
    }

    const string LANGCOOKIEKEY = "PCINewWebLang";
    public void SetLang(string lang)
    {
        HttpCookie langCookie = new HttpCookie(LANGCOOKIEKEY, lang);
        langCookie.Path = "/";
        langCookie.Expires = DateTime.Now.AddYears(50);
        HttpContext.Current.Response.AddHeader("P3P", "CP=CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR");
        HttpContext.Current.Response.Cookies.Add(langCookie);
    }

    #endregion


    #region 給客戶端UI用的配置

    public string Current_Fact_No()
    {
        return SystemConfig.Instance.Get<string>("Current_Fact_No");
    }

    public string User_IP()
    {
        return PCIWeb.AppEventHanlder.Instance.UserHost;
    }

    public ArrayList Das_Items()
    {
        return SystemConfig.Instance.Get<ArrayList>("Das/Config.js", "Das_Items");
    }

    public string Now()
    {
        return DateTime.Now.ToString("yyyyMMddHHmmssfff");
    }

    #endregion

    #region 報表權限

    bool isSuperManager(string userID)
    {
        if (userID != null)
        {
            ArrayList managers = SystemConfig.Instance.Get<ArrayList>("SuperManager");
            return managers.IndexOf(userID) >= 0;
        }
        return false;
    }

    string REPORT_RIGHT_KIND = "REPORT";         //報表權限的權限類別是REPORT

    bool hasFeeFactRights(string feeFact)
    {
        string userID = AuthenticateHelper.Instance.UserID;
        return isSuperManager(userID) || RightsProvider.Instance.HasDataRight(userID, REPORT_RIGHT_KIND, feeFact);
    }


    public List<DataRow>[] RightsFeeFactsBrandFact()
    {
        List<DataRow>[] rets = new List<DataRow>[2];
        DataSet ds = DBHelper.Instance.Query("MPL/FeefactNew", null);
        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            List<DataRow> ret1 = new List<DataRow>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                string feeFact = dr["FEE_FACT"].ToString().Trim();
                if (hasFeeFactRights(feeFact))
                {
                    ret1.Add(dr);
                }
            }
            if (ret1.Count == 0)
            {
                return null;
            }
            List<DataRow> ret2 = new List<DataRow>();
            foreach (DataRow dr in ds.Tables[1].Rows)
            {
                string feeFact = dr["FEE_FACT"].ToString().Trim();
                if (hasFeeFactRights(feeFact))
                {
                    ret2.Add(dr);
                }
            }
            if (ret2.Count == 0)
            {
                return null;
            }
            return new List<DataRow>[] { ret1, ret2 };
        }
        return null;
    }

    #endregion

    #region 上傳文件
    /*

    public string SaveUploadTest()
    {
        string path = System.Web.HttpContext.Current.Request.PhysicalApplicationPath
                    + "\\upload\\files\\Test\\";

        HttpFileCollection files = HttpContext.Current.Request.Files;
        if (files.Count > 0)
        {
            string extension = System.IO.Path.GetExtension(files[0].FileName);


            string filePath = DateTime.Now.ToString("yyyyMMddHHmmssfff") + "_" + Guid.NewGuid().ToString() + extension;
            files[0].SaveAs(path + filePath);
            return filePath;
        }
        else
            throw new ApplicationException("No File Upload found");
    }

    //用Session存儲，保證后面的ajax請求時，file一定上傳完畢
    public void UploadTmp(string jsonKey)
    {
        HttpFileCollection files = HttpContext.Current.Request.Files;
        string cacheKey = HttpContext.Current.Request.UserHostAddress + "_" + jsonKey;          //IP
        //HttpContext.Current.Cache[cacheKey] = files;

        HttpRuntime.Cache.Insert(cacheKey, files
            , null
            , System.Web.Caching.Cache.NoAbsoluteExpiration
            , new TimeSpan(0, 2, 0)         //2分鐘自動刪除(也就是說5分鐘之內必須完成所有包的傳送)
            , System.Web.Caching.CacheItemPriority.Default
            , null
        );
    }

    public static HttpFileCollection GetUploadTmp()
    {
        string jsonKey = HttpContext.Current.Request["JsonKey"];
        if (jsonKey != null && jsonKey.Length > 0)
        {
            string cacheKey = HttpContext.Current.Request.UserHostAddress + "_" + jsonKey;          //IP
            HttpFileCollection ret = HttpRuntime.Cache[cacheKey] as HttpFileCollection;
            HttpRuntime.Cache.Remove(cacheKey);
            return ret;
        }
        return null;
    }
    */
    #endregion



}