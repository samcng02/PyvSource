using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Data;
using PCIWeb;
using PCIWeb.Tools;
using PCIWeb.Message;

namespace SmsService
{

    public class SmsUITask
    {
        Dictionary<string, ISmsUI> _smsUIList = new Dictionary<string, ISmsUI>();
        PCIWeb.Tools.SmsSender _sender = PCIWeb.Tools.SmsSender.Instance;
        //int _expiredHour = 24;                                               //24�p�ɦZ²�T�L��

        public SmsUITask(ArrayList smsUIList)
        {
            foreach (string smsUIID in smsUIList)
            {
                _smsUIList.Add(smsUIID, ObjectFactory.Default.Get<ISmsUI>(smsUIID));
            }
        }

        //�o��user���Ѥ��ΦA�o�F
        List<string> getIgnoreUsers()
        {
            List<string> ret = new List<string>();
            DataSet ds = DBHelper.Instance.Query("SMS/GetSendingTask", null);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    ret.Add(dr["USERID"].ToString().Trim());
                }
            }
            return ret;
        }

        List<string> getIgnoreTask(string userID)
        {
            List<string> ret = new List<string>();
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                //�b�̪�7�Ѩ�user����o�i��@�L�������A�~���|�Vuser�~��o�o�i����
                //�H�קK�Ӧh����Ƽ��X�Ӥ���A�v�T�Ĳv
                "SUBTIME" , DateTime.Now.AddDays(-7).ToString("yyyyMMddHHmmss")
            });
            if (userID != null)
                args.Add("USERID", userID);
            DataSet ds = DBHelper.Instance.Query("SMS/GetIgnoreTask", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    ret.Add(dr["KEY"].ToString().Trim());
                }
            }
            return ret;
        }

        void expiredTask()
        {
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "TODAYZERO",DateTime.Now.ToString("yyyyMMdd") + "000000"
                ,"NOW",DateTime.Now.ToString("yyyyMMddHHmmss")
            });
            //DBHelper.Instance.NoLogResult(args);
            DBHelper.Instance.Execute("SMS/ExpireTask", args);
        }

        void addTask(string smsUIId, SmsTask task)
        {

            DataSet ds = DBHelper.Instance.Query("SMS/GetUserByPhone", Tool.ToDic(new object[]{
                "user_id",task.User
            }));

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["tel_no"] != DBNull.Value)
                {
                    string phone = ds.Tables[0].Rows[0]["tel_no"].ToString().Trim();
                    if (phone.Length > 0)
                    {
                        //�s�W
                        DBHelper.Instance.Execute("Insert_WEB_SMS_TASK@ERP",
                            Tool.ToDic(new object[]{
                                "TASKID",IdGenerator.Instance.NextNo("SMSTASK")
                                ,"USERID",task.User
                                ,"SERVICE",smsUIId
                                ,"CONTENT",task.Content
                                ,"KEY",task.Key
                                ,"ADDTIME",DateTime.Now.ToString("yyyyMMddHHmmss")
                                //,"EXPIREDTIME",DateTime.Now.AddHours(_expiredHour).ToString("yyyyMMddHHmmss")
                                ,"STATUS","SENDING"
                                ,"PHONE",phone
                            })
                        );

                        string content = task.Content += "\n�Цb���Ѥ��^��\n�^��R���������}���o�U�@��";
                        //�o�e²�T(TODO)
                        _sender.Send(phone, "", content, "SmsTask", smsUIId);

                    }
                }

            }
        }

        void finishTask(string taskID, string status, string content, string retInfo)
        {
            DBHelper.Instance.Execute("SMS/FeedbackTask", Tool.ToDic(new object[]{
                "RECTIME",DateTime.Now.ToString("yyyyMMddHHmmss")
                ,"RECCONTENT",content
                ,"RECRESULT",retInfo
                ,"STATUS",status
                ,"TASKID",taskID
            }));
        }

        //Job Run(�C5�����@��)
        public void RunJob()
        {
            expiredTask();

            List<string> ignoreUsers = getIgnoreUsers();
            List<string> ignoreTask = getIgnoreTask(null);
            foreach (string smsUIId in _smsUIList.Keys)
            {
                ISmsUI ui = _smsUIList[smsUIId];
                Dictionary<string, SmsTask> userTask = ui.GetAllTask(ignoreUsers, ignoreTask);
                foreach (string user in userTask.Keys)
                {
                    ignoreUsers.Add(user);      //�[�J�����A�U�@�ӴN���άd�o��user�F
                    addTask(smsUIId, userTask[user]);
                }
            }
        }

        DataRow getUserTask(string userID)
        {
            DataSet ds = DBHelper.Instance.Query("SMS/GetSendingTask", Tool.ToDic(new object[]{
                "USERID",userID
            }));
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                return ds.Tables[0].Rows[0];
            return null;
        }

        public bool isMatch(string userID)
        {
            return getUserTask(userID) != null;
        }

        //�Ȯɤ��a�o�Ӯ��U�@��task
        //������job����task
        /*
        void autoFillNextTask(string userID)
        {
            List<string> ignoreTask = getIgnoreTask(userID);
            foreach (ISmsUI ui in _smsUIList.Values)
            {
                SmsTask userTask = ui.GetUserTask(userID, ignoreTask);
                if (userTask != null)
                {
                    addTask(userTask);
                    break;
                }
            }
        }
        */

        public void DealTask(string content, string telNo, string userID, string[] otherInfo)
        {
            DataRow taskDr = getUserTask(userID);
            string sendMsg = null;
            Exception throwEx = null;
            if (taskDr != null)
            {
                string status;
                string retInfo;
                string taskID = taskDr["TASKID"].ToString();
                //�e�m�B�z(��������)
                if (content.Trim().ToUpper() == "R")
                {
                    status = "IGNORE";
                    retInfo = "����";
                }
                else
                {
                    string service = taskDr["SERVICE"].ToString();
                    ISmsUI ui = _smsUIList[service];
                    try
                    {
                        bool isFinish;
                        sendMsg = retInfo = ui.DealTask(userID, content, taskDr["KEY"].ToString(), out isFinish);
                        status = isFinish ? "FINISH" : "SENDING";

                    }
                    catch (PCIBusException ex)
                    {
                        status = "SENDING";     //user�X���ɥi�A���^��
                        retInfo = ex.Message;
                        sendMsg = ex.Message;// "�t�γB�z���~�A���b���@�t�ΡA�еy��";
                    }
                    catch (Exception ex)
                    {
                        throwEx = ex;
                        status = "SENDING";     //�t�ΥX��,�]pending���A�_�huser�@����²�T
                        retInfo = ex.Message;
                        sendMsg = "�B�z���`�]��ڥi��w�Qñ�֡A�еn���t�άd�ߡ^";
                    }
                }
                //��s���A(TODO)                    
                finishTask(taskID, status, content, retInfo);
            }
            else
                sendMsg = "�S���ݳB�z�����ȩΥ��Ȥw�L��";
            if (sendMsg != null)
            {
                //�o�e²�T(TODO)
                _sender.Send(telNo, "", sendMsg, "SmsTask", "DealReply");
                //�o�e²�T(TODO)
            }
            if (throwEx != null)
                throw throwEx;      //�W�@�h�|�B�z���Acatch all Exception�A���ξ�߷|rollback
        }

    }

}