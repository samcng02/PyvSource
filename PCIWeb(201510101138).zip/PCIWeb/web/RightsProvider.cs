﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Web;
using PCIWeb.Tools;

namespace PCIWeb
{

    public class RightsProvider
    {

        public static RightsProvider Instance
        {
            get
            {
                return ObjectFactory.Instance.Get<DBRightsProvider>();//DBRightsProvider.Instance;// new RightsProvider();//
            }
        }

        public RightsProvider()
        {
            // _ttc = new FileConfig("RightsProvider", new TextTableParser());
        }

        bool hasRight(string ownerKind, string ownerID, string objKind, string objID, bool isLogin)
        {
            string key = ownerKind + "_" + objKind;
            DataTable dt = _ttc.Parse<DataTable>(key);
            if (dt == null)
                Tool.Trace("未配置Config:{0}", key);
            else
            {
                DataRow[] drs;

                //不需要權限(所有人皆可訪問)
                drs = dt.Select(string.Format(
                     "{0} = '?' and Object in ('{1}','*')"
                     , ownerKind, objID));
                if (drs != null && drs.Length > 0)
                {
                    Tool.Trace("所有人皆可訪問");
                    return true;
                }

                if (isLogin)
                {
                    //登錄之後可訪問
                    drs = dt.Select(string.Format(
                         "{0} = '*' and Object in ('{1}','*')"
                         , ownerKind, objID));
                    if (drs != null && drs.Length > 0)
                    {
                        Tool.Trace("所有已登錄用戶皆可訪問");
                        return true;
                    }
                }

                if (ownerID != null && ownerID != "")
                {

                    drs = dt.Select(string.Format(
                         "{0} in('{1}') and Object in ('{2}','*')"
                         , ownerKind, ownerID.Replace(",", "','"), objID));
                    if (drs != null && drs.Length > 0)
                    {
                        Tool.Trace("以{0}({1})可訪問", ownerKind, ownerID);
                        return true;
                    }
                }
            }
            return false;
        }

        string getRoles(string userID)
        {
            string ret = null;
            if (userID != null)
            {
                DataTable userRoleDt = _ttc.Parse<DataTable>("User_Role");
                if (userRoleDt != null)
                {
                    //找出角色，進行轉換
                    DataRow[] roleDrs = userRoleDt.Select(string.Format(
                          "User='{0}'", userID));
                    if (roleDrs != null && roleDrs.Length > 0)
                    {
                        StringBuilder sb = new StringBuilder();
                        foreach (DataRow roleDr in roleDrs)
                            sb.AppendFormat("{0}{1}", sb.Length > 0 ? "," : "", roleDr["Role"].ToString());
                        ret = sb.ToString();
                    }
                }
            }
            return ret;
        }

        IConfig _ttc = null;

        /// <summary>
        /// 隻能以群組設置權限
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="kind"></param>
        /// <param name="objID"></param>
        /// <returns></returns>
        public virtual bool HasRight(string userId, string kind, string objID)
        {
            //if(_ttc==null)
            //    _ttc = new FileConfig("RightsProvider", new TextTableParser()); 
            bool ret = hasRight("User", userId, kind, objID, userId != null);
            if (!ret)
            {
                string roles = getRoles(userId);
                ret = hasRight("Role", roles, kind, objID, userId != null);
            }
            return ret;
        }

        void getUsers(List<string> ret, string roleID)
        {
            DataTable userRoleDt = _ttc.Parse<DataTable>("User_Role");
            if (userRoleDt != null)
            {
                //找出角色，進行轉換
                DataRow[] roleDrs = userRoleDt.Select(string.Format(
                      "Role='{0}'", roleID));
                if (roleDrs != null && roleDrs.Length > 0)
                {
                    foreach (DataRow roleDr in roleDrs)
                    {
                        string user = roleDr["User"].ToString();
                        if (!ret.Contains(user))
                            ret.Add(user);
                    }
                }
            }
        }

        void getRightsOwner(List<string> ret, string ownerKind, string kind, string objectID, bool allRightsContain)
        {
            string key = ownerKind + "_" + kind;
            DataTable dt = _ttc.Parse<DataTable>(key);
            if (dt != null)
            {
                //不需要權限(所有人皆可訪問)
                DataRow[] drs = dt.Select(string.Format(
                     "Object in ('{0}'{1})"
                     , objectID, allRightsContain ? ",'*'" : ""));
                if (drs != null && drs.Length > 0)
                {
                    foreach (DataRow dr in drs)
                    {
                        string owner = dr[ownerKind].ToString();
                        if (!ret.Contains(owner))
                            ret.Add(owner);
                    }
                }
            }
        }

        //含所有權限判斷(不包括所有用戶有權限的判斷)
        public virtual List<string> RightsOwner(string kind, string objectID, bool allRightsContain)
        {
            List<string> ret = new List<string>();
            getRightsOwner(ret, "User", kind, objectID, allRightsContain);
            List<string> roles = new List<string>();
            getRightsOwner(roles, "Role", kind, objectID, allRightsContain);
            foreach (string role in roles)
                getUsers(ret, role);
            return ret;
        }

        public virtual bool HasAllRight(string kind, string userID)
        {
            return HasRight(userID, kind, "*");
        }

        void getRightsData(List<string> ret, string ownerKind, string kind, string ownerID)
        {
            string key = ownerKind + "_" + kind;
            DataTable dt = _ttc.Parse<DataTable>(key);
            if (dt != null)
            {
                //不需要權限(所有人皆可訪問)
                DataRow[] drs = dt.Select(string.Format(
                     "{0} = '{1}'"
                     , ownerKind, ownerID));
                if (drs != null && drs.Length > 0)
                {
                    foreach (DataRow dr in drs)
                    {
                        string data = dr["Object"].ToString();
                        if (!ret.Contains(data))
                            ret.Add(data);
                    }
                }
            }
        }

        public virtual List<string> RightsData(string kind, string userID)
        {
            List<string> ret = new List<string>();
            getRightsData(ret, "User", kind, userID);
            string rolestr = getRoles(userID);
            if (rolestr != null && rolestr.Trim().Length > 0)
            {
                string[] roles = rolestr.Trim().Split(new char[] { ',' });
                foreach (string role in roles)
                    getRightsData(ret, "Role", kind, role);
            }
            return ret;

        }

        //是否可以匿名訪問
        public virtual bool NoNeedRight(string objKind, string objID)
        {
            string ownerKind = "Role";
            string key = ownerKind + "_" + objKind;
            DataTable dt = _ttc.Parse<DataTable>(key);
            if (dt != null)
            {
                DataRow[] drs;
                //不需要權限(所有人皆可訪問)
                drs = dt.Select(string.Format(
                     "{0} = '?' and Object in ('{1}','*')"
                     , ownerKind, objID));
                if (drs != null && drs.Length > 0)
                    return true;
            }

            ownerKind = "User";
            key = ownerKind + "_" + objKind;
            dt = _ttc.Parse<DataTable>(key);
            if (dt != null)
            {
                DataRow[] drs;
                //不需要權限(所有人皆可訪問)
                drs = dt.Select(string.Format(
                     "{0} = '?' and Object in ('{1}','*')"
                     , ownerKind, objID));
                if (drs != null && drs.Length > 0)
                    return true;
            }
            return false;
        }

        public DataRowCollection[] GetRights(string leftCmd, string idField, string rightKind)
        {
            DataRowCollection objectDrs = null;
            DataRowCollection userDrs = null;

            DataSet ds = DBHelper.Instance.Query(leftCmd, null);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                objectDrs = ds.Tables[0].Rows;

                List<string> allUsers = new List<string>();
                string ownerStr = "";
                if (!ds.Tables[0].Columns.Contains("RightOwners"))
                    ds.Tables[0].Columns.Add("RightOwners", typeof(List<string>));
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string objId = dr[idField].ToString();
                    List<string> owners = RightsOwner(rightKind, objId, true);
                    dr["RightOwners"] = owners;
                    if (owners != null && owners.Count > 0)
                    {
                        foreach (string owner in owners)
                        {
                            if (!allUsers.Contains(owner))
                            {
                                allUsers.Add(owner);
                                ownerStr += (ownerStr.Length > 0 ? "," : "") + owner;
                            }
                        }
                    }
                }
                if (ownerStr.Length > 0)
                {
                    DataSet ds2 = DBHelper.Instance.Query("Common_Users_Query", Tool.ToDic(new object[]{
                        "UsersID", ownerStr
                    }));
                    if (ds2 != null && ds2.Tables.Count > 0 && ds2.Tables[0].Rows.Count > 0)
                        userDrs = ds2.Tables[0].Rows;

                }
            }
            return new DataRowCollection[] { objectDrs, userDrs };
        }

        public virtual bool HasAllDataRight(string rightKind, string userID)
        {
            return false;
        }

        public virtual bool HasDataRight(string userID, string rightKind, string objectID)
        {
            return false;
        }

        public virtual bool HasDataRight(string rightKind, string objectID)
        {
            return false;
        }

        public virtual List<string> DataRightsData(string rightKind, string userID)
        {
            return null;
        }

        public virtual List<string> DataRightsOwner(string rightKind, string objectID)
        {
            return null;
        }

        public virtual bool HasServiceRight(string kind, string service, string userIP, string userID)
        {
            return false;
        }

        public virtual void CheckServiceRight(string objKind, string objId)
        {
            throw new ApplicationException("Not supported");
        }

    }

    public class ProgramsHelper
    {
        public static readonly ProgramsHelper Instance = new ProgramsHelper();

        FileConfig _config;

        private ProgramsHelper()
        {
            _config = new FileConfig("Programs", new JsonParser());
        }

        public List<Dictionary<string, object>> Programs()
        {
            return Programs(AuthenticateHelper.Instance.UserID);
        }

        public List<Dictionary<string, object>> Program(string app)
        {
            List<Dictionary<string, object>> ret = new List<Dictionary<string, object>>();
            Dictionary<string, object> item = getSysPrograms(app, AuthenticateHelper.Instance.UserID);
            if (item != null)
            {
                ret.Add(item);
            }
            return ret;
        }

        public List<Dictionary<string, object>> Programs(string userID)
        {
            List<string> allsys = _config.Items();
            if (allsys != null)
            {
                List<Dictionary<string, object>> ret = new List<Dictionary<string, object>>();
                foreach (string sys in allsys)
                {
                    Dictionary<string, object> item = getSysPrograms(sys, userID);
                    if (item != null)
                        ret.Add(item);
                }
                return ret;
            }
            return null;
        }


        public string JsonPrograms()
        {
            return JsonPrograms(AuthenticateHelper.Instance.UserID);
        }

        public string JsonPrograms(string userID)
        {
            return Tool.ToJson(Programs(userID));
        }

        void parseItems(Dictionary<string, object> item, string userID)
        {
            if (item.ContainsKey("items"))
            {
                ArrayList subItems = item["items"] as ArrayList;
                ArrayList newSubItems = new ArrayList();
                foreach (Dictionary<string, object> subItem in subItems)
                {
                    if (hasRight(subItem, userID))
                    {
                        parseItems(subItem, userID);
                        newSubItems.Add(subItem);
                    }
                }
                if (newSubItems.Count > 0)
                    item["items"] = newSubItems;
                else
                    item.Remove("items");
            }
        }

        bool hasRight(Dictionary<string, object> item, string userID)
        {
            bool ret = false;
            if (item.ContainsKey("__rights"))
                return (bool)item["__rights"];
            else if (item.ContainsKey("permission"))        //本身有，算本身
            {
                string str = item["permission"].ToString();
                if (str == "All")
                    ret = true;
                else if (str == "User" && userID != null)
                    ret = true;
                else
                {
                    if (str.IndexOf(",") > 0)
                    {
                        string objKind = str.Substring(0, str.IndexOf(","));
                        string objID = str.Substring(str.IndexOf(",") + 1);
                        //ret = RightsProvider.Instance.HasRight(userID, objKind, objID);
                        ret = RightsProvider.Instance.HasServiceRight(objKind, objID, AppEventHanlder.Instance.UserHost, userID);

                        //如果是ajax的方法，則還要判斷service.*是否有權限(這也算是有權限)
                        /*
                        if (!ret && objKind.ToLower() == "ajax" && objID.IndexOf(".") > 0 && !objID.EndsWith(".*"))
                        {
                            objID = objID.Substring(0, objID.LastIndexOf(".")) + ".*";
                            ret = RightsProvider.Instance.HasRight(userID, objKind, objID);
                        }
                        */
                    }
                }
            }
            else        //本身沒有，任一子項次有即可
            {
                if (item.ContainsKey("items"))
                {
                    ArrayList subItems = item["items"] as ArrayList;
                    if (subItems != null)
                    {
                        foreach (Dictionary<string, object> subItem in subItems)
                        {
                            if (hasRight(subItem, userID))
                            {
                                ret = true;
                                break;
                            }
                        }
                    }
                }
                else
                    ret = true;     //如果也沒有下一層，說明是葉子層，所以只看上一層即可（明顯上一層有配置）
            }
            item["__rights"] = ret;
            return ret;
        }

        Dictionary<string, object> getSysPrograms(string sys, string userID)
        {
            if (sys.EndsWith(".js"))
            {
                Dictionary<string, object> dic = _config.ParseNoCache<Dictionary<string, object>>(sys);
                if (dic != null && hasRight(dic, userID))
                {
                    parseItems(dic, userID);
                    dic.Add("AppID", sys.Substring(0, sys.Length - 3));
                    return dic;
                }
            }
            return null;
        }
    }

    public class DBRightsProvider : RightsProvider
    {

        public new static readonly DBRightsProvider Instance = new DBRightsProvider();
        //HttpCache _cache;       //用來緩存B2B用戶信息

        public DBRightsProvider()
        {
            //_cache = new HttpCache(this.GetType().FullName);
        }

        #region 流程相關權限和流程設定

        bool hasRight(string userID, string rightKind, string objectID, List<OwnerKind3> ownerKind3)
        {
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", rightKind
                ,"ObjectID",objectID       //不會對所有權限進行判斷
            });
            if (userID != null && userID.Length > 0)
                args.Add("UserID", userID);
            if (ownerKind3 != null && ownerKind3.Count > 0)
            {
                string ownerKind3Str = "";
                foreach (OwnerKind3 kind in ownerKind3)
                    ownerKind3Str += (ownerKind3Str.Length > 0 ? "','" : "") + ((int)kind).ToString();
                args.Add("OwnerKind3", "'" + ownerKind3Str + "'");
            }
            return DBHelper.Instance.QueryObject("Rights/HasRight", args) != null;
        }

        #region 一般數據權限

        //提高權限判斷的性能
        //對真正的userID進行判斷(如是否對某人有權限，對某個部門有權限，對某項任務有權限)
        //這些權限不能設置特殊User權限，如所有用戶有權限，所有登錄用戶有權限，所有PCI內網用戶有權限
        public override bool HasRight(string userID, string rightKind, string objectID)
        {
            List<OwnerKind3> ownerKind3 = new List<OwnerKind3>();
            ownerKind3.Add(OwnerKind3.AllUser);
            if (userID != null && userID.Length > 0)
                ownerKind3.Add(OwnerKind3.LoginUser);
            return hasRight(userID, rightKind, objectID, ownerKind3);
        }

        //如果有所有權限，查詢的sql 欄位 in就可以直接去除，而不要組字符串來IN查詢，提高性能
        //否則比較麻煩，要抓出所有的權限物件，才能in，程式這樣就不靈活了
        public override bool HasAllRight(string rightKind, string userID)
        {
            return HasRight(userID, rightKind, "%");        //2用% like %，1不會有%的數據
        }

        //可以判斷有權限的有誰?
        public override List<string> RightsOwner(string rightKind, string objectID, bool allRightsContain)
        {
            List<string> ret = new List<string>();
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", rightKind
                ,"ObjectID",objectID       //不會對所有權限進行判斷
            });
            DataSet ds = DBHelper.Instance.Query("Rights/RightsOwner", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string userID = dr[0].ToString().Trim();
                    if (!ret.Contains(userID))
                        ret.Add(userID);
                }
            }
            return ret;
        }

        //程式可以用這個組成IN字符串，再放進SQL中查詢，形成權限過濾
        public override List<string> RightsData(string rightKind, string userID)
        {
            List<string> ret = new List<string>();
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", rightKind
                ,"UserID",userID       //不會對所有權限進行判斷
            });
            DataSet ds = DBHelper.Instance.Query("Rights/RightsData", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string objectID = dr[0].ToString().Trim();
                    if (!ret.Contains(objectID))
                        ret.Add(objectID);
                }
            }
            return ret;
        }

        #endregion

        #region 權限管理

        #region 普通流程權限管理

        public void AddRights(string userID, string rightKind, string objectID)
        {
            if (hasRight(userID, rightKind, objectID, null))
                throw new PCIBusException("權限已存在");
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", rightKind
                ,"ObjectKind","1"
                ,"ObjectID",objectID       //不會對所有權限進行判斷
                ,"OwnerKind","1"
                ,"OwnerID",userID
            });
            DBHelper.Instance.Execute("Insert_Base_Rights@Flow", args);
        }

        public void RemoveRights(string userID, string rightKind, string objectID)
        {
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", rightKind
                ,"ObjectKind","1"
                ,"ObjectID",objectID       //不會對所有權限進行判斷
                ,"OwnerKind","1"
                ,"OwnerID",userID
            });
            DBHelper.Instance.Execute("Delete_Base_Rights@Flow", args);
        }

        #endregion

        #region 流程管理(以權限方式表現的流程)

        //不用傳左邊，因為只有一個，從資料庫中找出來就好.沒有提供全部刪除功能
        public string DeleteFlowNode(string nodeID, string rightKind, bool autoConnect)
        {
            //找到左節點
            string leftID = null;
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", rightKind
                ,"ObjectKind","1"
                ,"OwnerKind","1"
                ,"ObjectID",nodeID
            });
            DataSet ds = DBHelper.Instance.Query("Select_Base_Rights@Flow", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count == 1)  //2表示有多個節點,不做任何動作(都不能顯示)
                leftID = ds.Tables[0].Rows[0]["OwnerID"].ToString();

            if (leftID != null)
            {
                //刪除左節點連線
                DBHelper.Instance.Execute("Delete_Base_Rights@Flow", args);

                if (autoConnect)
                {
                    //將右節點全部綁到左節點
                    Dictionary<string, object> updateArgs = Tool.ToDic(new object[]{
                        "RightKind__W", rightKind
                        ,"ObjectKind__W","1"
                        ,"OwnerKind__W","1"
                        ,"OwnerID__W",nodeID
                        ,"OwnerID",leftID
                    });
                    DBHelper.Instance.Execute("Update_Base_Rights@Flow", updateArgs);
                }
            }
            //else
            //    return "沒有數據庫連線，不需要刪除(直接在Client端刪就好)"
            return "";
        }

        //往右邊新增節點(會報錯，可能新節點已有左節點)
        public string InsertFlowRightNode(string nodeID, string rightKind, string newID)
        {
            if (nodeID == newID)
                return "不能新增與自己相同的節點";
            string loopFlowStr = isDeadLoop(rightKind, nodeID, newID, "");
            if (loopFlowStr.Length > 0)
                return "不能新增:" + newID + "->" + nodeID + "，因為存在:" + loopFlowStr;

            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", rightKind
                ,"ObjectKind","1"
                ,"OwnerKind","1"
                ,"ObjectID",newID
            });
            DataSet ds = DBHelper.Instance.Query("Select_Base_Rights@Flow", args);
            //可以新增兩個左結點，程式自己負責(流程就不行，但是單純的數據權限就可以，如果流程被新增兩個左節點，則可能走不同的路)
            //if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            //    return newID + "已有左邊節點，不能同時有兩個左節點";
            //else
            //{
            args.Add("OwnerID", nodeID);
            DBHelper.Instance.Execute("Insert_Base_Rights@Flow", args);
            return "";
            //}

        }

        //找是否有死迴圈
        string isDeadLoop(string rightKind, string nodeID, string newID, string flowStr)
        {
            string leftID = null;
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", rightKind
                ,"ObjectKind","1"
                ,"OwnerKind","1"
                ,"ObjectID",nodeID
            });
            DataSet ds = DBHelper.Instance.Query("Select_Base_Rights@Flow", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)  //2表示有多個節點,不做任何動作(都不能顯示)
            {
                if (flowStr == "")
                    flowStr = nodeID;
                leftID = ds.Tables[0].Rows[0]["OwnerID"].ToString();
                flowStr += "->" + leftID;
                if (leftID == newID)
                    return flowStr;
                else
                    return isDeadLoop(rightKind, leftID, newID, flowStr);
            }
            return "";
        }

        //往左邊新增節點(不會有錯，因為總是新增右邊的節點，不會報錯)
        public string InsertFlowLeftNode(string nodeID, string rightKind, string newID)
        {
            if (nodeID == newID)
                return "不能新增與自己相同的節點";
            string loopFlowStr = isDeadLoop(rightKind, newID, nodeID, "");
            if (loopFlowStr.Length > 0)
                return "不能新增:" + nodeID + "->" + newID + "，因為存在:" + loopFlowStr;

            //當前節點有左節點嗎?
            string leftID = null;
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", rightKind
                ,"ObjectKind","1"
                ,"OwnerKind","1"
                ,"ObjectID",nodeID
            });
            DataSet ds = DBHelper.Instance.Query("Select_Base_Rights@Flow", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)  //2表示有多個節點,不做任何動作(都不能顯示)
                leftID = ds.Tables[0].Rows[0]["OwnerID"].ToString();

            if (leftID == null)  //當前節點沒有左節點，則新增一筆就好(不管newID的情況，因為是加在右邊)
            {
                args.Add("OwnerID", newID);
                DBHelper.Instance.Execute("Insert_Base_Rights@Flow", args);
            }
            else              //當前節點有左節點，則替換 
            {
                //替換當前左節點為新左節點
                Dictionary<string, object> updateArgs = Tool.ToDic(new object[]{
                    "RightKind__W", rightKind
                    ,"ObjectKind__W","1"
                    ,"OwnerKind__W","1"
                    ,"ObjectID__W",nodeID
                    ,"OwnerID",newID
                });
                DBHelper.Instance.Execute("Update_Base_Rights@Flow", updateArgs);

                //新左節點有左節點嗎?
                //如果有，就算了，直接把現在的連過去
                //如果沒有，則掛靠舊的左結點
                Dictionary<string, object> args2 = Tool.ToDic(new object[]{
                    "RightKind", rightKind
                    ,"ObjectKind","1"
                    ,"OwnerKind","1"
                    ,"ObjectID",newID
                });
                DataSet ds2 = DBHelper.Instance.Query("Select_Base_Rights@Flow", args2);
                if (ds2 == null || ds2.Tables.Count == 0 || ds2.Tables[0].Rows.Count == 0)  //2表示有多個節點,不做任何動作(都不能顯示)
                {
                    //要連起新節點和舊左節點
                    //則要查詢舊左節點是否有連到新節點?
                    if (isDeadLoop(rightKind, leftID, newID, "").Length == 0)
                    {
                        args2.Add("OwnerID", leftID);
                        DBHelper.Instance.Execute("Insert_Base_Rights@Flow", args2);
                    }
                }
            }
            return "";
        }

        //替換流程人員(先在左邊插入,再斷開自動重連)
        public string ReplaceFlowNode(string nodeID, string rightKind, string newID)
        {
            if (nodeID == newID)
                return "不能替換為與自己相同的節點";
            string loopFlowStr = isDeadLoop(rightKind, nodeID, newID, "");
            if (loopFlowStr.Length > 0)
                return "不能替換:" + nodeID + "為" + newID + "，因為存在:" + loopFlowStr;

            string ret = InsertFlowLeftNode(nodeID, rightKind, newID);
            if (ret.Length == 0)
                ret = DeleteFlowNode(nodeID, rightKind, true);
            return ret;
        }

        public string CopyFlow(string flowNo, string newFlowNo)
        {
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", newFlowNo
            });
            DataSet ds = DBHelper.Instance.Query("Select_Base_Rights@Flow", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)  //2表示有多個節點,不做任何動作(都不能顯示)
                return "新流程名已存在，不能復制:" + newFlowNo;
            else
            {
                Dictionary<string, object> args2 = Tool.ToDic(new object[]{
                    "FlowNo", flowNo
                    ,"NewFlowNo", newFlowNo
                });
                DBHelper.Instance.Execute("Rights/CopyFlow", args2);
                return "";
            }
        }

        public string RenameFlow(string flowNo, string newFlowNo)
        {
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", newFlowNo
            });
            DataSet ds = DBHelper.Instance.Query("Select_Base_Rights@Flow", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)  //2表示有多個節點,不做任何動作(都不能顯示)
                return "新流程名已存在，不能改名:" + newFlowNo;
            else
            {
                Dictionary<string, object> args2 = Tool.ToDic(new object[]{
                    "FlowNo", flowNo
                    ,"NewFlowNo", newFlowNo
                });
                DBHelper.Instance.Execute("Rights/RenameFlow", args2);
                return "";
            }
        }

        #endregion

        #endregion

        #endregion

        #region 數據權限(以群組方式分配權限)

        public override bool HasDataRight(string userID, string rightKind, string objectID)
        {
            if (userID != null && userID.Length > 0)
            {
                if (isSuperManager(userID))
                    return true;
                Dictionary<string, object> args = Tool.ToDic(new object[]{
                    "RightKind", rightKind
                    ,"ObjectID",objectID       //不會對所有權限進行判斷
                    ,"UserID",userID
                });
                return DBHelper.Instance.QueryObject("Rights/HasDataRight", args) != null;
            }
            return false;
        }

        public override List<string> DataRightsData(string rightKind, string userID)
        {
            if (userID != null && userID.Length > 0)
            {
                List<string> ret = new List<string>();
                Dictionary<string, object> args = Tool.ToDic(new object[]{
                    "RightKind", rightKind
                    ,"UserID",userID       //不會對所有權限進行判斷
                });
                DataSet ds = DBHelper.Instance.Query("Rights/DataRightsData", args);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        string objectID = dr[0].ToString().Trim();
                        if (!ret.Contains(objectID))
                            ret.Add(objectID);
                    }
                }
                return ret;
            }
            return null;
        }

        public override List<string> DataRightsOwner(string rightKind, string objectID)
        {
            List<string> ret = new List<string>();
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "RightKind", rightKind
                ,"ObjectID",objectID       //不會對所有權限進行判斷
            });
            DataSet ds = DBHelper.Instance.Query("Rights/DataRightsOwner", args);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string userID = dr[0].ToString().Trim();
                    if (!ret.Contains(userID))
                        ret.Add(userID);
                }
            }
            return ret;
        }

        public override bool HasDataRight(string rightKind, string objectID)
        {
            string userID = AuthenticateHelper.Instance.UserID;
            return isSuperManager(userID) || HasDataRight(userID, rightKind, "*") || HasDataRight(userID, rightKind, objectID);
        }

        public override bool HasAllDataRight(string rightKind,string userID)
        {
            //string userID = AuthenticateHelper.Instance.UserID;
            return isSuperManager(userID) || HasDataRight(userID, rightKind, "*");
        }

        #endregion

        #region 服務權限判斷(超級管理員,IP管控+Login管控,群組數據權限分配)

        bool isSuperManager(string userID)
        {
            if (userID != null)
            {
                ArrayList managers = SystemConfig.Instance.Get<ArrayList>("SuperManager");
                return managers.IndexOf(userID) >= 0;
            }
            return false;
        }

        int getUserIPKind(string userIp)
        {
            //string userHostAddress = AppEventHanlder.Instance.UserHost;
            ArrayList ipSettings = SystemConfig.Instance.Get<ArrayList>("IPKind");
            int ret = 0;
            //從后面開始匹配越來越嚴
            if (ipSettings != null)
            {
                for (int i = ipSettings.Count - 1; i > 0; i--)
                {
                    string ipSet = ipSettings[i].ToString();
                    string[] ipArray = ipSet.Split(new char[] { '#' });
                    foreach (string ip in ipArray)
                    {
                        if (userIp.StartsWith(ip))
                        {
                            return i;
                        }
                    }
                }
            }
            return ret;
        }

        bool serviceDirectAccess(string kind, string service, string userIP, string userID)
        {
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "Kind", kind
                ,"Service",service 
                ,"IPKind",getUserIPKind(userIP)
            });
            if (userID != null && userID.Length > 0)
                args.Add("Login", "1");
            return DBHelper.Instance.QueryObject("Rights/ServiceDirectAccess", args) != null;
        }
        /*
        bool menuDirectAccess(string kind, string service, string userID)
        {
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                "Kind", kind
                ,"Service",service 
                ,"Login", userID != null && userID.Length > 0?"1":"0"
            });
            return DBHelper.Instance.QueryObject("Rights/menuDirectAccess", args) != null;
        }
        */
        bool menuHasRight(string userID, string rightKind, string objectID,int accountKind)
        {
            Dictionary<string, object> args = Tool.ToDic(
                "RightKind", rightKind
                ,"ObjectID",objectID       //不會對所有權限進行判斷
                ,"AccountKind",accountKind < 2 ? "IN" : "OUT"
            );
            if (userID != null && userID.Length > 0)
            {
                args.Add("UserID", userID.Replace(".00",""));
            }
            return DBHelper.Instance.QueryObject("Rights/HasRightByMenu", args) != null;
        }

        public override void CheckServiceRight(string objKind, string objId)
        {
            string userId = AuthenticateHelper.Instance.UserID;
            string userIP = AppEventHanlder.Instance.UserHost;
            //string objKind = "RoleRightKind";      //限定FlowAction權限才不會讓TASK從這里鉆進來
            //string objId = this.roleKind + "." + rightKind;
            if (!RightsProvider.Instance.HasServiceRight(objKind, objId, userIP, userId))
            {
                if (userId == null)
                    throw new PCINeedLoginException(objKind + "." + objId);
                else
                    throw new PCINoPermissionException(userId + ":" + objKind + "." + objId);
            }
        }

        public override bool HasServiceRight(string kind, string service, string userIP, string userID)
        {
            Tool.Trace("valid permission","kind",kind,"service",service,"userIP",userIP,"userID",userID);
            //if (userIP == "172.19.6.86" && userIP == "172.19.61.144")
            //    return true;        //開發時使用
            //if (HttpContext.Current.Server.MachineName.ToUpper() == "WEBTEST")
            //    return true;
            //if (HttpContext.Current.Server.MachineName.ToUpper() == "ADMIN-PC")
            //    return true;
            //權限管控可以硬編碼，因為只改一個地方(kevin.zou 2012.4.11 注)
            //以后如果繼續復雜化，可以考慮重構
            if (userID != null)
            {
                Dictionary<string,object> user = AuthenticateHelper.Instance.GetUserInfo(userID);
                if (user["Enable"].ToString() == "Y")
                    throw new PCINoPermissionException();
            }
            //所有用戶(包括B2B供應商用戶)可以在任何地方(internet)訪問ClientTool.
            if (kind == "Service" && service.StartsWith("ClientTool"))
                return true;
            if (kind == "Ajax" && service.StartsWith("ClientTool."))
                return true;
            //2013.5.20 www.pci.co.id,172.19.5.* 172.19.6.*的不用檢驗
            ArrayList noCheckB2BService = SystemConfig.Instance.Get<ArrayList>("NoCheckB2BUser");
            bool noCheckB2B = false;
            if (noCheckB2BService != null)
            {
                foreach (string s in noCheckB2BService)
                {
                    if (service.ToLower().StartsWith(s.ToLower()))
                    {
                        noCheckB2B = true;
                    }
                }
            }

            int accountKind = userID == null ? 0 : 1;        //0未登錄,1集團內用戶或不需要區分供應商和客戶,2供應商,3客戶
            if (!noCheckB2B && userID != null)
            {
                //1表示b2b供應商用戶,2表示b2b採購用戶(PCI)，0表示非b2b用戶，空表示未登錄
                //string b2bUserKind;
                //b2bUserKind = ServiceCaller.Instance.Call<string>(ServiceCaller.CallType.BaseCall, "B2B.Service.UserKind");
                ////B2B供應商用戶可以在任何地方(internet)訪問B2B.Service.
                //if (b2bUserKind == "1")
                //    return service.StartsWith("B2B.Service.");
                Dictionary<string,object> userInfo = AuthenticateHelper.Instance.GetUserInfo(userID);
                if (userInfo.ContainsKey("AccountKind"))
                {
                    string webpubKind = userInfo["AccountKind"].ToString();
                    if (webpubKind == "S")
                        accountKind = 2;
                    else if (webpubKind == "C")
                        accountKind = 3;
                }
            }
            Tool.Trace("right info", "accountKind", accountKind, "noCheckB2B", noCheckB2B);
            //2013.5.20 www.pci.co.id,172.19.5.* 172.19.6.*的不用檢驗
            bool enableInternetCheck = SystemConfig.Instance.Get<bool>("EnableInternetCheck");
            if (enableInternetCheck)
            {
                ArrayList noCheckInternetService = SystemConfig.Instance.Get<ArrayList>("NoCheckInternet");
                bool noCheckInternet = false;
                if (noCheckInternetService != null)
                {
                    foreach (string s in noCheckInternetService)
                    {
                        if (service.ToLower().StartsWith(s.ToLower()))
                        {
                            noCheckInternet = true;
                        }
                    }
                }

                //未授權的用戶不允許用internet訪問服務(但B2B供應商用戶不受此限制)
                if (!noCheckInternet && getUserIPKind(userIP) < 1 && accountKind < 2)
                {
                    if (userID == null)
                    {
                        Tool.Trace("no login and use internet access");
                        return false;
                    }
                    ArrayList managers = SystemConfig.Instance.Get<ArrayList>("AllowInternetAccess");
                    if (managers.IndexOf(userID) < 0)
                    {
                        Tool.Trace("login but userID not in AllowInternetAccess", "managers", managers);
                        return false;
                    }
                }
            }
            string varContent = AppEventHanlder.Instance.ServiceVarContent();
            service = service + (varContent!=null?"$" + varContent:"") ;
            if (accountKind == 1 && isSuperManager(userID))
                return true;
            else if (accountKind < 2 && serviceDirectAccess(kind, service, userIP, userID))
                return true;
            //暫時不從這里著手，因為除了判斷權限外，還有很多需要抓選單或service權限的地方，一一改反而復雜
            //目前關于權限讀取，只用管base_datarights table就好，然後循環menu
            //而如果加這個規則，則很多判斷權限的地方(如分配權限的tree)都要改
            //else if (accountKind < 2 && menuDirectAccess(kind, service,userID))
            //    return true;
            else if (HasDataRight(userID, kind, service))   //2供應商和3客戶統一只采用這種直接對應的角色權限
                return true;
            else if (menuHasRight(userID, kind, service,accountKind))
                return true;
            //Service和DBPackage也會判斷,造成很多沒用的warn日志
            //Tool.Warn("No Permission", "service", service, "varContent", varContent);
            return false;
        }

        #endregion

        #region 用于功能權限(如Ajax.Service或Url或DBCommand)先NoNeedRight再HasRightWithLoginUser，可節約登錄用戶的認證【已作廢】

        public enum OwnerKind3
        {
            AllUser             //所有用戶
            ,
            LoginUser          //所有登錄用戶
                ,
            PCI_adidas          //adidas特有IP段(如172.19.48.*等配置在Sys.Config中)
                ,
            PCI                //172.19.*
                , Pouchen            //172.*
        }

        List<OwnerKind3> getOwnerKind3ByIP()
        {
            List<OwnerKind3> ret = new List<OwnerKind3>();
            string userHostAddress = AppEventHanlder.Instance.UserHost;
            Dictionary<string, object> ipSettings = SystemConfig.Instance.Get<Dictionary<string, object>>("OwnerKind3");
            foreach (string ownerKind3Str in ipSettings.Keys)
            {
                string ipSetting = ipSettings[ownerKind3Str].ToString();
                string[] ipArray = ipSetting.Split(new char[] { '#' });
                foreach (string ip in ipArray)
                {
                    if (userHostAddress.StartsWith(ip))
                    {
                        ret.Add((OwnerKind3)(int.Parse(ownerKind3Str)));
                        break;
                    }
                }
            }
            return ret;
        }

        //是否可以匿名訪問
        public override bool NoNeedRight(string rightKind, string objectID)
        {
            List<OwnerKind3> ownerKind3 = getOwnerKind3ByIP();
            ownerKind3.Add(OwnerKind3.AllUser);
            return hasRight(null, rightKind, objectID, ownerKind3);
        }

        #endregion

    }

    public class DevelopRightsProvider : DBRightsProvider
    {

        ArrayList allowIPs;
        bool allowAll;

        public DevelopRightsProvider(ArrayList allowIPs,bool allowAll)
        {
            this.allowIPs = allowIPs;
            this.allowAll = allowAll;
        }

        public override bool HasServiceRight(string kind, string service, string userIP, string userID)
        {
            return this.allowAll || allowIPs.IndexOf(userIP) >= 0;
        }


        //提高權限判斷的性能
        //對真正的userID進行判斷(如是否對某人有權限，對某個部門有權限，對某項任務有權限)
        //這些權限不能設置特殊User權限，如所有用戶有權限，所有登錄用戶有權限，所有PCI內網用戶有權限
        public override bool HasRight(string userID, string rightKind, string objectID)
        {
            return true;
        }

        //如果有所有權限，查詢的sql 欄位 in就可以直接去除，而不要組字符串來IN查詢，提高性能
        //否則比較麻煩，要抓出所有的權限物件，才能in，程式這樣就不靈活了
        public override bool HasAllRight(string rightKind, string userID)
        {
            return true;
        }

        public override bool HasDataRight(string userID, string rightKind, string objectID)
        {
            return true;
        }

        public override bool HasDataRight(string rightKind, string objectID)
        {
            return true;
        }

        public override bool HasAllDataRight(string rightKind, string userID)
        {
            return true;
        }

    }

}