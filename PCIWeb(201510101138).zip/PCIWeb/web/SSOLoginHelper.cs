﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Reflection;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using PCIWeb.Tools;

namespace PCIWeb
{

    //遠程登錄模組
    public class SSOLoginHelper
    {
        public static readonly SSOLoginHelper _instance = new SSOLoginHelper();

        public static SSOLoginHelper Instance
        {
            get
            {
                return _instance;
            }
        }


        /*
        Dictionary<string, string> _cacheLoginKey = new Dictionary<string, string>();
        public string DirectLoginKey(string userID)
        {
            int count = 0;
            string guid = Guid.NewGuid().ToString();
            string shortKey = guid.Substring(0,8);
            _cacheLoginKey.Add(
            _cacheLoginKey = new Dictionary<string, string>();
        }
        */
        public readonly string LoginKey = "SSOLOGONKEY";
        public readonly string NOFOREVER = "SSOPCINFE";
        string _defaultServiceID = "SSOLoginService";
        string _defaultMethod = "LoginAsKey";
        public void RemoteLogin()
        {
            try
            {
                string forever = "Forever";
                string foreverKey = HttpContext.Current.Request.QueryString[NOFOREVER];
                if (foreverKey != null)
                {
                    forever = "";
                }
                string loginKey = HttpContext.Current.Request.QueryString[LoginKey];
                if (loginKey != null)
                {
                    string serviceObjectID = HttpContext.Current.Request.QueryString["Service"] ?? _defaultServiceID;
                    string methodName = HttpContext.Current.Request.QueryString["Method"] ?? _defaultMethod;
                    object service = ObjectFactory.Default.Get(serviceObjectID);
                    Tool.Trace("遠程登錄", "serviceObjectID", serviceObjectID,"methodName", methodName);
                    if (service != null)
                    {
                        string userID = null;
                        userID = service.GetType().GetMethod(methodName).Invoke(service, new object[] { loginKey }) as string;
                        if (userID != null)
                        {
                            string userService = HttpContext.Current.Request.QueryString["UserService"];
                            Tool.Trace("安全詢問");
                            AuthenticateHelper.Instance.Login(userID + (userService == null ? "" : "@" + userService), forever);
                            Tool.Trace("遠程登錄成功","UserID", userID,"userService", userService ?? "");

                        }
                    }
                }


                string codeKey = HttpContext.Current.Request.QueryString["PCISSODIRECTLOGON"];
                if (codeKey != null)
                {
                    string key = ByteDecode(codeKey);
                    if(key!=""){
                        Tool.Trace("直接賬號密碼登錄","key", key);
                        //首先LogIn
                        string[] tmp = key.Split(new char[] { '|' });
                        string account = tmp[0];
                        string password = tmp[1];
                        LoginHelper.Instance.Login(account, password, forever);
                        Tool.Trace("登錄成功");
                    }
                    else
                        Tool.Trace("Decode失敗" ,"codeKey", codeKey);
                }
            }
            catch (Exception ex)
            {
                Tool.Error("遠程登錄失敗","ex",ex);
            }


      }

        #region byte簡單編碼

        /// <summary>
        /// 簡單UTF8編碼
        /// </summary>
        /// <param name="src"></param>
        /// <returns></returns>
        public static string ByteEncode(string src)
        {
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(src);
            return BitConverter.ToString(bytes);
        }

        /// <summary>
        /// 簡單UTF8解碼
        /// </summary>
        /// <param name="src"></param>
        /// <returns></returns>
        public static string ByteDecode(string src)
        {
            try
            {
                byte[] bytes = getBytesFromString(src);
                return System.Text.Encoding.UTF8.GetString(bytes);
            }
            catch
            {
                return "";
            }
        }

        /// <summary>
        /// 將字符串形式的byte,轉成真正的byte類型
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        static byte[] getBytesFromString(string bytes)
        {
            string[] strBytes = bytes.Split(new char[] { '-' });
            byte[] ret = new byte[strBytes.Length];
            int i = 0;
            foreach (string b in strBytes)
                ret[i++] = Convert.ToByte(b, 16);
            return ret;
        }

        #endregion
    }



}