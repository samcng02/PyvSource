﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Reflection;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using PCIWeb.Tools;

namespace PCIWeb
{
    public class LoginHelper
    {
        public static readonly LoginHelper _instance = new LoginHelper();

        public static LoginHelper Instance
        {
            get
            {
                return _instance;
            }
        }

        public string Login(string account, string password)
        {
            return Login(account, password, null, null);
        }

        public string Login(string account, string password,string loginInfo)
        {
            return Login(account, password, null, loginInfo);
        }

        public virtual string Login(string account, string password, string loginValidID, string loginInfo)
        {
            string ret;
            if (loginValidID != null)
            {
                LoginValider valider = ObjectFactory.Default.Get<LoginValider>(loginValidID);
                if (valider != null)
                    ret = valider.Valid(account, password);
                else
                    throw new ApplicationException("this loginValidID(" + loginValidID + ") is not exists");
            }
            else
            {
                LoginValider valider = LoginValider.Instance;
                ret = valider.Valid(account, password);
            }

            if (ret != null && ret.Substring(0, 1) == "1")
                AuthenticateHelper.Instance.Login(ret.Substring(1) + (loginValidID == null ? "" : "@" + loginValidID), loginInfo);
            else
                Tool.Warn("Login Fail", "account", account, "password", password);
            return ret;
        }

        public virtual void Logout()
        {
            AuthenticateHelper.Instance.Logout();
        }
    }
}