﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using PCIWeb.Tools;

namespace SmsService
{
    /// <summary>
    /// 簡訊處理器
    /// </summary>
    public class Dispatcher
    {
        SmsUITask _smsTask = ObjectFactory.Default.Get<SmsUITask>("SmsUITask");

        /// <summary>
        /// 用于本機測試(2011.4.27暫時)
        /// </summary>
        public void RunJob()
        {
            Dictionary<string, object> args = Tool.ToDic(new object[]{
                        "PHONE","6285880336381"
            });
            DBHelper.Instance.NoCache(args);
            DataSet ds = DBHelper.Instance.Query("Select_WEB_SMS_RECEIVE@ERP", args);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    if (dr["RECTIME"].ToString().Substring(0, 8) == DateTime.Now.ToString("yyyyMMdd")
                        && dr["STATUS"].ToString() == "OK"
                        )
                    {
                        DealSms(Tool.ToDic(dr));
                    }
                }
            }

        }

        ///處理一條簡訊
        public void DealSms(Dictionary<string, object> args)
        {
            PCIWeb.Tools.Tool.Trace("Dispatcher.DealSms");
            string status = args["STATUS"].ToString();

            if (status == "OK")
            {
                try
                {
                    //還需要驗證手機號碼，并匹配到user，進行權限驗證
                    string content = args["CONTENT"].ToString();
                    string userID = null;
                    string tel_no = args["PHONE"].ToString();
                    if (tel_no.StartsWith("62"))
                    {
                        tel_no = "0" + tel_no.Substring(2);
                        DataSet ds = DBHelper.Instance.Query("SMS/GetUserByPhone", Tool.ToDic(new object[]{
                        //DataSet ds = DBHelper.Instance.Query("Select_shr_usermail@WebPub", Tool.ToDic(new object[]{
                            "tel_no",tel_no
                        }));

                        PCIWeb.Tools.Tool.Trace("status OK", "tel_no", tel_no);

                        //如果有多筆，選第一筆
                        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                        {
                            userID = ds.Tables[0].Rows[0]["user_id"].ToString().Trim();
                            //登錄(如果service是遠方的，則傳入)
                            //驗證權限，防止誰都可以使用(避免又去使用這個，因為本身這支是從webservice過來，沒有經過user認證)
                            PCIWeb.AuthenticateHelper.Instance.SetUserID(userID);
                        }
                        PCIWeb.Tools.Tool.Trace("取得用戶ID", "userID", userID);

                        string dealerService = getService(content, userID,args);
                        PCIWeb.Tools.Tool.Trace("取得服務", "dealerService", dealerService);

                        if (dealerService != null)
                        {
                            //Dictionary<string, object> dealResult = null;
                            Dictionary<string, object> reportArgs = new Dictionary<string, object>();
                            reportArgs["RECID"] = args["RECID"].ToString();
                            reportArgs["DEALTIME"] = DateTime.Now.ToString("yyyyMMddHHmmss");
                            string errMsg = "";
                            string userMsg = "";
                            try
                            {
                                //PCIWeb.ServiceCaller.Instance.Call(PCIWeb.ServiceCaller.CallType.PermissionCall, dealerService,args["CONTENT"].ToString()
                                //      , tel_no, userID, new string[] { args["RECTIME"].ToString() });
                                //自己處理異常，哪有公共異常好用
                                Dictionary<string, object> ret = PCIWeb.ServiceCaller.Instance.CallToDic(PCIWeb.ServiceCaller.CallType.PermissionCall, dealerService, args["CONTENT"].ToString()
                                      , tel_no, userID, new string[] { args["RECTIME"].ToString() });
                                string ajaxError = ret["AjaxError"].ToString();
                                errMsg = ajaxError == "0" ? "" : ret["Message"].ToString().Trim();
                                userMsg = ajaxError == "1" || ajaxError == "2" || ajaxError == "3" || ajaxError == "6" ? errMsg : "";
                            }
                            catch (Exception ex)
                            {
                                errMsg = ex.Message;
                            }
                            reportArgs["STATUS"] = errMsg.Length == 0 ? "SUCCESS" : "FAIL";
                            reportArgs["DEALINFO"] = errMsg.Length > 450 ? errMsg.Substring(0, 450) : errMsg;
                            reportArgs["DEALER"] = dealerService;
                            reportArgs["USERID"] = userID ?? "";
                            PCIWeb.Tools.Tool.Trace("取得userID", "userID", userID);

                            if (reportArgs["STATUS"].ToString() != "SUCCESS")
                                Tool.Error("處理簡訊失敗", "dealerService", dealerService, "content", content, "tel_no", tel_no, "userID", userID, "errMsg", errMsg);//dealResult["AjaxError"].ToString() + dealResult["Message"].ToString());
                            //不需要記錄結果，因為WEB_SMS_RECEIVE有記錄
                            //DBHelper.Instance.NoLogResult(reportArgs);
                            DBHelper.Instance.Execute("SMS/Report_Dispatch", reportArgs);
                            if (userID != null && userID.Length > 0 && errMsg.Length > 0)
                                SmsSender.Instance.Send(tel_no, "", (userMsg.Length > 0 ? userMsg : "system error,please try again or contact IT department,thank you!") + "(" + content + ")", args["RECPHONE"].ToString(), "SMS_ERR_REPLY");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Tool.Error("處理收到簡訊時工作失敗","ex", ex.ToString());
                }

            }

        }

        //根據content獲取service
        private string getService(string content, string userID,Dictionary<string,object> args)
        {
            //TODO:優先處理固定的 如:HELP ? Weather等

            //專用簡訊貓，如nike sms complain系統，專用一支簡訊貓
            string recPhone = args["RECPHONE"].ToString();
            Dictionary<string, object> kindSender = SystemConfig.Instance.Get<Dictionary<string, object>>("SmsFramework.RecPhoneDealer");
            if (kindSender.ContainsKey(recPhone))
                return kindSender[recPhone].ToString();

            //TODO:再匹配正則表達式處理固定的 如:13-8時產 15-6RFT等
            if (content.StartsWith("時產") || content.StartsWith("时产") || content.StartsWith("Hour")
                || content.EndsWith("時產") || content.EndsWith("时产") || content.EndsWith("Hour"))
            {
                return "EIP_Shoe.DealSms";
            }

            //簡訊任務第三優先
            if (userID != null && _smsTask.isMatch(userID))
                return "SmsUITask.DealTask";

            //TODO:最后再按功能碼，選出處理程式，再轉交執行
            if (content.Length > 0)
            {
                string prefixCode = content.Substring(0, 1).ToUpper();
                if (prefixCode == "H" || prefixCode == "P")
                {
                    return "PusatSmsDealer.DealSms";
                }

                else if (prefixCode == "A")
                {
                    return "adidasSmsDealer.DealSms";
                }
                else if (prefixCode == "B")
                {
                    return "PCIWeb.Mat.Form.SmsSign";
                }

                else if (prefixCode == "G")
                {
                    return "GSISmsDealer.DealSms";
                }

                else if (prefixCode == "T")
                {
                    return "PusatTestSmsDealer.DealSms";
                }

                //else if (prefixCode == "N")
                //{
                //    return "PCIWeb.NikeSmsDealer.DealSms";
                //}

            }
            //最后都沒有匹配，則回傳信息給user或日志記錄下來
            return null;
        }

    }
}